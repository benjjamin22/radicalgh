// The single place an online payment becomes a Receipt. Both the browser
// callback and the provider webhook call finalizePayment(); it is safe to
// call any number of times for the same reference.
const Payment = require('../models/Payment');
const Receipt = require('../models/Receipt');
const Fee = require('../models/Fee');
const Entry = require('../models/Entry');
const { verifyTransaction, toKobo } = require('./paystack');
const { generateReceiptNo } = require('./receiptNo');
const { logSelf } = require('./logger');
const { feeBalanceForEntry } = require('./fees');
const { fullName } = require('./entryFields');

// Returns { status: 'success'|'pending'|'failed', receipt? }.
async function finalizePayment(reference) {
  const payment = await Payment.findOne({ reference });
  if (!payment) return { status: 'failed', reason: 'unknown reference' };
  if (payment.status === 'success') {
    return { status: 'success', receipt: payment.receipt ? await Receipt.findById(payment.receipt).lean() : null };
  }
  // A payment closed as "failed"/"abandoned" is still re-checked with the
  // provider: if the student did complete it afterwards (say, from an old
  // tab), the money must still become a receipt, never be lost.

  // Always ask Paystack directly; never trust the browser or webhook body alone.
  const tx = await verifyTransaction(reference);
  if (tx.status !== 'success') {
    if (['failed', 'abandoned', 'reversed'].includes(tx.status)) {
      if (payment.status === 'pending') await Payment.updateOne({ _id: payment._id, status: 'pending' }, { status: 'failed', note: `Provider status: ${tx.status}` });
      return { status: 'failed' };
    }
    return { status: payment.status === 'failed' ? 'failed' : 'pending' };
  }

  const entry = await Entry.findById(payment.entry).lean();
  if (tx.amount !== toKobo(payment.amount) || tx.currency !== 'NGN') {
    await Payment.updateOne({ _id: payment._id }, { status: 'failed', note: `Amount/currency mismatch: paid ${tx.amount} ${tx.currency}` });
    await logSelf(null, entry, 'ONLINE_PAYMENT_REJECTED', { reference, expected: toKobo(payment.amount), got: tx.amount });
    return { status: 'failed' };
  }

  // Claim the payment so a simultaneous callback + webhook can't both issue a receipt.
  const claimed = await Payment.findOneAndUpdate({ _id: payment._id, status: { $in: ['pending', 'failed'] } }, { status: 'processing' }, { new: true });
  if (!claimed) {
    const again = await Payment.findById(payment._id).lean();
    return { status: again.status === 'success' ? 'success' : 'pending', receipt: again.receipt ? await Receipt.findById(again.receipt).lean() : null };
  }

  try {
    const fee = await Fee.findById(payment.fee).lean();
    const before = await feeBalanceForEntry(entry, payment.fee);
    const overpaid = before && payment.amount > before.balance + 0.001;

    let receipt = null;
    for (let attempt = 0; attempt < 5 && !receipt; attempt += 1) {
      try {
        receipt = await Receipt.create({
          receiptNo: generateReceiptNo(),
          entry: entry._id,
          entryRegNo: entry.regNo,
          entryName: fullName(entry),
          department: entry.department,
          amount: payment.amount,
          purpose: fee ? fee.title : 'Online payment',
          fee: payment.fee,
          source: 'online',
          cashierUsername: 'Online',
          reference,
        });
      } catch (err) {
        if (err.code === 11000 && err.keyPattern && err.keyPattern.reference) {
          receipt = await Receipt.findOne({ reference });
        } else if (err.code !== 11000 || attempt === 4) throw err;
      }
    }

    await Payment.updateOne(
      { _id: payment._id },
      { status: 'success', receipt: receipt._id, note: overpaid ? 'Paid more than the balance at confirmation time (simultaneous payments). Review.' : '' }
    );
    await logSelf(null, entry, 'ONLINE_PAYMENT_CONFIRMED', { reference, receiptNo: receipt.receiptNo, amount: payment.amount, overpaid: !!overpaid });
    return { status: 'success', receipt: receipt.toObject ? receipt.toObject() : receipt };
  } catch (err) {
    // Let the next callback/webhook retry.
    await Payment.updateOne({ _id: payment._id, status: 'processing' }, { status: 'pending' });
    throw err;
  }
}

module.exports = { finalizePayment };
