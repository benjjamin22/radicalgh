// Thin wrapper around Paystack's REST API (Node 18+ built-in fetch, no
// extra package). Only the server ever sees PAYSTACK_SECRET_KEY.
const crypto = require('crypto');

const BASE = 'https://api.paystack.co';

function secret() {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key) throw new Error('PAYSTACK_SECRET_KEY is not set.');
  return key;
}

async function call(path, options = {}) {
  const res = await fetch(BASE + path, {
    ...options,
    headers: { Authorization: `Bearer ${secret()}`, 'Content-Type': 'application/json' },
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || json.status === false) {
    throw new Error(json.message || `Paystack request failed (${res.status})`);
  }
  return json.data;
}

const toKobo = (naira) => Math.round(Number(naira) * 100);

function initializeTransaction({ email, amount, reference, callbackUrl, metadata }) {
  return call('/transaction/initialize', {
    method: 'POST',
    body: JSON.stringify({ email, amount: toKobo(amount), reference, callback_url: callbackUrl, metadata }),
  });
}

function verifyTransaction(reference) {
  return call(`/transaction/verify/${encodeURIComponent(reference)}`);
}

// Paystack signs the raw request body with HMAC-SHA512 using the secret key.
function isValidSignature(rawBody, signature) {
  if (!signature || !Buffer.isBuffer(rawBody)) return false;
  const expected = crypto.createHmac('sha512', secret()).update(rawBody).digest('hex');
  const a = Buffer.from(expected);
  const b = Buffer.from(String(signature));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

module.exports = { initializeTransaction, verifyTransaction, isValidSignature, toKobo };
