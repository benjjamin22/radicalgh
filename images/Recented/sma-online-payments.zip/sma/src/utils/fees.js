const mongoose = require('mongoose');
const Fee = require('../models/Fee');
const Receipt = require('../models/Receipt');
const Payment = require('../models/Payment');

const round2 = (n) => Math.round(Number(n) * 100) / 100;

// Amount already paid toward each fee id for one entry (cash + online).
async function paidByFee(entryId) {
  const rows = await Receipt.aggregate([
    { $match: { entry: new mongoose.Types.ObjectId(String(entryId)), fee: { $ne: null } } },
    { $group: { _id: '$fee', paid: { $sum: '$amount' } } },
  ]);
  const map = new Map();
  rows.forEach((r) => map.set(String(r._id), r.paid));
  return map;
}

// Every active fee that applies to this entry (all departments, or their
// own), each with paid / balance. Balance never goes below zero.
async function feeSummaryForEntry(entry) {
  const [fees, paid] = await Promise.all([
    Fee.find({ active: true, department: { $in: ['', entry.department] } }).sort({ createdAt: 1 }).lean(),
    paidByFee(entry._id),
  ]);
  return fees.map((f) => {
    const p = round2(paid.get(String(f._id)) || 0);
    const balance = round2(Math.max(0, f.amount - p));
    return { ...f, paid: p, balance, cleared: balance <= 0 };
  });
}

// One fee's balance for one entry, or null if the fee doesn't apply.
async function feeBalanceForEntry(entry, feeId) {
  if (!mongoose.isValidObjectId(feeId)) return null;
  const fee = await Fee.findOne({ _id: feeId, active: true, department: { $in: ['', entry.department] } }).lean();
  if (!fee) return null;
  const paid = round2((await paidByFee(entry._id)).get(String(fee._id)) || 0);
  return { fee, paid, balance: round2(Math.max(0, fee.amount - paid)) };
}

// An online payment the student has started but that isn't confirmed yet
// (they may be at the bank's page right now). Counts as "reserved" for this
// long, so a cashier can't take the same money at the desk at the same time.
const RESERVE_MS = 15 * 60 * 1000;

async function reservedOnline(entryId, feeId) {
  const rows = await Payment.aggregate([
    {
      $match: {
        entry: new mongoose.Types.ObjectId(String(entryId)),
        fee: new mongoose.Types.ObjectId(String(feeId)),
        status: { $in: ['pending', 'processing'] },
        createdAt: { $gte: new Date(Date.now() - RESERVE_MS) },
      },
    },
    { $group: { _id: null, total: { $sum: '$amount' } } },
  ]);
  return round2(rows[0]?.total || 0);
}

// Active fees a cashier may choose from: everything for a level-1 cashier,
// only fees for their own department (or every department) for level 2.
async function feesForCashier(cashier) {
  const filter = { active: true };
  if (cashier && cashier.level === 2) filter.department = { $in: ['', cashier.department] };
  return Fee.find(filter).sort({ department: 1, title: 1 }).lean();
}

// Checks a cashier's receipt against a student's live balance. Returns
// { fee } when fine, or { error } with a message to show the cashier.
async function checkFeeForReceipt(entry, feeId, amount) {
  const info = await feeBalanceForEntry(entry, feeId);
  if (!info) return { error: 'That fee does not apply to this student (wrong department, or it is switched off).' };
  if (info.balance <= 0) return { error: `${info.fee.title} is already fully paid for this student.` };
  if (amount > info.balance) {
    return { error: `That is more than the balance. ${info.fee.title} balance is ₦${info.balance.toLocaleString()}.` };
  }
  // Cashier side checks the online side: money the student is already
  // paying online can't also be taken at the desk.
  const reserved = await reservedOnline(entry._id, info.fee._id);
  if (reserved > 0 && amount > round2(info.balance - reserved)) {
    return {
      error: `This student has an online payment of ₦${reserved.toLocaleString()} in progress for ${info.fee.title}. `
        + `Only ₦${Math.max(0, round2(info.balance - reserved)).toLocaleString()} can be received at the desk right now. `
        + 'Ask them to finish the online payment, or try again in about 15 minutes.',
    };
  }
  return { fee: info.fee, balance: info.balance };
}

module.exports = { feeSummaryForEntry, feeBalanceForEntry, feesForCashier, checkFeeForReceipt, reservedOnline, round2 };
