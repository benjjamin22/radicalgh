const AuditLog = require('../models/AuditLog');
const { clientIp } = require('./rateLimit');

// Writes one audit log entry. Logging is "every action for both levels,
// and every admin action" per the spec — so this is called from every
// admin/supervisor route, including reads (search, view) not just
// writes. Failures here are swallowed (logged to the server console
// only) rather than thrown — a broken audit write should never be the
// reason a legitimate request 500s.
async function logAction(req, { actorType, actorId = '', actorLabel = '', level = null, action, targetEntryId = '', targetPin = '', targetReceiptId = '', department = '', meta = {} }) {
  try {
    await AuditLog.create({
      actorType,
      actorId,
      actorLabel,
      level,
      action,
      targetEntryId,
      targetPin,
      targetReceiptId,
      department,
      meta,
      // Real visitor address (behind Vercel's proxy req.ip is the proxy, not the person).
      ip: clientIp(req || { headers: {} }) || '',
    });
  } catch (err) {
    console.error('Failed to write audit log', action, err);
  }
}

// Logs something a pin holder (an "entry") did on their own profile. Records
// who (name + reg no) and what — never the pin itself. Never throws.
async function logSelf(req, entry, action, meta = {}) {
  try {
    if (!entry) return;
    const name = [entry.firstName, entry.surname].filter(Boolean).join(' ');
    await logAction(req, {
      actorType: 'entry',
      actorId: String(entry._id),
      actorLabel: `${name}${entry.regNo ? ` (${entry.regNo})` : ''}`.trim(),
      action,
      targetEntryId: String(entry._id),
      department: entry.department || '',
      meta,
    });
  } catch (err) {
    console.error('Failed to write self log', action, err);
  }
}

module.exports = { logAction, logSelf };
