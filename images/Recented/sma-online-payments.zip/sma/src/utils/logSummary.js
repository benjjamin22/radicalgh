// Turns one audit-log record into a short plain-language sentence for the
// admin log pages ("Cashier ada issued receipt R-123 for ₦5,000 (Tuition)").
// Display only — never changes what is stored. Unknown actions fall back to a
// readable version of the action name, so nothing can ever break the page.

function naira(n) {
  const v = Number(n);
  return Number.isFinite(v) ? `\u20A6${v.toLocaleString('en-NG')}` : '';
}

function fieldsChanged(meta) {
  const c = meta && meta.changed;
  if (!c || typeof c !== 'object') return '';
  const names = Array.isArray(c) ? c : Object.keys(c);
  return names.length ? ` (${names.join(', ')})` : '';
}

function describeLog(log) {
  const who = log.actorLabel || log.actorType || 'Someone';
  const m = (log.meta && typeof log.meta === 'object') ? log.meta : {};
  const dept = log.department ? ` in ${log.department}` : '';
  const S = {
    ADMIN_LOGIN_SUCCESS: () => 'Admin logged in',
    ADMIN_LOGIN_FAILURE: () => 'Failed admin login attempt',
    ADMIN_LOGOUT: () => 'Admin logged out',
    SUPERVISOR_CREATED: () => `Admin created supervisor ${m.username || ''} (level ${m.level || '?'})`,
    SUPERVISOR_DEACTIVATED: () => `Admin deactivated supervisor ${m.username || ''}`,
    SUPERVISOR_REACTIVATED: () => `Admin reactivated supervisor ${m.username || ''}`,
    SUPERVISOR_LOGIN_SUCCESS: () => `Supervisor ${who} logged in`,
    SUPERVISOR_LOGIN_FAILURE: () => `Failed supervisor login for "${who}"`,
    SUPERVISOR_LOGOUT: () => `Supervisor ${who} logged out`,
    ENTRY_SEARCH: () => `Supervisor ${who} searched for "${m.query || ''}"${m.found === false ? ' (no match)' : ''}`,
    ENTRY_VIEW: () => `${who} viewed an entry${dept}`,
    ENTRY_VIEW_DENIED: () => `${who} was blocked from viewing an entry outside their department`,
    ENTRY_UPDATE: () => `Admin updated an entry${fieldsChanged(m)}`,
    ENTRY_UPDATE_DENIED: () => `${who} was blocked from updating an entry`,
    ENTRY_DELETE: () => `Admin deleted entry ${m.name || ''} ${m.regNo ? `(${m.regNo})` : ''}`.replace(/\s+/g, ' ').trim(),
    ENTRY_DEACTIVATED: () => `Admin deactivated entry ${m.name || ''} ${m.regNo ? `(${m.regNo})` : ''}`.replace(/\s+/g, ' ').trim(),
    ENTRY_REACTIVATED: () => `Admin reactivated entry ${m.name || ''} ${m.regNo ? `(${m.regNo})` : ''}`.replace(/\s+/g, ' ').trim(),
    CASHIER_CREATED: () => `Admin created cashier ${m.username || ''} (level ${m.level || '?'})`,
    CASHIER_DEACTIVATED: () => `Admin deactivated cashier ${m.username || ''}`,
    CASHIER_REACTIVATED: () => `Admin reactivated cashier ${m.username || ''}`,
    CASHIER_LOGIN_SUCCESS: () => `Cashier ${who} logged in`,
    CASHIER_LOGIN_FAILURE: () => `Failed cashier login for "${who}"`,
    CASHIER_LOGOUT: () => `Cashier ${who} logged out`,
    CASHIER_USER_SEARCH: () => `Cashier ${who} looked up ${/^pin:/i.test(m.query || '') ? 'a scanned pin' : `"${m.query || ''}"`} (${m.resultCount || 0} found)`,
    CASHIER_USER_SEARCH_DENIED: () => `Cashier ${who} was blocked from looking up someone outside their department`,
    RECEIPT_ISSUED: () => `Cashier ${who} issued receipt ${m.receiptNo || log.targetReceiptId || ''} for ${naira(m.amount)}${m.purpose ? ` (${m.purpose})` : ''}`.replace(/\s+/g, ' ').trim(),
    RECEIPT_ISSUE_DENIED: () => `Cashier ${who} was blocked from issuing a receipt (${m.reason || 'not allowed'})`,
    RECEIPT_VIEW: () => `Admin viewed receipt ${m.receiptNo || ''}`.trim(),
    RECEIPT_VIEW_DENIED: () => `${who} was blocked from viewing a receipt`,
    RECEIPT_UPDATE: () => `Admin edited receipt ${m.receiptNo || ''}${fieldsChanged(m)}`.trim(),
    RECEIPT_DELETE: () => `Admin deleted receipt ${m.receiptNo || ''} (${naira(m.amount)}${m.purpose ? `, ${m.purpose}` : ''})`.replace(/\(\s*,/, '(').trim(),
    ATTENDANCE_MARKED: () => `Supervisor ${who} marked ${m.type || 'attendance'} for session "${m.session || ''}"`,
    ATTENDANCE_MARK_DENIED: () => `Supervisor ${who} was blocked from marking attendance (${m.reason || 'not allowed'})`,
    RESULT_SAVED: () => `Supervisor ${who} saved a result for ${m.regNo || 'an entry'} (${m.session || ''})`,
    RESULT_UPDATED: () => `Supervisor ${who} updated the result for ${m.regNo || 'an entry'} (${m.session || ''})`,
    RESULT_VIEW_DENIED: () => `Supervisor ${who} was blocked from viewing a result`,
    RESULT_ADMIN_REMARK: () => `Admin ${m.cleared ? 'cleared the remark on' : 'added a remark to'} the result for ${m.regNo || 'an entry'} (${m.session || ''})`,
    RESULT_DELETED: () => `Admin deleted the result for ${m.regNo || 'an entry'} (${m.session || ''})`,
    CASHIER_PAYOUT_REQUESTED: () => `Cashier ${who} requested a payout of ${naira(m.amount)}`,
    SUPERVISOR_PAYOUT_REQUESTED: () => `Supervisor ${who} requested a payout of ${naira(m.amount)}`,
    CASHIER_PAYOUT_APPROVED: () => `Admin approved ${m.requester || 'a cashier'}'s payout of ${naira(m.amount)}`,
    SUPERVISOR_PAYOUT_APPROVED: () => `Admin approved ${m.requester || 'a supervisor'}'s payout of ${naira(m.amount)}`,
    CASHIER_PAYOUT_REJECTED: () => `Admin rejected ${m.requester || 'a'} payout of ${naira(m.amount)}`,
    COMPLAINT_SUBMITTED: () => `${who} submitted a complaint${m.subject ? `: ${m.subject}` : ''}`,
    ENQUIRY_SUBMITTED: () => `${who} submitted an enquiry${m.subject ? `: ${m.subject}` : ''}`,
    COMPLAINT_STATUS_CHANGED: () => `Admin marked a complaint ${m.status || ''}${m.subject ? `: ${m.subject}` : ''}`.trim(),
    ENQUIRY_STATUS_CHANGED: () => `Admin marked an enquiry ${m.status || ''}${m.subject ? `: ${m.subject}` : ''}`.trim(),
    SELF_LOGIN: () => `${who} logged in with their pin`,
    SELF_LOGIN_FAILED: () => `Wrong pin entered for ${who}`,
    SELF_LOGOUT: () => `${who} logged out`,
    SELF_PROFILE_CREATED: () => `${who} filled in their profile`,
    SELF_PROFILE_UPDATED: () => `${who} edited their profile${fieldsChanged(m)}`,
    SELF_ENQUIRY_SENT: () => `${who} sent an enquiry${m.subject ? `: ${m.subject}` : ''}`,
    SELF_COMPLAINT_SENT: () => `${who} sent a complaint${m.subject ? `: ${m.subject}` : ''}`,
  };
  try {
    const fn = S[log.action];
    if (fn) return fn();
  } catch (e) { /* fall through to the generic line */ }
  return `${who}: ${String(log.action || '').toLowerCase().replace(/_/g, ' ')}`;
}

module.exports = { describeLog };
