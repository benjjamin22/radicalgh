// Payment provider webhooks. Mounted in app.js BEFORE the /:pin catch-all
// ("webhooks" would otherwise match the pin pattern).
//
// The signature is checked against the RAW body, so this route uses
// express.raw() and must not sit behind a JSON parser.
const express = require('express');
const { isValidSignature } = require('../utils/paystack');
const { finalizePayment } = require('../utils/onlinePayment');

const router = express.Router();

router.post('/paystack', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
  try {
    if (!isValidSignature(req.body, req.headers['x-paystack-signature'])) return res.sendStatus(401);

    const event = JSON.parse(req.body.toString('utf8'));
    if (event.event === 'charge.success' && event.data && event.data.reference) {
      // Do the work BEFORE replying: on a serverless host the function can be
      // frozen the moment the response is sent. A 500 makes Paystack retry.
      await finalizePayment(event.data.reference);
    }
    res.sendStatus(200);
  } catch (err) {
    console.error('Paystack webhook error', err);
    res.sendStatus(500);
  }
});

module.exports = router;
