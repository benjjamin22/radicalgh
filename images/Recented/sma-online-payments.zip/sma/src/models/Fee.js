const mongoose = require('mongoose');

// A fee the school charges (tuition, exam fee, ...). Set by admin only.
// `department` empty means the fee applies to every department; otherwise
// only entries in that department are asked to pay it. What a student has
// already paid toward a fee is NOT stored here — it is always the sum of
// their receipts linked to this fee, so cash receipts from a cashier and
// online receipts count toward the same balance automatically.
const feeSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 120 },
    amount: { type: Number, required: true, min: 1 },
    department: { type: String, trim: true, default: '', maxlength: 100, index: true },
    // 0 = any amount is allowed for a part payment (up to the balance).
    minInstallment: { type: Number, default: 0, min: 0 },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Fee', feeSchema);
