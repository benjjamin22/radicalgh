const mongoose = require('mongoose');

// One document per admin/supervisor action. Nothing here is ever
// updated or deleted by the app itself — it's an append-only trail.
// `before`/`after` hold only the fields that actually changed on an
// UPDATE action (see routes/supervisor.js), not a full entry snapshot,
// to keep log documents small.
const auditLogSchema = new mongoose.Schema(
  {
    actorType: { type: String, required: true, enum: ['admin', 'supervisor', 'cashier', 'entry'] },
    // For a supervisor/cashier actor: their _id and username. For the
    // shared admin login there's no per-admin account, so actorId stays
    // empty and actorLabel is just "admin".
    actorId: { type: String, trim: true, default: '' },
    actorLabel: { type: String, trim: true, default: '' },
    level: { type: Number, default: null }, // 1, 2, or null for admin actions

    action: {
      type: String,
      required: true,
      enum: [
        'ADMIN_LOGIN_SUCCESS',
        'ADMIN_LOGIN_FAILURE',
        'ADMIN_LOGOUT',
        'SUPERVISOR_CREATED',
        'SUPERVISOR_DEACTIVATED',
        'SUPERVISOR_REACTIVATED',
        'SUPERVISOR_LOGIN_SUCCESS',
        'SUPERVISOR_LOGIN_FAILURE',
        'SUPERVISOR_LOGOUT',
        'ENTRY_SEARCH',
        'ENTRY_VIEW',
        'ENTRY_VIEW_DENIED',
        'ENTRY_UPDATE',
        'ENTRY_UPDATE_DENIED',
        'ENTRY_DELETE',
        'CASHIER_CREATED',
        'CASHIER_DEACTIVATED',
        'CASHIER_REACTIVATED',
        'CASHIER_LOGIN_SUCCESS',
        'CASHIER_LOGIN_FAILURE',
        'CASHIER_LOGOUT',
        'CASHIER_USER_SEARCH',
        'CASHIER_USER_SEARCH_DENIED',
        'RECEIPT_ISSUED',
        'RECEIPT_ISSUE_DENIED',
        'RECEIPT_VIEW',
        'RECEIPT_VIEW_DENIED',
        'RECEIPT_UPDATE',
        'RECEIPT_DELETE',
        'ATTENDANCE_MARKED',
        'ATTENDANCE_MARK_DENIED',
        'RESULT_SAVED',
        'RESULT_UPDATED',
        'RESULT_VIEW_DENIED',
        'RESULT_ADMIN_REMARK',
        'RESULT_DELETED',
        'CASHIER_PAYOUT_REQUESTED',
        'SUPERVISOR_PAYOUT_REQUESTED',
        'COMPLAINT_SUBMITTED',
        // These were already being logged by the routes but were missing from
        // this list, so the database rejected them and they silently never saved.
        'ENQUIRY_SUBMITTED',
        'COMPLAINT_STATUS_CHANGED',
        'ENQUIRY_STATUS_CHANGED',
        'CASHIER_PAYOUT_APPROVED',
        'SUPERVISOR_PAYOUT_APPROVED',
        'CASHIER_PAYOUT_REJECTED',
        'ENTRY_DEACTIVATED',
        'ENTRY_REACTIVATED',
        // Pin holders (entries) acting on their own profile.
        'SELF_LOGIN',
        'SELF_LOGIN_FAILED',
        'SELF_LOGOUT',
        'SELF_PROFILE_CREATED',
        'SELF_PROFILE_UPDATED',
        'SELF_ENQUIRY_SENT',
        'SELF_COMPLAINT_SENT',
        'FEE_CREATED',
        'FEE_TOGGLED',
        'ONLINE_PAYMENT_STARTED',
        'ONLINE_PAYMENT_CONFIRMED',
        'ONLINE_PAYMENT_REJECTED',
      ],
    },

    targetEntryId: { type: String, trim: true, default: '' },
    targetPin: { type: String, trim: true, default: '' },
    targetReceiptId: { type: String, trim: true, default: '' },
    department: { type: String, trim: true, default: '' },

    // Free-form details specific to the action — e.g. { query } for a
    // search, or { changed: { name: { from, to }, ... } } for an update.
    meta: { type: mongoose.Schema.Types.Mixed, default: {} },

    ip: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

auditLogSchema.index({ createdAt: -1 });

// Append-only: once written, a log entry can never be changed or removed
// through the app. Any attempt to update, replace or delete one (by any code,
// any role) is refused here, at the model level. Creating new entries
// (AuditLog.create in utils/logger.js) and reading them is unaffected.
const APPEND_ONLY_MSG = 'Audit logs are append-only and cannot be changed or deleted.';
auditLogSchema.pre(
  ['updateOne', 'updateMany', 'replaceOne', 'findOneAndUpdate', 'findOneAndReplace', 'findOneAndDelete', 'deleteOne', 'deleteMany', 'bulkWrite'],
  { document: true, query: true },
  function blockAuditLogChange(next) {
    next(new Error(APPEND_ONLY_MSG));
  },
);
auditLogSchema.pre('save', function blockAuditLogResave(next) {
  if (!this.isNew) return next(new Error(APPEND_ONLY_MSG));
  next();
});

module.exports = mongoose.model('AuditLog', auditLogSchema);
