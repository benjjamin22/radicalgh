const mongoose = require('mongoose');

// One document per online payment attempt. It is created BEFORE the
// student is sent to the payment provider (status "pending") and only
// becomes a Receipt once the provider's confirmation has been verified.
// "processing" is a short-lived claim so the browser callback and the
// provider webhook can never both create a receipt for the same payment.
const paymentSchema = new mongoose.Schema(
  {
    reference: { type: String, required: true, unique: true, index: true },
    provider: { type: String, default: 'paystack' },
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry', required: true, index: true },
    fee: { type: mongoose.Schema.Types.ObjectId, ref: 'Fee', required: true },
    amount: { type: Number, required: true, min: 1 },
    email: { type: String, trim: true, default: '' },
    status: { type: String, enum: ['pending', 'processing', 'success', 'failed'], default: 'pending', index: true },
    receipt: { type: mongoose.Schema.Types.ObjectId, ref: 'Receipt', default: null },
    note: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Payment', paymentSchema);
