const mongoose = require('mongoose');

// A receipt is created by a cashier against one Entry ("user"). Cashiers
// can only ever CREATE and READ-THEIR-OWN receipts (enforced in
// routes/cashier.js, not just hidden in the UI); only an admin can
// update or delete one (routes/admin.js), which is why this schema has
// no soft-delete/void flag of its own — deletion is a real admin CRUD
// operation, logged like everything else.
const receiptSchema = new mongoose.Schema(
  {
    receiptNo: { type: String, required: true, unique: true, trim: true, uppercase: true, index: true },

    // The user (Entry) the receipt was issued to. Kept as a ref so the
    // live record can always be looked up, plus a denormalized snapshot
    // of the three fields a cashier is allowed to see, so a receipt
    // still reads sensibly even if the entry is later edited/removed.
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry', required: true },
    entryRegNo: { type: String, trim: true, required: true, maxlength: 40 },
    entryName: { type: String, trim: true, required: true, maxlength: 200 },
    // Also the scope field: level-2 cashiers may only issue against (and
    // only ever see) receipts whose department matches their own.
    department: { type: String, trim: true, required: true, maxlength: 100, index: true },

    amount: { type: Number, required: true, min: 0.01 },
    purpose: { type: String, trim: true, required: true, maxlength: 300 },

    // Cash receipts are issued by a cashier. Online receipts (source
    // "online") have no cashier, so these three are only required for
    // cashier receipts.
    cashier: { type: mongoose.Schema.Types.ObjectId, ref: 'Cashier', index: true, required: function () { return this.source !== 'online'; } },
    cashierUsername: { type: String, trim: true, maxlength: 60, default: '', required: function () { return this.source !== 'online'; } },
    cashierLevel: { type: Number, enum: [1, 2], required: function () { return this.source !== 'online'; } },

    // Which fee this payment counts toward (drives the balance). Older
    // receipts have none and simply don't count toward any fee balance.
    fee: { type: mongoose.Schema.Types.ObjectId, ref: 'Fee', default: null, index: true },
    source: { type: String, enum: ['cashier', 'online'], default: 'cashier' },
    // Payment provider reference. Unique, so a repeated webhook can never
    // create a second receipt for the same payment.
    reference: { type: String, trim: true, unique: true, sparse: true },
  },
  { timestamps: true }
);

receiptSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Receipt', receiptSchema);
