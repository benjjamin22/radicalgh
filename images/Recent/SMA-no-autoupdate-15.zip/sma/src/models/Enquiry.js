const mongoose = require('mongoose');

// A general enquiry raised by a cashier, a supervisor, or an entry owner
// (from their public profile page). Deliberately minimal, mirroring
// Complaint.js: who raised it, subject, message, and its status.
const enquirySchema = new mongoose.Schema(
  {
    raisedByType: { type: String, enum: ['supervisor', 'cashier', 'entry'], required: true },
    supervisor: { type: mongoose.Schema.Types.ObjectId, ref: 'Supervisor' },
    supervisorUsername: { type: String, trim: true, default: '' },
    cashier: { type: mongoose.Schema.Types.ObjectId, ref: 'Cashier' },
    cashierUsername: { type: String, trim: true, default: '' },
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry' },
    entryName: { type: String, trim: true, default: '' },
    department: { type: String, trim: true, default: '' },
    subject: { type: String, required: true, trim: true, maxlength: 120 },
    message: { type: String, required: true, trim: true, maxlength: 1000 },
    status: { type: String, enum: ['Open', 'Resolved'], default: 'Open' },
  },
  { timestamps: true }
);

enquirySchema.index({ createdAt: -1 });

module.exports = mongoose.model('Enquiry', enquirySchema);
