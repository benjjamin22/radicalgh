const mongoose = require('mongoose');

// A complaint a supervisor raises with admin. Deliberately minimal —
// subject, message, who raised it, and its status — mirroring how
// CashierPayout keeps a money request simple.
const complaintSchema = new mongoose.Schema(
  {
    // Who raised it. Kept backward compatible: existing supervisor
    // complaints didn't record this field and default to 'supervisor'.
    raisedByType: { type: String, enum: ['supervisor', 'cashier', 'entry'], default: 'supervisor' },
    supervisor: { type: mongoose.Schema.Types.ObjectId, ref: 'Supervisor' },
    supervisorUsername: { type: String, trim: true, default: '' },
    cashier: { type: mongoose.Schema.Types.ObjectId, ref: 'Cashier' },
    cashierUsername: { type: String, trim: true, default: '' },
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry' },
    entryName: { type: String, trim: true, default: '' },
    department: { type: String, trim: true, default: '' },
    subject: { type: String, required: true, trim: true, maxlength: 120 },
    message: { type: String, required: true, trim: true, maxlength: 1000 },
    status: { type: String, enum: ['Open', 'Resolved'], default: 'Open' },
  },
  { timestamps: true }
);

complaintSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Complaint', complaintSchema);
