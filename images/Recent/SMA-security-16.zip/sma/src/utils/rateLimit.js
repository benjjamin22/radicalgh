// Brute-force protection for logins and pin guessing. Counters live in
// MongoDB (models/LoginAttempt) because this app runs serverless — an
// in-memory counter would reset on every cold start and differ per instance.
//
// Design rules so this can never become the thing that breaks the app:
//   - It FAILS OPEN: any database error here is logged and the request
//     carries on as if nothing was limited. A broken counter must never
//     lock legitimate people out.
//   - Only FAILED attempts count. A correct login clears the counter.
//   - Nothing here ever throws.

const LoginAttempt = require('../models/LoginAttempt');

// Vercel sits in front of the app, so req.ip is the proxy, not the visitor.
// Its forwarded-for header is set by Vercel itself (a client can't spoof it
// there); locally it just falls back to the socket address.
function clientIp(req) {
  const fwd = req.headers['x-vercel-forwarded-for'] || req.headers['x-forwarded-for'] || '';
  const first = String(fwd).split(',')[0].trim();
  return first || req.ip || (req.socket && req.socket.remoteAddress) || 'unknown';
}

// Seconds left on a lock for `key`, or 0 when not locked.
async function lockedSeconds(key) {
  try {
    const doc = await LoginAttempt.findOne({ key }).lean();
    if (!doc || !doc.lockedUntil) return 0;
    const left = Math.ceil((new Date(doc.lockedUntil).getTime() - Date.now()) / 1000);
    return left > 0 ? left : 0;
  } catch (err) {
    console.error('rateLimit.lockedSeconds failed (allowing request)', err.message);
    return 0;
  }
}

// Count one failed attempt; lock the key once it reaches `max` within `windowMs`.
async function recordFailure(key, { max, windowMs, lockMs }) {
  try {
    const now = Date.now();
    const bumped = await LoginAttempt.findOneAndUpdate(
      { key, expiresAt: { $gt: new Date(now) } },
      { $inc: { count: 1 } },
      { new: true },
    ).lean();

    if (!bumped) {
      // No live counter yet (first failure, or the old one expired).
      try {
        await LoginAttempt.findOneAndUpdate(
          { key },
          { $set: { count: 1, lockedUntil: null, expiresAt: new Date(now + windowMs) } },
          { upsert: true },
        );
      } catch (err) {
        if (!(err && err.code === 11000)) throw err; // lost a harmless race
      }
      return;
    }

    if (bumped.count >= max && !bumped.lockedUntil) {
      const until = new Date(now + lockMs);
      await LoginAttempt.updateOne({ key }, { $set: { lockedUntil: until, expiresAt: until } });
    }
  } catch (err) {
    console.error('rateLimit.recordFailure failed (ignored)', err.message);
  }
}

async function clearAttempts(key) {
  try {
    await LoginAttempt.deleteOne({ key });
  } catch (err) {
    console.error('rateLimit.clearAttempts failed (ignored)', err.message);
  }
}

function waitText(seconds) {
  const mins = Math.max(1, Math.ceil(seconds / 60));
  return `${mins} minute${mins === 1 ? '' : 's'}`;
}

module.exports = { clientIp, lockedSeconds, recordFailure, clearAttempts, waitText };
