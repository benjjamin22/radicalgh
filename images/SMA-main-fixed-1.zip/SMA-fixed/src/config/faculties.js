// Static faculty -> departments map.
//
// This is intentionally a plain JS object rather than a DB collection —
// faculties/departments change rarely, so keeping them here avoids an
// extra model and extra queries. If you later want admins to manage this
// list themselves, move it into its own Mongoose model and load it once
// at startup instead.
//
// NOTE: the specific faculty/department names below are placeholders —
// edit this file to match your institution's real structure. Every name
// here is what gets stored on an Entry and what the cascading dropdown
// in the form is built from, so keep it in sync with the UI copy.

module.exports = {
  'Engineering': [
    'Chemical Engineering',
    'Mechanical Engineering',
    'Electrical Engineering',
    'Civil Engineering',
    'Computer Engineering',
  ],
  'Sciences': [
    'Physics',
    'Chemistry',
    'Biology',
    'Mathematics',
    'Computer Science',
  ],
  'Arts and Humanities': [
    'English',
    'History',
    'Philosophy',
    'Linguistics',
  ],
  'Social Sciences': [
    'Economics',
    'Political Science',
    'Sociology',
    'Psychology',
  ],
  'Law': [
    'Public Law',
    'Private Law',
    'Commercial Law',
  ],
  'Management Sciences': [
    'Accounting',
    'Business Administration',
    'Marketing',
    'Banking and Finance',
  ],
};
