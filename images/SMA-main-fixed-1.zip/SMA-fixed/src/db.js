const mongoose = require('mongoose');

// Serverless functions (Vercel) can reuse a warm container between requests,
// but every cold start would otherwise open a brand new MongoDB connection.
// Caching the connection on `global` means warm invocations reuse it instead
// of piling up new connections until MongoDB Atlas rejects them.
let cached = global.__mongooseConn;
if (!cached) {
  cached = global.__mongooseConn = { conn: null, promise: null };
}

async function connectDB() {
  if (cached.conn) return cached.conn;

  if (!cached.promise) {
    const uri = process.env.MONGODB_URI;
    if (!uri) {
      throw new Error('MONGODB_URI is not set. Copy .env.example to .env and fill it in.');
    }

    mongoose.set('strictQuery', true);
    cached.promise = mongoose.connect(uri).then((m) => {
      console.log('MongoDB connected');
      return m;
    });
  }

  cached.conn = await cached.promise;
  return cached.conn;
}

module.exports = { connectDB };
