require('dotenv').config();
const path = require('path');
const express = require('express');
const methodOverride = require('method-override');
const cookieParser = require('cookie-parser');
const { connectDB } = require('./db');
const homeRoutes = require('./routes/home');
const pinRoutes = require('./routes/pin');
const adminRoutes = require('./routes/admin');
const supervisorRoutes = require('./routes/supervisor');
const cashierRoutes = require('./routes/cashier');
const entryProfileRoutes = require('./routes/entryProfile');

const app = express();

// -------------------- VIEWS --------------------
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// -------------------- MIDDLEWARE --------------------
app.use(express.urlencoded({ extended: true })); // parse HTML <form> submissions
// Reads ?_method=PUT/DELETE from the query string rather than the body.
// The edit/delete forms submit as multipart/form-data (photo upload), and
// multipart bodies aren't parsed until multer runs further down the
// route-specific middleware chain — a body-based override would run too
// early to see it. Query-string override works for any encoding.
app.use(methodOverride((req) => (req.query && req.query._method) || undefined));
// Auth state lives in a signed JWT cookie (see src/utils/auth.js) — this
// is the only reason we need cookie parsing; there is no session store.
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/health', (req, res) => res.json({ ok: true }));

// Ensure the DB connection is ready before any route touches it. connectDB()
// is cached (see src/db.js), so on a warm serverless invocation this
// resolves immediately instead of reconnecting.
app.use(async (req, res, next) => {
  try {
    await connectDB();
    next();
  } catch (err) {
    next(err);
  }
});

app.use('/', homeRoutes);
// Admin/supervisor/cashier/entry routes are mounted BEFORE the /:pin
// catch-all so "admin", "supervisor", "cashier", and "entry" are
// effectively reserved words: a request to /admin/..., /supervisor/...,
// /cashier/..., or /entry/... is always handled here first and never
// falls through to being interpreted as someone's pin. One consequence:
// a pin literally equal to any of these four can never be issued/used —
// reserve those codes when generating pins.
app.use('/admin', adminRoutes);
app.use('/supervisor', supervisorRoutes);
app.use('/cashier', cashierRoutes);
app.use('/entry', entryProfileRoutes);
// :pin is the entry point into the app. GET checks the pin against the
// database and routes to the form, the view, or a "doesn't exist" page.
app.use('/:pin([a-zA-Z0-9]{4,10})', pinRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).render('404');
});

// Central error handler (catches anything thrown/passed to next())
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).render('error', { message: err.message || 'Server error' });
});

// -------------------- EXPORT --------------------
module.exports = app;
