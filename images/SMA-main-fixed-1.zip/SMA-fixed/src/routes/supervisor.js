const express = require('express');
const mongoose = require('mongoose');
const Supervisor = require('../models/Supervisor');
const CashierPayout = require('../models/CashierPayout');
const Entry = require('../models/Entry');
const { isPlainString, sanitizeText } = require('../utils/sanitize');
const { verifyPassword } = require('../utils/password');
const {
  setSupervisorCookie,
  clearSupervisorCookie,
  requireSupervisor,
} = require('../utils/adminAuth');
const { logAction } = require('../utils/logger');

const router = express.Router();

// Same reasoning as routes/pin.js, routes/admin.js and routes/cashier.js:
// once a supervisor logs out, every supervisor page must be re-fetched
// and re-checked, not served from the browser's back/forward cache.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

const RESULTS_PER_PAGE = 20;
const MAX_AMOUNT = 100000000;
const AMOUNT_PATTERN = /^\d{1,9}(\.\d{1,2})?$/;

// Escapes regex metacharacters so a search term is used as literal text,
// never as an arbitrary regex (which could be used for a ReDoS attack
// via a submitted query string).
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// -------------------- LOGIN / LOGOUT --------------------

router.get('/login', (req, res) => {
  res.render('supervisor/login', { error: null });
});

router.post('/login', async (req, res, next) => {
  try {
    const body = req.body || {};
    if (!isPlainString(body.username) || !isPlainString(body.password)) {
      return res.status(400).render('supervisor/login', { error: 'Invalid submission.' });
    }

    const username = sanitizeText(body.username).toLowerCase();
    const password = body.password;

    const supervisor = await Supervisor.findOne({ username });
    const passwordOk = supervisor ? await verifyPassword(password, supervisor.passwordHash) : false;

    if (!supervisor || !supervisor.active || !passwordOk) {
      await logAction(req, {
        actorType: 'supervisor',
        actorLabel: username,
        action: 'SUPERVISOR_LOGIN_FAILURE',
      });
      return res.status(401).render('supervisor/login', { error: 'Incorrect username or password.' });
    }

    setSupervisorCookie(res, {
      supervisorId: supervisor._id.toString(),
      username: supervisor.username,
      level: supervisor.level,
      department: supervisor.department,
    });

    await logAction(req, {
      actorType: 'supervisor',
      actorId: supervisor._id.toString(),
      actorLabel: supervisor.username,
      level: supervisor.level,
      department: supervisor.department,
      action: 'SUPERVISOR_LOGIN_SUCCESS',
    });

    res.redirect('/supervisor');
  } catch (err) {
    next(err);
  }
});

router.post('/logout', requireSupervisor, async (req, res, next) => {
  try {
    clearSupervisorCookie(res);
    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level: req.supervisor.level,
      department: req.supervisor.department,
      action: 'SUPERVISOR_LOGOUT',
    });
    res.redirect('/supervisor/login');
  } catch (err) {
    next(err);
  }
});

// -------------------- SEARCH DASHBOARD --------------------
// Level 1: searches the entire Entry collection.
// Level 2: the department filter is always forced to the supervisor's
// own department, regardless of anything else submitted — this is what
// actually enforces the department-only scope, not just the UI.
//
// A supervisor is READ-ONLY everywhere in this file: there is no
// update or delete route here at all. Only /admin/entries can change or
// remove an entry — see routes/admin.js.
router.get('/', requireSupervisor, async (req, res, next) => {
  try {
    const { level, department } = req.supervisor;
    const rawQuery = isPlainString(req.query.q) ? req.query.q : '';
    const q = sanitizeText(rawQuery).slice(0, 100);
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);

    const filter = {};
    if (level === 2) {
      filter.department = department;
    }
    if (q) {
      const re = new RegExp(escapeRegex(q), 'i');
      filter.$or = [{ firstName: re }, { middleName: re }, { surname: re }, { regNo: re }, { pin: re }, { phone: re }];
    }

    const [entries, total] = await Promise.all([
      Entry.find(filter)
        .sort({ surname: 1, firstName: 1 })
        .skip((page - 1) * RESULTS_PER_PAGE)
        .limit(RESULTS_PER_PAGE)
        .lean(),
      Entry.countDocuments(filter),
    ]);

    if (q) {
      await logAction(req, {
        actorType: 'supervisor',
        actorId: req.supervisor.supervisorId,
        actorLabel: req.supervisor.username,
        level,
        department: level === 2 ? department : '',
        action: 'ENTRY_SEARCH',
        meta: { query: q },
      });
    }

    const payoutRequests = await CashierPayout.find({
      requesterType: 'supervisor',
      supervisor: req.supervisor.supervisorId,
    }).sort({ createdAt: -1 }).limit(10).lean();

    res.render('supervisor/dashboard', {
      supervisor: req.supervisor,
      entries,
      q,
      page,
      totalPages: Math.max(1, Math.ceil(total / RESULTS_PER_PAGE)),
      payoutRequests,
      error: null,
    });
  } catch (err) {
    next(err);
  }
});

// Shared authorization: level 1 may view any entry; level 2 only an
// entry in their own department. Used by the read-only view route below.
async function loadAuthorizedEntry(req, res) {
  const { id } = req.params;
  if (!mongoose.isValidObjectId(id)) {
    res.status(404).render('404');
    return null;
  }

  const entry = await Entry.findById(id).lean();
  if (!entry) {
    res.status(404).render('404');
    return null;
  }

  const { level, department } = req.supervisor;
  if (level === 2 && entry.department !== department) {
    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level,
      department,
      action: 'ENTRY_VIEW_DENIED',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
      meta: { reason: 'department mismatch', entryDepartment: entry.department },
    });
    res.status(403).render('error', { message: 'You are not authorized to view this entry.' });
    return null;
  }

  return entry;
}

// -------------------- MONEY / ADMIN APPROVAL REQUESTS --------------------
// Supervisors may send money approval requests to admin. These requests are
// kept separate from cashier receipt balances because supervisors do not
// issue receipts themselves.
router.post('/payout-requests', requireSupervisor, async (req, res, next) => {
  try {
    const body = req.body || {};
    const amountRaw = isPlainString(body.amount) ? sanitizeText(body.amount) : '';
    const reason = isPlainString(body.reason) ? sanitizeText(body.reason).slice(0, 300) : '';
    if (!AMOUNT_PATTERN.test(amountRaw)) return res.status(400).redirect('/supervisor');
    const amount = Number(amountRaw);
    if (!(amount > 0) || amount > MAX_AMOUNT) return res.status(400).redirect('/supervisor');

    const payout = await CashierPayout.create({
      requesterType: 'supervisor',
      supervisor: req.supervisor.supervisorId,
      requesterUsername: req.supervisor.username,
      amount,
      reason,
      status: 'Pending',
    });

    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level: req.supervisor.level,
      department: req.supervisor.department,
      action: 'SUPERVISOR_PAYOUT_REQUESTED',
      meta: { payoutId: payout._id.toString(), amount, reason },
    });
    res.redirect('/supervisor');
  } catch (err) { next(err); }
});

// -------------------- VIEW (READ-ONLY) --------------------
// Supervisors can look, never touch: there is deliberately no PUT/DELETE
// route in this file. Only an admin can edit or delete an entry — see
// the "/admin/entries" section of routes/admin.js.
router.get('/entry/:id', requireSupervisor, async (req, res, next) => {
  try {
    const entry = await loadAuthorizedEntry(req, res);
    if (!entry) return;

    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level: req.supervisor.level,
      department: entry.department,
      action: 'ENTRY_VIEW',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
    });

    res.render('supervisor/view', {
      supervisor: req.supervisor,
      entry,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
