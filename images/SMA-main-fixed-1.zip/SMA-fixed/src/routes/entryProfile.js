// GET/POST /entry/:id — a public, database-_id-addressed profile page.
//
// This is deliberately the ONLY way to reach another pin holder's full
// profile (name, faculty, department, contact details — everything
// except payments) without knowing their pin. It is intentionally a
// dead-end, read-only page: it never renders any pin-section screen
// (edit, department listing, payments) and never even looks at the
// pin-section auth cookie. Its only interactive element is a "enter
// your pin" hand-off — on success it hands the visitor over to the pin
// section entirely (redirects to /:pin/profile) rather than absorbing
// any pin-section behaviour into itself. See src/views/entry/view.ejs,
// which is its own standalone template with no shared partial.
//
// Mounted at /entry in app.js, ahead of the /:pin catch-all — same
// reservation trick as /admin, /supervisor, /cashier: "entry" can never
// be issued as a pin.
const express = require('express');
const mongoose = require('mongoose');
const Entry = require('../models/Entry');
const { setAuthCookie } = require('../utils/auth');
const { isPlainString, sanitizeText } = require('../utils/sanitize');

function normalizeEntryPhoto(entry) {
  if (!entry) return entry;
  if (entry.photoUrl) return entry;
  if (entry.photoId) {
    entry.photoUrl = `https://drive.google.com/thumbnail?id=${encodeURIComponent(entry.photoId)}&sz=w1000`;
  }
  return entry;
}

const router = express.Router();

async function loadEntry(id) {
  if (!mongoose.isValidObjectId(id)) return null;
  const entry = await Entry.findById(id).lean();
  if (!entry || entry.active === false) return null;
  return normalizeEntryPhoto(entry);
}

router.get('/:id', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('404');
    }
    res.render('entry/view', { entry, error: null });
  } catch (err) {
    next(err);
  }
});

router.post('/:id', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('404');
    }

    const body = req.body || {};
    if (!isPlainString(body.pin)) {
      return res.status(400).render('entry/view', { entry, error: 'Enter a valid pin.' });
    }

    const attempt = sanitizeText(body.pin);
    if (!attempt || attempt !== entry.pin) {
      return res.status(400).render('entry/view', { entry, error: 'Incorrect pin.' });
    }

    setAuthCookie(res, {
      pin: entry.pin,
      entryId: entry._id.toString(),
      department: entry.department,
      faculty: entry.faculty,
    });

    // Hand off to the pin section entirely — this route's job ends here.
    res.redirect(`/${entry.pin}/profile`);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
