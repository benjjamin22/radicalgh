// Auth for the /admin and /supervisor areas. Same pattern as
// utils/auth.js (signed JWT in an httpOnly cookie, no server-side
// session store) but kept in a separate file/cookie namespace since
// these are a different trust boundary from the public pin-holder auth:
//   - admin_token: proves the shared admin password was entered.
//   - supervisor_token: proves a specific Supervisor account logged in;
//     carries { supervisorId, username, level, department } so every
//     request can re-check scope without a DB round trip.

const jwt = require('jsonwebtoken');
const Supervisor = require('../models/Supervisor');
const Cashier = require('../models/Cashier');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error('JWT_SECRET is not set. Add it to your .env file.');
}

const ADMIN_COOKIE = 'admin_token';
const SUPERVISOR_COOKIE = 'supervisor_token';
const CASHIER_COOKIE = 'cashier_token';
const TOKEN_TTL = '8h';
const COOKIE_MAX_AGE_MS = 8 * 60 * 60 * 1000;

function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: COOKIE_MAX_AGE_MS,
  };
}

// -------------------- ADMIN --------------------

function setAdminCookie(res) {
  const token = jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: TOKEN_TTL });
  res.cookie(ADMIN_COOKIE, token, cookieOptions());
}

function getAdminAuth(req) {
  const token = req.cookies && req.cookies[ADMIN_COOKIE];
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded.role === 'admin' ? decoded : null;
  } catch (err) {
    return null;
  }
}

function clearAdminCookie(res) {
  res.clearCookie(ADMIN_COOKIE);
}

// Redirects to the login form instead of a bare 401/403 so a supervisor
// clicking a stale bookmark just gets sent to sign in again.
function requireAdmin(req, res, next) {
  const auth = getAdminAuth(req);
  if (!auth) return res.redirect('/admin/login');
  req.admin = auth;
  next();
}

// -------------------- SUPERVISOR --------------------

function setSupervisorCookie(res, payload) {
  const token = jwt.sign({ role: 'supervisor', ...payload }, JWT_SECRET, { expiresIn: TOKEN_TTL });
  res.cookie(SUPERVISOR_COOKIE, token, cookieOptions());
}

function getSupervisorAuth(req) {
  const token = req.cookies && req.cookies[SUPERVISOR_COOKIE];
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded.role === 'supervisor' ? decoded : null;
  } catch (err) {
    return null;
  }
}

function clearSupervisorCookie(res) {
  res.clearCookie(SUPERVISOR_COOKIE);
}

// Re-checks the live Supervisor record on every request (not just the
// JWT payload) so that an admin deactivating an account, or changing
// its level/department, takes effect immediately rather than waiting up
// to 8h for the token to expire.
async function requireSupervisor(req, res, next) {
  const auth = getSupervisorAuth(req);
  if (!auth) return res.redirect('/supervisor/login');
  try {
    const record = await Supervisor.findById(auth.supervisorId).lean();
    if (!record || !record.active) {
      clearSupervisorCookie(res);
      return res.redirect('/supervisor/login');
    }
    // Use the DB record as the source of truth for level/department,
    // ignoring whatever the (possibly stale) JWT payload says.
    req.supervisor = {
      supervisorId: record._id.toString(),
      username: record.username,
      level: record.level,
      department: record.department,
    };
    next();
  } catch (err) {
    next(err);
  }
}

// -------------------- CASHIER --------------------
// Same shape/philosophy as the SUPERVISOR block above, in its own cookie
// namespace so a cashier session and a supervisor session can't be
// confused with one another.

function setCashierCookie(res, payload) {
  const token = jwt.sign({ role: 'cashier', ...payload }, JWT_SECRET, { expiresIn: TOKEN_TTL });
  res.cookie(CASHIER_COOKIE, token, cookieOptions());
}

function getCashierAuth(req) {
  const token = req.cookies && req.cookies[CASHIER_COOKIE];
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded.role === 'cashier' ? decoded : null;
  } catch (err) {
    return null;
  }
}

function clearCashierCookie(res) {
  res.clearCookie(CASHIER_COOKIE);
}

// Re-checks the live Cashier record on every request (not just the JWT
// payload) so that an admin deactivating an account, or changing its
// level/department, takes effect immediately rather than waiting up to
// 8h for the token to expire — identical reasoning to requireSupervisor.
async function requireCashier(req, res, next) {
  const auth = getCashierAuth(req);
  if (!auth) return res.redirect('/cashier/login');
  try {
    const record = await Cashier.findById(auth.cashierId).lean();
    if (!record || !record.active) {
      clearCashierCookie(res);
      return res.redirect('/cashier/login');
    }
    req.cashier = {
      cashierId: record._id.toString(),
      username: record.username,
      level: record.level,
      department: record.department,
    };
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = {
  setAdminCookie,
  getAdminAuth,
  clearAdminCookie,
  requireAdmin,
  setSupervisorCookie,
  getSupervisorAuth,
  clearSupervisorCookie,
  requireSupervisor,
  setCashierCookie,
  getCashierAuth,
  clearCashierCookie,
  requireCashier,
  ADMIN_COOKIE,
  SUPERVISOR_COOKIE,
  CASHIER_COOKIE,
};
