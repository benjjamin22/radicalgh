// -------------------- GOOGLE DRIVE --------------------
// OAuth2 upload helper for profile photos.
// Required environment variables:
//   GOOGLE_CLIENT_ID
//   GOOGLE_CLIENT_SECRET
//   GOOGLE_REFRESH_TOKEN
// Optional:
//   GOOGLE_REDIRECT_URI
//   GOOGLE_DRIVE_FOLDER_ID

const { google } = require('googleapis');
const { PassThrough } = require('stream');


function getOAuth2Client() {

  const client = new google.auth.OAuth2(
    '299799989715-9j5t32aoriem1chgjkd1d91vleh9njni.apps.googleusercontent.com',
    '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',
    'https://developers.google.com/oauthplayground'
  );

  client.setCredentials({ refresh_token: '1//04SleHQlO68aLCgYIARAAGAQSNwF-L9IrZKYFd3YWazjkliZA_Z3tO98_P1q76Eb-_zLAugY-fN2A6M0kHNABfJL9OEnrB90YC3c' });

  return client;
}


function getDrive() {
  return google.drive({
    version: 'v3',
    auth: getOAuth2Client(),
  });
}

function makeFiveDigitName() {
  return Array.from({ length: 5 }, () => String(Math.floor(Math.random() * 9) + 1)).join('') + '.jpg';
}

async function uploadPhotoToDrive(buffer, filename, mimeType) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) {
    throw new Error('The uploaded photo is empty.');
  }

  const drive = getDrive();
  const bufferStream = new PassThrough();
  bufferStream.end(buffer);

  const fileMetadata = {
    name: makeFiveDigitName(),
    parents: ["10KpoRo-jHT62ko_7BNH9khxA2S_6GY42"],
  };

  const response = await drive.files.create({
    requestBody: fileMetadata,
    media: {
      mimeType: mimeType || 'image/jpeg',
      body: bufferStream,
    },
    fields: 'id,name,webViewLink,mimeType',
    supportsAllDrives: true,
  });

  const fileId = response.data && response.data.id;
  if (!fileId) {
    throw new Error('Google Drive did not return a file ID.');
  }

  // Make the image readable by the profile page without requiring the
  // visitor to sign in to the Google account that owns the Drive file.
  await drive.permissions.create({
    fileId,
    requestBody: {
      role: 'reader',
      type: 'anyone',
    },
    supportsAllDrives: true,
  });

  return {
    id: fileId,
    name: response.data.name || fileMetadata.name,
    url: `https://drive.google.com/thumbnail?id=${encodeURIComponent(fileId)}&sz=w1000`,
    webViewLink: response.data.webViewLink || `https://drive.google.com/file/d/${fileId}/view`,
  };
}

async function deletePhotoFromDrive(fileId) {
  if (!fileId) return;

  try {
    const drive = getDrive();
    await drive.files.delete({ fileId, supportsAllDrives: true });
  } catch (err) {
    console.error('Failed to delete Google Drive image:', fileId, err.message);
  }
}

module.exports = {
  uploadPhotoToDrive,
  deletePhotoFromDrive,
};
