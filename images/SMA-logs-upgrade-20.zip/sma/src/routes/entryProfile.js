// GET/POST /entry/:id — a public, database-_id-addressed profile page.
//
// This is deliberately the ONLY way to reach another pin holder's full
// profile (name, faculty, department, contact details) without knowing
// their pin. It is intentionally a dead-end, self-contained page: it
// never renders any pin-section screen (edit, department listing, the
// pin section's own payments page) and never hands the visitor off into
// the pin section. Entering the correct pin re-renders this same
// /entry/:id page, now showing the logged-in state (with a Log out
// button and a Payment History link); it does not redirect to
// /:pin/profile or anywhere else in the pin section. Payment history for
// the logged-in owner is served by this section's own /entry/:id/payments
// route below — a separate, self-contained page, not the pin section's
// /:pin/profile/payments. Logging out from either page here (POST
// /:pin/logout with from=entry, see routes/pin.js) lands back on this
// same /entry/:id page. The pin section, this entry page, and admin are
// kept deliberately separate — none of the three ever redirects a
// visitor into either of the others. See src/views/entry/view.ejs and
// src/views/entry/payments.ejs, which are their own standalone
// templates with no shared partial with the pin section.
//
// Mounted at /entry in app.js, ahead of the /:pin catch-all — same
// reservation trick as /admin, /supervisor, /cashier: "entry" can never
// be issued as a pin.
const express = require('express');
const mongoose = require('mongoose');
const Entry = require('../models/Entry');
const Receipt = require('../models/Receipt');
const Attendance = require('../models/Attendance');
const Result = require('../models/Result');
const Enquiry = require('../models/Enquiry');
const Complaint = require('../models/Complaint');
const { setAuthCookie, getAuth } = require('../utils/auth');
const { isPlainString, sanitizeText } = require('../utils/sanitize');
const { resolvePhotoUrl } = require('../utils/photo');
const { clientIp, lockedSeconds, recordFailure, clearAttempts, waitText } = require('../utils/rateLimit');
const { logSelf } = require('../utils/logger');

// Always rebuild the photo URL from the permanent photoId (see
// utils/photo.js) rather than trusting a possibly-stale stored value.
function normalizeEntryPhoto(entry) {
  if (!entry) return entry;
  entry.photoUrl = resolvePhotoUrl(entry);
  return entry;
}

const router = express.Router();

// Same reasoning as routes/pin.js and the other route files: this page's
// "Log out" button (shown when the visitor is viewing their own entry
// while logged in) changes what's rendered, so the page must be
// re-fetched rather than repainted from the browser's back/forward
// cache once that state has changed.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

async function loadEntry(id) {
  if (!mongoose.isValidObjectId(id)) return null;
  const entry = await Entry.findById(id).lean();
  if (!entry || entry.active === false) return null;
  return normalizeEntryPhoto(entry);
}

router.get('/:id', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('entry/not-found');
    }
    const auth = getAuth(req);
    const loggedInPin = auth && String(auth.entryId) === String(entry._id) ? auth.pin : '';
    // A wrong pin is a redirect back here (post/redirect/get) so the page
    // can be refreshed or cancelled cleanly instead of re-submitting.
    const pinError = req.query.pinerr === 'invalid' ? 'Enter a valid pin.'
      : req.query.pinerr === 'wrong' ? 'Incorrect pin.'
      : req.query.pinerr === 'locked' ? 'Too many wrong attempts. Please wait a few minutes and try again.' : null;

    // Payments and Attendance Log tabs are only ever populated for the
    // entry's own owner (same ownership check as the standalone
    // /entry/:id/payments route below) — everyone else just sees the
    // Info tab, same as before this page had tabs at all.
    let paymentHistory = [];
    let attendanceLog = [];
    let resultsForEntry = [];
    let entryEnquiries = [];
    let entryComplaints = [];
    if (loggedInPin) {
      [paymentHistory, attendanceLog, resultsForEntry, entryEnquiries, entryComplaints] = await Promise.all([
        Receipt.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
        Attendance.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
        Result.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
        Enquiry.find({ entry: entry._id }).sort({ createdAt: -1 }).limit(50).lean(),
        Complaint.find({ entry: entry._id }).sort({ createdAt: -1 }).limit(50).lean(),
      ]);
    }

    res.render('entry/view', {
      entry, error: loggedInPin ? null : pinError, loggedInPin, paymentHistory, attendanceLog, resultsForEntry,
      entryEnquiries, entryComplaints,
      openTab: ['enquiries', 'complaint'].includes(req.query.tab) ? req.query.tab : '',
    });
  } catch (err) {
    next(err);
  }
});

router.post('/:id', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('entry/not-found');
    }

    const body = req.body || {};
    if (!isPlainString(body.pin)) {
      return res.redirect(`/entry/${entry._id}?pinerr=invalid`);
    }

    // Wrong-pin guesses are limited per person (address) per entry, so guessing
    // can't go on forever — and one person's mistakes never lock out anyone else.
    const limitKey = `epin:${entry._id}:${clientIp(req)}`;
    if (await lockedSeconds(limitKey)) {
      return res.redirect(`/entry/${entry._id}?pinerr=locked`);
    }

    const attempt = sanitizeText(body.pin);
    if (!attempt || attempt !== entry.pin) {
      await recordFailure(limitKey, { max: 5, windowMs: 15 * 60 * 1000, lockMs: 15 * 60 * 1000 });
      await logSelf(req, entry, 'SELF_LOGIN_FAILED', { via: 'entry page' });
      return res.redirect(`/entry/${entry._id}?pinerr=wrong`);
    }
    await clearAttempts(limitKey);
    await logSelf(req, entry, 'SELF_LOGIN', { via: 'entry page' });

    setAuthCookie(res, {
      pin: entry.pin,
      entryId: entry._id.toString(),
      department: entry.department,
      faculty: entry.faculty,
    });

    // Stay on this same page, now logged in — never hand off to the pin
    // section. (The GET handler above reads the same auth cookie to
    // decide whether to show the logged-in state / Log out button.)
    res.redirect(`/entry/${entry._id}`);
  } catch (err) {
    next(err);
  }
});

// POST /entry/:id/enquiries and /entry/:id/complaints — the logged-in
// owner of this entry sends an enquiry or a complaint from the
// Enquiries / Complaint tabs. Owner-only, same check as /payments below.
function makeSubmitHandler(Model, tab) {
  return async (req, res, next) => {
    try {
      const entry = await loadEntry(req.params.id);
      if (!entry) return res.status(404).render('entry/not-found');

      const auth = getAuth(req);
      if (!auth || String(auth.entryId) !== String(entry._id)) {
        return res.redirect(`/entry/${entry._id}`);
      }

      const body = req.body || {};
      const subject = isPlainString(body.subject) ? sanitizeText(body.subject).slice(0, 120) : '';
      const message = isPlainString(body.message) ? sanitizeText(body.message).slice(0, 1000) : '';
      if (subject && message) {
        await Model.create({
          raisedByType: 'entry',
          entry: entry._id,
          entryName: [entry.firstName, entry.surname].filter(Boolean).join(' '),
          department: entry.department || '',
          subject,
          message,
        });
        await logSelf(req, entry, tab === 'enquiries' ? 'SELF_ENQUIRY_SENT' : 'SELF_COMPLAINT_SENT', { subject });
      }
      const back = req.query.back === 'auto' ? '/auto' : '';
      res.redirect(`/entry/${entry._id}${back}?tab=${tab}`);
    } catch (err) {
      next(err);
    }
  };
}
router.post('/:id/enquiries', makeSubmitHandler(Enquiry, 'enquiries'));
router.post('/:id/complaints', makeSubmitHandler(Complaint, 'complaint'));

// GET /entry/:id/auto — the logged-in owner's page, same as /entry/:id but
// the tab ring actually "clicks": each tab's content shows for 8 seconds,
// then the next tab slides in and shows its content, and so on. Owner-only
// (the tabs only exist for the owner); anyone else is sent to the public
// /entry/:id page, where the pin prompt lives.
router.get('/:id/auto', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) return res.status(404).render('entry/not-found');

    const auth = getAuth(req);
    const loggedInPin = auth && String(auth.entryId) === String(entry._id) ? auth.pin : '';
    if (!loggedInPin) return res.redirect(`/entry/${entry._id}`);

    const [paymentHistory, attendanceLog, resultsForEntry, entryEnquiries, entryComplaints] = await Promise.all([
      Receipt.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
      Attendance.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
      Result.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
      Enquiry.find({ entry: entry._id }).sort({ createdAt: -1 }).limit(50).lean(),
      Complaint.find({ entry: entry._id }).sort({ createdAt: -1 }).limit(50).lean(),
    ]);

    res.render('entry/auto', {
      entry, error: null, loggedInPin, paymentHistory, attendanceLog, resultsForEntry,
      entryEnquiries, entryComplaints,
      openTab: ['enquiries', 'complaint'].includes(req.query.tab) ? req.query.tab : '',
    });
  } catch (err) {
    next(err);
  }
});

// GET /entry/:id/payments — payment history for the logged-in owner of
// this entry, rendered by this section's own standalone template
// (src/views/entry/payments.ejs). Deliberately NOT the pin section's
// /:pin/profile/payments route — a visitor here never leaves /entry.
// Only the entry's own owner (matched via the same auth cookie the GET
// /:id handler already reads) can see it; anyone else, or a signed-out
// visitor, is sent back to the public profile at /entry/:id, exactly as
// if this route didn't exist for them.
router.get('/:id/payments', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('entry/not-found');
    }

    const auth = getAuth(req);
    const isOwner = auth && String(auth.entryId) === String(entry._id);
    if (!isOwner) {
      return res.redirect(`/entry/${entry._id}`);
    }

    const paymentHistory = await Receipt.find({ entry: entry._id })
      .sort({ createdAt: -1 })
      .lean();

    res.render('entry/payments', { entry, loggedInPin: auth.pin, paymentHistory });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
