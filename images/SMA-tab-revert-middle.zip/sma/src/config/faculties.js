// Static faculty -> departments map.

module.exports = {
  'Agriculture and Agricultural Technology': [
    'Agribusiness',
    'Agricultural Economics',
    'Agricultural Extension',
    'Animal Science and Technology',
    'Crop Science and Technology',
    'Soil Science and Technology',
    'Fisheries and Aquaculture Technology',
    'Forestry and Wildlife Technology',
  ],

  'Biological Sciences': [
    'Biochemistry',
    'Biological Science',
    'Biotechnology',
    'Forensic Science',
    'Microbiology',
  ],

  'Engineering and Engineering Technology': [
    'Agricultural Engineering',
    'Biomedical Engineering',
    'Food Science and Technology',
    'Materials and Metallurgical Engineering',
    'Polymer Engineering',
    'Chemical Engineering',
    'Civil Engineering',
    'Mechanical Engineering',
    'Petroleum Engineering',
  ],

  'Environmental Sciences': [
    'Architecture',
    'Building Technology',
    'Environmental Management',
    'Estate Management and Valuation',
    'Quantity Surveying',
    'Surveying and Geoinformatics',
    'Urban and Regional Planning',
  ],

  'Physical Sciences': [
    'Chemistry',
    'Geology',
    'Mathematics',
    'Physics',
    'Science Laboratory Technology',
    'Statistics',
  ],

  'Information and Communication Technology': [
    'Computer Science',
    'Cyber Security Science',
    'Information Technology',
    'Software Engineering',
  ],

  'Electrical Systems and Engineering Technology': [
    'Computer Engineering',
    'Electrical Engineering',
    'Electronic Engineering',
    'Mechatronic Engineering',
    'Telecommunication Engineering',
  ],

  'Logistics and Innovation Technology': [
    'Entrepreneurship Studies and Innovation',
    'Finance and Innovation Technology',
    'Logistics and Transport Technology',
    'Maritime Science Technology',
    'Project Management Technology',
    'Supply Chain Management',
  ],

  'Health Technology': [
    'Dental Technology',
    'Environmental Health Science',
    'Prosthetics and Orthotics Technology',
    'Public Health Technology',
    'Optometry',
    'Radiography',
  ],

  'Basic Medical Sciences': [
    'Human Anatomy',
    'Human Physiology',
  ],

  'Centre of Excellence for Sustainable Procurement, Environment and Social Standard': [
    'Sustainable Environmental Studies',
    'Sustainable Social Development',
    'Procurement Management',
  ],

  'College of Medicine': [
    'Medicine and Surgery',
  ],
};
