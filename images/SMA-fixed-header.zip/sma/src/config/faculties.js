// The canonical faculty -> departments map now lives in a genuine, standalone
// JSON file: public/data/faculties.json. It's served as-is to the browser
// (so client-side form dropdowns always match what the server accepts) and
// required here for server-side validation — one file, one source of truth,
// instead of the JSON data being duplicated/hand-typed inside a template's
// <script> block where it could silently drift out of sync (which is what
// caused "invalid faculty" errors on submission).
module.exports = require('../../public/data/faculties.json');
