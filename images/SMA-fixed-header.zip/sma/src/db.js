const mongoose = require('mongoose');

// Serverless functions (Vercel) can reuse a warm container between requests,
// but every cold start would otherwise open a brand new MongoDB connection.
// Caching the connection on `global` means warm invocations reuse it instead
// of piling up new connections until MongoDB Atlas rejects them.
let cached = global.__mongooseConn;
if (!cached) {
  cached = global.__mongooseConn = { conn: null, promise: null };
}

async function connectDB() {
  if (cached.conn) return cached.conn;

  if (!cached.promise) {
    const uri = process.env.MONGODB_URI;
    if (!uri) {
      throw new Error('MONGODB_URI is not set. Copy .env.example to .env and fill it in.');
    }

    mongoose.set('strictQuery', true);
    cached.promise = mongoose.connect(uri).then(async (m) => {
      console.log('MongoDB connected');

      // The Attendance collection's unique index used to be on `entry`
      // alone (one attendance record per person, full stop) before the
      // entry/exit redesign changed it to a compound index on
      // (entry, session, type). Mongoose's normal auto-indexing only
      // *adds* indexes the current schema defines — it never drops an
      // index that's no longer in the schema. On a database that still
      // has that old `entry` index left over, MongoDB keeps enforcing
      // "one record per person" underneath the new code, so a second,
      // perfectly legitimate record (a different session, or the exit
      // half of the same session) fails as a duplicate every time no
      // matter what the application logic decides. syncIndexes() drops
      // any index that isn't in the current schema and (re)builds the
      // ones that are, so this self-heals on the very next deploy
      // instead of needing a manual `db.attendances.dropIndex(...)`.
      try {
        await require('./models/Attendance').syncIndexes();
      } catch (err) {
        console.error('Attendance.syncIndexes() failed (non-fatal):', err.message);
      }

      return m;
    });
  }

  cached.conn = await cached.promise;
  return cached.conn;
}

module.exports = { connectDB };
