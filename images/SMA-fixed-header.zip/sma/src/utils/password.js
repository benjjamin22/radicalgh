// Wraps bcryptjs (pure JS — no native build step, so it works the same
// locally and on Vercel's serverless functions) for hashing/checking
// supervisor account passwords. Never store a plaintext password on the
// Supervisor model — only the hash produced here.

const bcrypt = require('bcryptjs');

const SALT_ROUNDS = 12;

function hashPassword(plain) {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

function verifyPassword(plain, hash) {
  if (!plain || !hash) return Promise.resolve(false);
  return bcrypt.compare(plain, hash);
}

module.exports = { hashPassword, verifyPassword };
