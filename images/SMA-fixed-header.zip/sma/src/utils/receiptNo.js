const crypto = require('crypto');

// Human-readable, sortable-ish receipt number: RC-<UTC yymmdd>-<5 random
// base32 chars>. Collisions are astronomically unlikely but the caller
// still retries on a duplicate-key error rather than trusting that.
function generateReceiptNo() {
  const now = new Date();
  const datePart = now.toISOString().slice(2, 10).replace(/-/g, ''); // yymmdd
  const randomPart = crypto.randomBytes(4).toString('hex').toUpperCase().slice(0, 5);
  return `RC-${datePart}-${randomPart}`;
}

module.exports = { generateReceiptNo };
