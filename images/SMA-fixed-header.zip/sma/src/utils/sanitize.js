// Small, dependency-free helpers used to clean up any text that comes in
// from a form before it touches the database or gets rendered back out.

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// True only for an actual string. express.urlencoded({extended:true}) will
// happily turn a field like `name[$ne]=1` into a nested object, or a
// repeated field like `name=a&name=b` into an array — either of those
// getting passed straight to Mongoose is how NoSQL-operator injection
// happens. Rejecting anything that isn't a plain string closes that off
// before the value goes anywhere near a query or a document.
function isPlainString(value) {
  return typeof value === 'string';
}

// - trim() removes leading/trailing whitespace
// - replace(/\s+/g, ' ') collapses any run of internal whitespace (double
//   spaces, tabs, newlines from a multi-line textarea paste, etc.) to one
//   single space
function sanitizeText(value) {
  if (!isPlainString(value)) return '';
  return value.trim().replace(/\s+/g, ' ');
}

// Preserves single newlines (so paragraphs in a <textarea> don't get
// collapsed onto one line) while still trimming and collapsing runs of
// spaces/tabs on each line and blank lines in between.
function sanitizeMultiline(value) {
  if (!isPlainString(value)) return '';
  return value
    .split(/\r\n|\r|\n/)
    .map((line) => line.trim().replace(/[ \t]+/g, ' '))
    .filter((line, i, arr) => line !== '' || (i > 0 && arr[i - 1] !== ''))
    .join('\n')
    .trim();
}

function isValidEmail(value) {
  return EMAIL_PATTERN.test(value);
}

// Loose on purpose — digits, spaces, and a leading + only. Good enough to
// catch "definitely not a phone number" without rejecting valid
// international formats.
const PHONE_PATTERN = /^[+\d][\d\s-]{6,29}$/;

function isValidPhone(value) {
  return PHONE_PATTERN.test(value);
}

module.exports = { isPlainString, sanitizeText, sanitizeMultiline, isValidEmail, isValidPhone };
