// -------------------- PHOTO URL --------------------
// Builds the <img src> for a profile photo stored on Google Drive.
//
// `drive.google.com/thumbnail?id=...` (the old format this app used to
// store on Entry.photoUrl) works fine for a single, one-off request —
// e.g. the big avatar on someone's own profile — but Google throttles
// or silently drops it once a page fires off many of those requests at
// once, which is exactly what the department "users" grid does (dozens
// of photos in view/near-view together). The practical fix people use
// for bulk/list thumbnails is Google's actual image CDN host,
// `lh3.googleusercontent.com`, which doesn't have that same bulk-request
// problem. We always rebuild the URL from the permanent `photoId`
// (never trust a possibly-stale stored `photoUrl` string), so this also
// self-heals any entry whose photoUrl was saved back when the old
// format was used.
function driveThumbnailUrl(photoId, size) {
  if (!photoId) return '';
  const w = size || 1000;
  return `https://lh3.googleusercontent.com/d/${encodeURIComponent(photoId)}=w${w}`;
}

// Given anything with photoId/photoUrl (a lean Entry doc, or similar),
// returns the best photo URL to render. Prefers rebuilding from
// photoId; falls back to a stored photoUrl only if there's no photoId
// (shouldn't normally happen, but keeps old/odd records working).
function resolvePhotoUrl(source, size) {
  if (!source) return '';
  if (source.photoId) return driveThumbnailUrl(source.photoId, size);
  return source.photoUrl || '';
}

module.exports = { driveThumbnailUrl, resolvePhotoUrl };
