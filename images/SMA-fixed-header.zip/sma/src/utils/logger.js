const AuditLog = require('../models/AuditLog');

// Writes one audit log entry. Logging is "every action for both levels,
// and every admin action" per the spec — so this is called from every
// admin/supervisor route, including reads (search, view) not just
// writes. Failures here are swallowed (logged to the server console
// only) rather than thrown — a broken audit write should never be the
// reason a legitimate request 500s.
async function logAction(req, { actorType, actorId = '', actorLabel = '', level = null, action, targetEntryId = '', targetPin = '', targetReceiptId = '', department = '', meta = {} }) {
  try {
    await AuditLog.create({
      actorType,
      actorId,
      actorLabel,
      level,
      action,
      targetEntryId,
      targetPin,
      targetReceiptId,
      department,
      meta,
      ip: req.ip || '',
    });
  } catch (err) {
    console.error('Failed to write audit log', action, err);
  }
}

module.exports = { logAction };
