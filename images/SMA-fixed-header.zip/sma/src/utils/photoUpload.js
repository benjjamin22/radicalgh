const multer = require('multer');

// Memory storage — the file never touches disk here, it's forwarded
// straight to Google Drive (see src/utils/googleDrive.js). That also
// keeps this fine on serverless (no writable/persistent filesystem to
// rely on).
const ALLOWED_PHOTO_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter(req, file, cb) {
    if (!ALLOWED_PHOTO_TYPES.has(file.mimetype)) {
      return cb(new Error('PHOTO_TYPE'));
    }
    cb(null, true);
  },
}).single('photo');

// Wraps multer's callback-style middleware so a bad upload (wrong file
// type, too large) turns into a friendly `req.photoError` message instead
// of a raw 500 — the route handler decides what to do with it (usually:
// re-render the form with that message, same as any other validation
// error).
function handlePhotoUpload(req, res, next) {
  upload(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        req.photoError = 'Photo must be 5MB or smaller.';
      } else if (err.message === 'PHOTO_TYPE') {
        req.photoError = 'Photo must be a JPEG, PNG, or WEBP image.';
      } else {
        req.photoError = 'Could not process that photo.';
      }
    }
    next();
  });
}

module.exports = { handlePhotoUpload };
