// Auth state is stored entirely in a signed JWT kept in an httpOnly
// cookie — there is no express-session / server-side session store
// anywhere in this app. The token is minted the moment someone proves
// they know a *used* pin (see GET /:pin in routes/pin.js) and carries
// just enough to authorize the department-browsing feature:
//   { pin, entryId, department, faculty }
//
// - Knowing a pin is still what proves you're allowed to see/edit the
//   entry that pin owns (same model as before).
// - The JWT is what additionally proves — without needing to know
//   anyone else's pin — that you're allowed to browse the read-only
//   list of other entries in your own department.

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  // Fail loudly at startup rather than silently signing tokens with
  // `undefined`, which would make every token trivially forgeable.
  throw new Error('JWT_SECRET is not set. Add it to your .env file.');
}

const COOKIE_NAME = 'auth_token';
const TOKEN_TTL = '2h';
const COOKIE_MAX_AGE_MS = 2 * 60 * 60 * 1000;

function signAuthToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

function verifyAuthToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (err) {
    return null;
  }
}

// Mint a fresh token for `payload` and attach it as an httpOnly cookie.
function setAuthCookie(res, payload) {
  const token = signAuthToken(payload);
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: COOKIE_MAX_AGE_MS,
  });
  return token;
}

// Read + verify the JWT cookie on a request. Returns the decoded payload,
// or null if there's no cookie, it's expired, or it's invalid.
function getAuth(req) {
  const token = req.cookies && req.cookies[COOKIE_NAME];
  if (!token) return null;
  return verifyAuthToken(token);
}

function clearAuthCookie(res) {
  res.clearCookie(COOKIE_NAME);
}

module.exports = {
  signAuthToken,
  verifyAuthToken,
  setAuthCookie,
  getAuth,
  clearAuthCookie,
  COOKIE_NAME,
};
