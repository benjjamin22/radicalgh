// Shared by routes/pin.js (self-service form) and routes/supervisor.js
// (supervisor edit/update). Pulling this out avoids two copies of the
// same validation rules silently drifting apart.

const FACULTIES = require('../config/faculties');
const STATES = require('../config/states');
const { isPlainString, sanitizeText, sanitizeMultiline, isValidPhone } = require('./sanitize');

const MAX_NAME_PART_LEN = 100;
const MAX_PHONE_LEN = 30;
const MAX_REGNO_LEN = 40;
// Letters, digits, and a few common separators (/ - .) — matches typical
// registration-number formats (e.g. "ENG/2021/0142") without being so
// loose it accepts arbitrary junk.
const REGNO_PATTERN = /^[A-Za-z0-9/.\-]{3,40}$/;

const SEX_OPTIONS = ['Male', 'Female'];
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const EMERGENCY_RELATIONS = ['Parent', 'Guardian', 'Sibling', 'Spouse', 'Other'];

// Flattened list of every department name across every faculty — used to
// validate a supervisor's assigned department (a supervisor isn't tied
// to one faculty, just one department name).
const ALL_DEPARTMENTS = Object.values(FACULTIES).flat();

// Validate + sanitize the intake fields from a request body. Shared by
// create (POST), self-service update (PUT /:pin), and the supervisor
// update route. Returns { ok: true, values } or { ok: false, error,
// values }, where `values` is always safe to redisplay in a form.
function readEntryInput(body) {
  const rawFields = {
    regNo: body.regNo,
    firstName: body.firstName,
    middleName: body.middleName,
    surname: body.surname,
    phone: body.phone,
    status: body.status,
    faculty: body.faculty,
    department: body.department,
    sex: body.sex,
    bloodGroup: body.bloodGroup,
    lga: body.lga,
    state: body.state,
    emergencyPhone: body.emergencyPhone,
  };

  // Reject anything that isn't a plain string up front. With
  // express.urlencoded({ extended: true }) / multer's text-field parsing,
  // a field can arrive as a nested object (e.g. name[$ne]=1) or an array
  // (a repeated field name), and either of those reaching Mongoose is how
  // NoSQL-operator injection happens. This check stops that before any
  // value is trimmed or saved.
  const hasBadType = Object.values(rawFields).some((val) => val !== undefined && !isPlainString(val));
  if (hasBadType) {
    return {
      ok: false,
      error: 'Invalid submission.',
      values: {
        regNo: '', firstName: '', middleName: '', surname: '', phone: '', status: 'STUDENT', faculty: '', department: '',
        sex: '', bloodGroup: '', lga: '', state: '', emergencyPhone: '',
      },
    };
  }

  // Trim, and collapse any run of internal whitespace (double spaces,
  // tabs, stray newlines) down to a single space or single newline.
  const values = {
    regNo: sanitizeText(rawFields.regNo).toUpperCase().slice(0, MAX_REGNO_LEN),
    firstName: sanitizeText(rawFields.firstName).slice(0, MAX_NAME_PART_LEN),
    middleName: sanitizeText(rawFields.middleName).slice(0, MAX_NAME_PART_LEN),
    surname: sanitizeText(rawFields.surname).slice(0, MAX_NAME_PART_LEN),
    phone: sanitizeText(rawFields.phone).slice(0, MAX_PHONE_LEN),
    status: sanitizeText(rawFields.status).slice(0, 40) || 'STUDENT',
    faculty: sanitizeText(rawFields.faculty),
    department: sanitizeText(rawFields.department),
    sex: sanitizeText(rawFields.sex),
    bloodGroup: sanitizeText(rawFields.bloodGroup).toUpperCase(),
    lga: sanitizeText(rawFields.lga).slice(0, 80),
    state: sanitizeText(rawFields.state),
    emergencyPhone: sanitizeText(rawFields.emergencyPhone).slice(0, MAX_PHONE_LEN),
  };

  if (!values.regNo) return { ok: false, error: 'Registration number is required.', values };
  if (!REGNO_PATTERN.test(values.regNo)) {
    return { ok: false, error: 'Enter a valid registration number.', values };
  }
  if (!values.firstName) return { ok: false, error: 'First name is required.', values };
  if (!values.surname) return { ok: false, error: 'Surname is required.', values };

  // Faculty/department must be a real pair from the config — never trust
  // whatever strings the client sent, since the <select> options are
  // client-side convenience only.
  const departmentsForFaculty = FACULTIES[values.faculty];
  if (!departmentsForFaculty) {
    return { ok: false, error: 'Select a valid faculty.', values };
  }
  if (!departmentsForFaculty.includes(values.department)) {
    return { ok: false, error: 'Select a valid department for that faculty.', values };
  }

  if (!SEX_OPTIONS.includes(values.sex)) {
    return { ok: false, error: 'Select a valid sex.', values };
  }
  if (!BLOOD_GROUPS.includes(values.bloodGroup)) {
    return { ok: false, error: 'Select a valid blood group.', values };
  }
  if (!STATES.includes(values.state)) {
    return { ok: false, error: 'Select a valid state.', values };
  }
  if (!values.phone) return { ok: false, error: 'Phone number is required.', values };
  if (!isValidPhone(values.phone)) return { ok: false, error: 'Enter a valid phone number.', values };
  if (!values.lga) return { ok: false, error: 'LGA is required.', values };
  if (!values.emergencyPhone) return { ok: false, error: 'Emergency contact phone is required.', values };
  if (!isValidPhone(values.emergencyPhone)) {
    return { ok: false, error: 'Enter a valid emergency contact phone number.', values };
  }
  return { ok: true, values };
}

// Turns a Mongo duplicate-key error into a field-specific message. Falls
// back to a generic one if the key can't be identified (e.g. some other
// unique index added later).
function duplicateKeyMessage(err) {
  const key = err && err.keyPattern ? Object.keys(err.keyPattern)[0] : null;
  if (key === 'regNo') return 'That registration number has already been used.';
  if (key === 'pin') return null; // handled separately as "already used"
  return 'That value is already in use.';
}

// Joins firstName/middleName/surname into one display string. Accepts
// any object with those three keys (a full Mongoose doc, a .lean()
// plain object, or a `values` bag from readEntryInput) since every
// caller has one of those on hand.
function fullName(entryLike) {
  if (!entryLike) return '';
  return [entryLike.firstName, entryLike.middleName, entryLike.surname]
    .filter(Boolean)
    .join(' ');
}

module.exports = {
  FACULTIES,
  STATES,
  SEX_OPTIONS,
  BLOOD_GROUPS,
  EMERGENCY_RELATIONS,
  ALL_DEPARTMENTS,
  readEntryInput,
  duplicateKeyMessage,
  fullName,
};
