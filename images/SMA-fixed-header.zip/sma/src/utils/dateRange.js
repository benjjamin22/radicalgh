// Shared "day / week / month" quick-filter used anywhere receipts or
// payments are listed (cashier receipts, admin receipts, a pin's payment
// history). Given a range keyword, returns the Date each range starts
// from (in server-local time), or null for 'all' (no lower bound).
const VALID_RANGES = ['day', 'week', 'month', 'all'];

function normalizeRange(value) {
  return VALID_RANGES.includes(value) ? value : 'all';
}

function rangeStart(range) {
  const now = new Date();
  switch (normalizeRange(range)) {
    case 'day':
      return new Date(now.getFullYear(), now.getMonth(), now.getDate());
    case 'week': {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const day = start.getDay(); // 0 = Sunday
      const diffToMonday = day === 0 ? 6 : day - 1;
      start.setDate(start.getDate() - diffToMonday);
      return start;
    }
    case 'month':
      return new Date(now.getFullYear(), now.getMonth(), 1);
    default:
      return null;
  }
}

module.exports = { normalizeRange, rangeStart, VALID_RANGES };
