const express = require('express');
const mongoose = require('mongoose');
const Pin = require('../models/Pin');
const Entry = require('../models/Entry');
const Receipt = require('../models/Receipt');
const { setAuthCookie, getAuth, clearAuthCookie } = require('../utils/auth');
const { uploadPhotoToDrive, deletePhotoFromDrive } = require('../utils/googleDrive');
const { handlePhotoUpload } = require('../utils/photoUpload');
const { resolvePhotoUrl } = require('../utils/photo');
const {
  FACULTIES,
  STATES,
  SEX_OPTIONS,
  BLOOD_GROUPS,
  readEntryInput,
  duplicateKeyMessage,
} = require('../utils/entryFields');

// mergeParams so this router (mounted at /:pin in app.js) can read req.params.pin
const router = express.Router({ mergeParams: true });

// No page under a pin is ever cacheable — once the auth cookie is
// cleared (logout, expiry, or a different pin taking over this
// browser), every one of these pages must hit the server again and
// re-run its own auth check, rather than the browser just repainting
// whatever it last had in memory when the person taps "back".
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

// Authorize access to own-pin-only pages (:pin/edit, :pin/profile,
// :pin/profile/payments, :pin/users/:id, PUT /:pin, DELETE /:pin). The
// pin itself is still what proves ownership (same model as before), but
// we also require — and refresh — the JWT here so the department-
// browsing auth stays in sync with whoever currently holds the pin. If
// it's missing or stale, bounce through GET /:pin first, which
// re-derives it from the DB and mints a fresh one — passing `next` so
// that re-auth continues on to wherever the visitor was actually trying
// to go (e.g. tapping "Edit" on a department-list page whose session
// has since lapsed lands on /edit once re-authenticated, instead of
// just stopping at the list with no explanation of why "Edit" didn't do
// what it said). `next` is always `req.path` — a path Express itself
// already matched inside this router, never anything user-supplied — so
// it's safe to reflect back regardless of which own-pin route it came
// from, dynamic segments (:id) included.
async function requireOwnPinAuth(req, res, next) {
  const { pin } = req.params;
  const auth = getAuth(req);
  if (!auth || auth.pin !== pin) {
    const nextPath = req.path && req.path !== '/' ? req.path : '';
    // `retried` caps this at a single bounce-through-and-back hop: if the
    // cookie still isn't there after GET /:pin just set it (e.g. it's
    // being blocked by the browser entirely), fall through to the plain
    // department listing rather than redirect-looping forever.
    if (nextPath && !req.query.retried) {
      return res.redirect(`/${pin}?next=${encodeURIComponent(nextPath)}&retried=1`);
    }
    return res.redirect(`/${pin}`);
  }
  // Same globalLogoutAction mechanism as utils/adminAuth.js — the shared
  // site-header's "Log out" button only renders when this is set. Pages
  // under /:pin that don't use that shared header (edit, profile,
  // department — see their own top-of-page logout button) read the same
  // res.locals value directly instead.
  res.locals.globalLogoutAction = `/${pin}/logout`;
  next();
}

// Only same-pin relative paths that are actually routes in this file are
// ever honoured as a `next` redirect target — never an arbitrary string.
const OWN_PIN_NEXT_PATTERN = /^\/(edit|profile|profile\/payments|users\/[a-zA-Z0-9]+)$/;

// Builds the absolute URL for a pin — used as the payload for the "scan
// to view" QR code on the profile card.
function profileUrlFor(req, pin) {
  return `${req.protocol}://${req.get('host')}/${pin}`;
}

// GET /:pin — the single entry point.
//   - pin not in DB          -> "pin doesn't exist"
//   - pin exists, not used   -> render the intake form
//   - pin exists, used       -> mint/refresh the JWT and show the
//                                department listing (all entries that
//                                share this entry's department)
router.get('/', async (req, res, next) => {
  try {
    const { pin } = req.params;
    const pinDoc = await Pin.findOne({ code: pin }).lean();

    if (!pinDoc) {
      return res.status(404).render('pin/not-found', { pin });
    }

    if (pinDoc.used) {
      const entry = await Entry.findOne({ pin }).lean();
      if (!entry) {
        return res.render('pin/view', { pin, entry: null });
      }

      // An admin-deactivated entry is locked out of its own pin flow
      // entirely — no department browsing, no edit, no profile — without
      // touching the Pin document itself (the pin stays "used" and isn't
      // freed for reuse; only DELETE by an admin does that).
      if (entry.active === false) {
        return res.status(403).render('pin/not-found', { pin, deactivated: true });
      }

      // Proves this visitor knows `pin` -> authorize department browsing
      // for entry.department, scoped to this pin, for the next 2 hours.
      setAuthCookie(res, {
        pin: entry.pin,
        entryId: entry._id.toString(),
        department: entry.department,
        faculty: entry.faculty,
      });

      // Continue on to whatever own-pin page requireOwnPinAuth bounced
      // the visitor here from, now that a fresh cookie is set. Checked
      // against a fixed pattern of this file's own routes — never an
      // arbitrary redirect target. `retried=1` carries the loop guard
      // forward so a still-broken cookie fails to the department list
      // instead of bouncing back and forth indefinitely.
      if (typeof req.query.next === 'string' && OWN_PIN_NEXT_PATTERN.test(req.query.next)) {
        return res.redirect(`/${pin}${req.query.next}?retried=1`);
      }

      const deptEntries = await Entry.find({ department: entry.department })
        .sort({ surname: 1, firstName: 1 })
        .lean();
      deptEntries.forEach((u) => { u.photoUrl = resolvePhotoUrl(u); });

      res.locals.globalLogoutAction = `/${pin}/logout`;
      return res.render('pin/department', {
        pin,
        faculty: entry.faculty,
        department: entry.department,
        ownEntryId: entry._id.toString(),
        entries: deptEntries,
      });
    }

    return res.render('pin/form', {
      pin,
      error: null,
      values: {},
      faculties: FACULTIES,
      states: STATES,
      sexOptions: SEX_OPTIONS,
      bloodGroups: BLOOD_GROUPS,
    });
  } catch (err) {
    next(err);
  }
});

// POST /:pin — CREATE: submit the intake form for this (unused) pin.
router.post('/', handlePhotoUpload, async (req, res, next) => {
  const { pin } = req.params;
  let result;
  try {
    const pinDoc = await Pin.findOne({ code: pin });

    if (!pinDoc) {
      return res.status(404).render('pin/not-found', { pin });
    }

    // Already used — don't accept a second submission, just send them
    // through the normal GET flow (department listing).
    if (pinDoc.used) {
      return res.redirect(`/${pin}`);
    }

    result = readEntryInput(req.body || {});
    if (!result.ok || req.photoError) {
      return res.status(400).render('pin/form', {
        pin,
        error: req.photoError || result.error,
        values: result.values,
        faculties: FACULTIES,
        states: STATES,
        sexOptions: SEX_OPTIONS,
        bloodGroups: BLOOD_GROUPS,
      });
    }

    // Photo is optional on create — only touch Drive if one was sent.
    let photo = { id: '', url: '' };
    if (req.file) {
      try {
        const uploaded = await uploadPhotoToDrive(req.file.buffer, `${pin}-${Date.now()}`, req.file.mimetype);
        photo = uploaded;
      } catch (uploadErr) {
        console.error('Drive upload failed', uploadErr);
        return res.status(400).render('pin/form', {
          pin,
          error: 'Photo upload failed. You can try again, or submit without a photo.',
          values: result.values,
          faculties: FACULTIES,
          states: STATES,
          sexOptions: SEX_OPTIONS,
          bloodGroups: BLOOD_GROUPS,
          });
      }
    }

    const entry = await Entry.create({
      pin,
      ...result.values,
      photoId: photo.id,
      photoUrl: photo.url,
    });

    pinDoc.used = true;
    await pinDoc.save();

    setAuthCookie(res, {
      pin: entry.pin,
      entryId: entry._id.toString(),
      department: entry.department,
      faculty: entry.faculty,
    });

    res.redirect(`/${pin}`);
  } catch (err) {
    // A duplicate-key error on Entry.pin means two submissions raced each
    // other — treat the loser as "already used" rather than a 500. A
    // duplicate on regNo means this registration number was already
    // registered under a different pin — send them back to the form.
    if (err.code === 11000) {
      const key = err.keyPattern ? Object.keys(err.keyPattern)[0] : null;
      if (key === 'regNo' && result && result.ok) {
        return res.status(400).render('pin/form', {
          pin,
          error: duplicateKeyMessage(err),
          values: { ...result.values, regNo: '' },
          faculties: FACULTIES,
          states: STATES,
          sexOptions: SEX_OPTIONS,
          bloodGroups: BLOOD_GROUPS,
          });
      }
      return res.redirect(`/${pin}`);
    }
    next(err);
  }
});

// GET /:pin/users/:id — read-only view of another entry in the same
// department, reached from the department listing. Deliberately its own
// isolated page (pin/user-profile.ejs) — no shared partial with
// pin/edit or pin/profile, and no relation to the public /entry/:id
// page at all; that route is a separate section with a separate purpose
// (public, no auth, shows contact details). This one stays inside the
// pin section: it requires the visitor's own pin, and only shows entries
// in that same department, without phone/emergency contact.
router.get('/users/:id', requireOwnPinAuth, async (req, res, next) => {
  try {
    const { pin, id } = req.params;
    const auth = getAuth(req);
    if (!mongoose.isValidObjectId(id)) return res.redirect(`/${pin}`);
    const target = await Entry.findById(id).lean();
    if (!target || target.active === false || target.department !== auth.department) {
      return res.redirect(`/${pin}`);
    }
    target.photoUrl = resolvePhotoUrl(target);
    res.render('pin/user-profile', { pin, target });
  } catch (err) {
    next(err);
  }
});

// GET /:pin/edit — owner-only full edit screen.
router.get('/edit', requireOwnPinAuth, async (req, res, next) => {
  try {
    const { pin } = req.params;
    const entry = await Entry.findOne({ pin }).lean();
    if (!entry || entry.active === false) return res.redirect(`/${pin}`);
    entry.photoUrl = resolvePhotoUrl(entry);
    res.render('pin/edit', {
      pin,
      error: null,
      values: entry,
      entry,
      faculties: FACULTIES,
      states: STATES,
      sexOptions: SEX_OPTIONS,
      bloodGroups: BLOOD_GROUPS,
      profileUrl: profileUrlFor(req, pin),
      ownEntryId: entry._id.toString(),
    });
  } catch (err) { next(err); }
});

// PUT /:pin — owner can update every public profile field and optionally replace
// the profile photo. The authorization check is tied to the authenticated
// entry id/pin, so changing the URL cannot edit somebody else's record.
router.put('/', requireOwnPinAuth, handlePhotoUpload, async (req, res, next) => {
  const { pin } = req.params;
  let result;
  let existingEntry;
  try {
    existingEntry = await Entry.findOne({ pin });
    if (!existingEntry || existingEntry.active === false) return res.redirect(`/${pin}`);

    result = readEntryInput(req.body || {});
    if (!result.ok || req.photoError) {
      return res.status(400).render('pin/edit', {
        pin, error: req.photoError || result.error,
        values: { ...existingEntry.toObject(), ...result.values }, entry: { ...existingEntry.toObject(), ...result.values },
        faculties: FACULTIES, states: STATES, sexOptions: SEX_OPTIONS, bloodGroups: BLOOD_GROUPS,
        profileUrl: profileUrlFor(req, pin), ownEntryId: existingEntry._id.toString(),
      });
    }

    if (result.values.regNo !== existingEntry.regNo) {
      const duplicate = await Entry.findOne({ regNo: result.values.regNo, _id: { $ne: existingEntry._id } }).lean();
      if (duplicate) {
        return res.status(400).render('pin/edit', {
          pin, error: 'That registration number has already been used.',
          values: { ...existingEntry.toObject(), ...result.values }, entry: { ...existingEntry.toObject(), ...result.values },
          faculties: FACULTIES, states: STATES, sexOptions: SEX_OPTIONS, bloodGroups: BLOOD_GROUPS,
          profileUrl: profileUrlFor(req, pin), ownEntryId: existingEntry._id.toString(),
        });
      }
    }

    let uploaded = null;
    if (req.file) {
      try {
        uploaded = await uploadPhotoToDrive(req.file.buffer, `${pin}-${Date.now()}`, req.file.mimetype);
      } catch (uploadErr) {
        console.error('Drive upload failed during profile update', uploadErr);
        return res.status(400).render('pin/edit', {
          pin, error: 'Photo upload failed. Your existing photo was kept.',
          values: { ...existingEntry.toObject(), ...result.values }, entry: { ...existingEntry.toObject(), ...result.values },
          faculties: FACULTIES, states: STATES, sexOptions: SEX_OPTIONS, bloodGroups: BLOOD_GROUPS,
          profileUrl: profileUrlFor(req, pin), ownEntryId: existingEntry._id.toString(),
        });
      }
    }

    Object.assign(existingEntry, result.values);
    if (uploaded) {
      const oldPhotoId = existingEntry.photoId;
      existingEntry.photoId = uploaded.id;
      existingEntry.photoUrl = uploaded.url;
      await existingEntry.save();
      if (oldPhotoId) await deletePhotoFromDrive(oldPhotoId);
    } else {
      await existingEntry.save();
    }

    setAuthCookie(res, {
      pin: existingEntry.pin,
      entryId: existingEntry._id.toString(),
      department: existingEntry.department,
      faculty: existingEntry.faculty,
    });
    res.redirect(`/${pin}`);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).render('pin/edit', {
        pin, error: duplicateKeyMessage(err), values: result && result.values ? result.values : {},
        faculties: FACULTIES, states: STATES, sexOptions: SEX_OPTIONS, bloodGroups: BLOOD_GROUPS,
        profileUrl: profileUrlFor(req, pin), ownEntryId: existingEntry ? existingEntry._id.toString() : '',
      });
    }
    next(err);
  }
});

// POST /:pin/logout — ends the current browser session for this pin.
// This doesn't lock the pin or anyone out of it — the pin itself is
// still the credential, so visiting /:pin (or re-entering it on the
// home page, or on someone's /entry/:id page) re-authenticates
// instantly. It just clears the auth cookie, so an "Edit Profile" /
// "My Profile" / "Users" screen left open on a shared or borrowed
// device stops being a live, logged-in session.
//
// Where this sends the visitor depends on which screen they logged out
// from, via the `from` field the logout button/form supplies:
//   - from the pin section itself (My Profile, Edit Profile, Users,
//     someone else's read-only profile) -> the home "enter your pin"
//     form. This is the default, so a plain POST with no `from` field
//     (or any value other than "entry") lands here too.
//   - from the public /entry/:id page (viewed as its own owner) ->
//     back to that same /entry/:id page, now shown as a stranger would
//     see it, since that's the page the visitor is already looking at.
router.post('/logout', (req, res) => {
  const auth = getAuth(req);
  const entryId = auth && auth.entryId ? String(auth.entryId) : '';
  const from = req.body && req.body.from;
  clearAuthCookie(res);
  if (from === 'entry' && mongoose.isValidObjectId(entryId)) {
    return res.redirect(`/entry/${entryId}`);
  }
  res.redirect('/');
});

// There is deliberately no DELETE route here anymore — deleting a
// submission is now an admin-only action (DELETE /admin/entries/:id).

// GET /:pin/profile/payments — payment history is deliberately a separate
// screen. The profile only shows a link; this route renders the payments
// as cards and supports filtering without any browser back-navigation.
router.get('/profile/payments', requireOwnPinAuth, async (req, res, next) => {
  try {
    const { pin } = req.params;
    const entry = await Entry.findOne({ pin }).lean();
    if (!entry || entry.active === false) return res.redirect(`/${pin}`);

    // The filter box on this page is a live, client-side filter now (see
    // pin/payments.ejs) rather than a server round-trip search, so the
    // whole history is sent down once and narrowed as the person types.
    const paymentHistory = await Receipt.find({ entry: entry._id }).sort({ createdAt: -1 }).lean();
    return res.render('pin/payments', { pin, entry, paymentHistory });
  } catch (err) {
    next(err);
  }
});

// GET /:pin/profile — the pin holder's own full profile (every field,
// read-only) plus their payment/receipt history. Reachable only with a
// valid auth cookie for this exact pin, same guard as the edit page.
router.get('/profile', requireOwnPinAuth, async (req, res, next) => {
  try {
    const { pin } = req.params;
    const pinDoc = await Pin.findOne({ code: pin }).lean();

    if (!pinDoc) {
      return res.status(404).render('pin/not-found', { pin });
    }
    if (!pinDoc.used) {
      return res.redirect(`/${pin}`);
    }

    const entry = await Entry.findOne({ pin }).lean();
    if (!entry) {
      return res.redirect(`/${pin}`);
    }
    if (entry.active === false) {
      return res.redirect(`/${pin}`);
    }

    const deptEntries = await Entry.find({ department: entry.department, active: { $ne: false } })
      .sort({ surname: 1, firstName: 1 })
      .lean();
    deptEntries.forEach((u) => { u.photoUrl = resolvePhotoUrl(u); });
    entry.photoUrl = resolvePhotoUrl(entry);

    const paymentHistory = await Receipt.find({ entry: entry._id }).sort({ createdAt: -1 }).lean();

    res.render('pin/profile', { pin, entry, entries: deptEntries, ownEntryId: entry._id.toString(), paymentHistory });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
