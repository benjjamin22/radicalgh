const express = require('express');
const crypto = require('crypto');
const mongoose = require('mongoose');
const Supervisor = require('../models/Supervisor');
const Cashier = require('../models/Cashier');
const Receipt = require('../models/Receipt');
const Attendance = require('../models/Attendance');
const Result = require('../models/Result');
const CashierPayout = require('../models/CashierPayout');
const Entry = require('../models/Entry');
const Pin = require('../models/Pin');
const AuditLog = require('../models/AuditLog');
const { isPlainString, sanitizeText } = require('../utils/sanitize');
const {
  ALL_DEPARTMENTS,
  FACULTIES,
  STATES,
  SEX_OPTIONS,
  BLOOD_GROUPS,
  EMERGENCY_RELATIONS,
  readEntryInput,
  duplicateKeyMessage,
  fullName,
} = require('../utils/entryFields');
const { handlePhotoUpload } = require('../utils/photoUpload');
const { uploadPhotoToDrive, deletePhotoFromDrive } = require('../utils/googleDrive');
const { resolvePhotoUrl } = require('../utils/photo');
const { hashPassword } = require('../utils/password');
const { setAdminCookie, clearAdminCookie, requireAdmin } = require('../utils/adminAuth');
const { logAction } = require('../utils/logger');
const { normalizeRange, rangeStart } = require('../utils/dateRange');

const router = express.Router();

// Same reasoning as routes/pin.js: once the admin password session is
// cleared, every admin page must be re-fetched and re-checked, not
// served from the browser's back/forward cache.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD) {
  // Fail loudly rather than silently letting anyone in — same philosophy
  // as the JWT_SECRET check in utils/auth.js.
  throw new Error('ADMIN_PASSWORD is not set. Add it to your .env file.');
}

const USERNAME_PATTERN = /^[a-z0-9._-]{3,40}$/;

async function getMoneySummary() {
  const [receiptAgg, payoutAgg] = await Promise.all([
    Receipt.aggregate([{ $group: { _id: null, total: { $sum: '$amount' } } }]),
    CashierPayout.aggregate([
      { $match: { status: 'Approved' } },
      { $group: { _id: null, total: { $sum: '$amount' } } },
    ]),
  ]);
  const totalCollected = receiptAgg[0]?.total || 0;
  const approvedPayouts = payoutAgg[0]?.total || 0;
  return { totalCollected, approvedPayouts, available: Math.max(0, totalCollected - approvedPayouts) };
}

async function attachCashierTotals(cashiers) {
  const ids = cashiers.map(c => c._id);
  if (!ids.length) return cashiers;
  const [receipts, payouts] = await Promise.all([
    Receipt.aggregate([{ $match: { cashier: { $in: ids } } }, { $group: { _id: '$cashier', total: { $sum: '$amount' } } }]),
    CashierPayout.aggregate([{ $match: { cashier: { $in: ids }, status: 'Approved' } }, { $group: { _id: '$cashier', total: { $sum: '$amount' } } }]),
  ]);
  const r = new Map(receipts.map(x => [x._id.toString(), x.total || 0]));
  const p = new Map(payouts.map(x => [x._id.toString(), x.total || 0]));
  return cashiers.map(c => {
    const gross = r.get(c._id.toString()) || 0;
    const paid = p.get(c._id.toString()) || 0;
    return { ...c, totalCollected: gross, approvedPayouts: paid, available: Math.max(0, gross - paid) };
  });
}

// Constant-time password comparison. Hashing both sides to a fixed-length
// digest first means timingSafeEqual never sees mismatched buffer
// lengths (which throws) and doesn't leak the real password's length
// via a length-mismatch short-circuit.
function safeCompare(a, b) {
  const digestA = crypto.createHash('sha256').update(String(a)).digest();
  const digestB = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(digestA, digestB);
}

// -------------------- LOGIN / LOGOUT --------------------

router.get('/login', (req, res) => {
  res.render('admin/login', { error: null });
});

router.post('/login', async (req, res, next) => {
  try {
    const body = req.body || {};
    const submitted = isPlainString(body.password) ? body.password : '';

    if (!submitted || !safeCompare(submitted, ADMIN_PASSWORD)) {
      await logAction(req, { actorType: 'admin', action: 'ADMIN_LOGIN_FAILURE' });
      return res.status(401).render('admin/login', { error: 'Incorrect password.' });
    }

    setAdminCookie(res);
    await logAction(req, { actorType: 'admin', actorLabel: 'admin', action: 'ADMIN_LOGIN_SUCCESS' });
    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

router.post('/logout', requireAdmin, async (req, res, next) => {
  try {
    clearAdminCookie(res);
    await logAction(req, { actorType: 'admin', actorLabel: 'admin', action: 'ADMIN_LOGOUT' });
    res.redirect('/admin/login');
  } catch (err) {
    next(err);
  }
});

// -------------------- DASHBOARD --------------------

router.get('/', requireAdmin, async (req, res, next) => {
  try {
    let [supervisors, cashiers] = await Promise.all([
      Supervisor.find().sort({ createdAt: -1 }).lean(),
      Cashier.find().sort({ createdAt: -1 }).lean(),
    ]);
    cashiers = await attachCashierTotals(cashiers);
    const money = await getMoneySummary();
    const pendingPayouts = await CashierPayout.countDocuments({ status: 'Pending' });
    res.render('admin/dashboard', {
      supervisors,
      cashiers,
      money,
      pendingPayouts,
      departments: ALL_DEPARTMENTS,
      error: null,
      cashierError: null,
      formValues: { username: '', level: '1', department: '' },
      cashierFormValues: { username: '', level: '1', department: '' },
    });
  } catch (err) {
    next(err);
  }
});

// -------------------- CREATE SUPERVISOR --------------------

router.post('/supervisors', requireAdmin, async (req, res, next) => {
  const body = req.body || {};
  const renderWithError = async (error, formValues) => {
    const [supervisors, cashiers] = await Promise.all([
      Supervisor.find().sort({ createdAt: -1 }).lean(),
      Cashier.find().sort({ createdAt: -1 }).lean(),
    ]);
    res.status(400).render('admin/dashboard', {
      supervisors,
      cashiers,
      departments: ALL_DEPARTMENTS,
      error,
      cashierError: null,
      formValues,
      cashierFormValues: { username: '', level: '1', department: '' },
    });
  };

  try {
    const hasBadType = ['username', 'password', 'level', 'department'].some(
      (key) => body[key] !== undefined && !isPlainString(body[key])
    );
    if (hasBadType) {
      return renderWithError('Invalid submission.', { username: '', level: '1', department: '' });
    }

    const username = sanitizeText(body.username).toLowerCase();
    const password = isPlainString(body.password) ? body.password : '';
    const level = body.level === '2' ? 2 : body.level === '1' ? 1 : null;
    const department = sanitizeText(body.department);

    const formValues = { username, level: level ? String(level) : '1', department };

    if (!USERNAME_PATTERN.test(username)) {
      return renderWithError('Username must be 3-40 characters: lowercase letters, numbers, dots, dashes, or underscores.', formValues);
    }
    if (!password || password.length < 8) {
      return renderWithError('Password must be at least 8 characters.', formValues);
    }
    if (!level) {
      return renderWithError('Select a level.', formValues);
    }
    if (level === 2 && !ALL_DEPARTMENTS.includes(department)) {
      return renderWithError('Level 2 supervisors need a valid department.', formValues);
    }

    const passwordHash = await hashPassword(password);
    const supervisor = await Supervisor.create({
      username,
      passwordHash,
      level,
      department: level === 2 ? department : '',
    });

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'SUPERVISOR_CREATED',
      department: supervisor.department,
      meta: { username: supervisor.username, level: supervisor.level },
    });

    res.redirect('/admin');
  } catch (err) {
    if (err.code === 11000) {
      return renderWithError('That username is already taken.', {
        username: '', level: '1', department: '',
      });
    }
    next(err);
  }
});

// -------------------- ACTIVATE / DEACTIVATE SUPERVISOR --------------------

router.get('/supervisors/:id', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(404).render('admin/not-found');
    }
    const supervisor = await Supervisor.findById(id).lean();
    if (!supervisor) return res.redirect('/admin');

    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const DETAIL_LOGS_PER_PAGE = 50;
    const [logs, total, payoutRequests] = await Promise.all([
      AuditLog.find({ actorType: 'supervisor', actorId: String(supervisor._id) })
        .sort({ createdAt: -1 })
        .skip((page - 1) * DETAIL_LOGS_PER_PAGE)
        .limit(DETAIL_LOGS_PER_PAGE)
        .lean(),
      AuditLog.countDocuments({ actorType: 'supervisor', actorId: String(supervisor._id) }),
      CashierPayout.find({ supervisor: supervisor._id }).sort({ createdAt: -1 }).lean(),
    ]);

    res.render('admin/supervisor-detail', {
      supervisor,
      logs,
      page,
      totalPages: Math.max(1, Math.ceil(total / DETAIL_LOGS_PER_PAGE)),
      payoutRequests,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/supervisors/:id/toggle', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(404).render('admin/not-found');
    }

    const supervisor = await Supervisor.findById(id);
    if (!supervisor) return res.redirect('/admin');

    supervisor.active = !supervisor.active;
    await supervisor.save();

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: supervisor.active ? 'SUPERVISOR_REACTIVATED' : 'SUPERVISOR_DEACTIVATED',
      department: supervisor.department,
      meta: { username: supervisor.username, level: supervisor.level },
    });

    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

// -------------------- CREATE CASHIER --------------------

router.post('/cashiers', requireAdmin, async (req, res, next) => {
  const body = req.body || {};
  const renderWithError = async (cashierError, cashierFormValues) => {
    const [supervisors, cashiers] = await Promise.all([
      Supervisor.find().sort({ createdAt: -1 }).lean(),
      Cashier.find().sort({ createdAt: -1 }).lean(),
    ]);
    res.status(400).render('admin/dashboard', {
      supervisors,
      cashiers,
      departments: ALL_DEPARTMENTS,
      error: null,
      cashierError,
      formValues: { username: '', level: '1', department: '' },
      cashierFormValues,
    });
  };

  try {
    const hasBadType = ['username', 'password', 'level', 'department'].some(
      (key) => body[key] !== undefined && !isPlainString(body[key])
    );
    if (hasBadType) {
      return renderWithError('Invalid submission.', { username: '', level: '1', department: '' });
    }

    const username = sanitizeText(body.username).toLowerCase();
    const password = isPlainString(body.password) ? body.password : '';
    const level = body.level === '2' ? 2 : body.level === '1' ? 1 : null;
    const department = sanitizeText(body.department);

    const cashierFormValues = { username, level: level ? String(level) : '1', department };

    if (!USERNAME_PATTERN.test(username)) {
      return renderWithError('Username must be 3-40 characters: lowercase letters, numbers, dots, dashes, or underscores.', cashierFormValues);
    }
    if (!password || password.length < 8) {
      return renderWithError('Password must be at least 8 characters.', cashierFormValues);
    }
    if (!level) {
      return renderWithError('Select a level.', cashierFormValues);
    }
    if (level === 2 && !ALL_DEPARTMENTS.includes(department)) {
      return renderWithError('Level 2 cashiers need a valid department.', cashierFormValues);
    }

    const passwordHash = await hashPassword(password);
    const cashier = await Cashier.create({
      username,
      passwordHash,
      level,
      department: level === 2 ? department : '',
    });

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'CASHIER_CREATED',
      department: cashier.department,
      meta: { username: cashier.username, level: cashier.level },
    });

    res.redirect('/admin');
  } catch (err) {
    if (err.code === 11000) {
      return renderWithError('That username is already taken.', {
        username: '', level: '1', department: '',
      });
    }
    next(err);
  }
});

// -------------------- ACTIVATE / DEACTIVATE CASHIER --------------------

router.get('/cashiers/:id', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(404).render('admin/not-found');
    }
    const cashierDoc = await Cashier.findById(id).lean();
    if (!cashierDoc) return res.redirect('/admin');
    const [cashier] = await attachCashierTotals([cashierDoc]);

    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const DETAIL_LOGS_PER_PAGE = 50;
    const RECEIPTS_LIMIT = 50;
    const [logs, total, receipts, payoutRequests] = await Promise.all([
      AuditLog.find({ actorType: 'cashier', actorId: String(cashier._id) })
        .sort({ createdAt: -1 })
        .skip((page - 1) * DETAIL_LOGS_PER_PAGE)
        .limit(DETAIL_LOGS_PER_PAGE)
        .lean(),
      AuditLog.countDocuments({ actorType: 'cashier', actorId: String(cashier._id) }),
      Receipt.find({ cashier: cashier._id }).sort({ createdAt: -1 }).limit(RECEIPTS_LIMIT).lean(),
      CashierPayout.find({ cashier: cashier._id }).sort({ createdAt: -1 }).lean(),
    ]);

    res.render('admin/cashier-detail', {
      cashier,
      logs,
      page,
      totalPages: Math.max(1, Math.ceil(total / DETAIL_LOGS_PER_PAGE)),
      receipts,
      payoutRequests,
    });
  } catch (err) {
    next(err);
  }
});

router.post('/cashiers/:id/toggle', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return res.status(404).render('admin/not-found');
    }

    const cashier = await Cashier.findById(id);
    if (!cashier) return res.redirect('/admin');

    cashier.active = !cashier.active;
    await cashier.save();

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: cashier.active ? 'CASHIER_REACTIVATED' : 'CASHIER_DEACTIVATED',
      department: cashier.department,
      meta: { username: cashier.username, level: cashier.level },
    });

    res.redirect('/admin');
  } catch (err) {
    next(err);
  }
});

// -------------------- CASHIER MONEY / PAYOUT APPROVALS --------------------
router.get('/cashier-payouts', requireAdmin, async (req, res, next) => {
  try {
    const [requests, money] = await Promise.all([
      CashierPayout.find().sort({ createdAt: -1 }).limit(200).lean(),
      getMoneySummary(),
    ]);
    res.render('admin/cashier-payouts', { requests, money, error: null });
  } catch (err) { next(err); }
});

router.post('/cashier-payouts/:id/approve', requireAdmin, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).render('admin/not-found');
    const payout = await CashierPayout.findById(req.params.id);
    if (!payout) return res.redirect('/admin/cashier-payouts');
    if (payout.status !== 'Pending') return res.redirect('/admin/cashier-payouts');

    // Cashier requests are tied to actual receipts, so preserve the existing
    // balance check. Supervisor requests are approval-only because supervisors
    // do not issue receipts and therefore have no cashier-style receipt balance.
    if (payout.requesterType === 'cashier' && payout.cashier) {
      const [receiptAgg, approvedAgg] = await Promise.all([
        Receipt.aggregate([{ $match: { cashier: payout.cashier } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
        CashierPayout.aggregate([{ $match: { cashier: payout.cashier, status: 'Approved' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]),
      ]);
      const collected = receiptAgg[0]?.total || 0;
      const alreadyPaid = approvedAgg[0]?.total || 0;
      const available = collected - alreadyPaid;
      if (payout.amount > available) {
        return res.status(400).render('admin/cashier-payouts', {
          requests: await CashierPayout.find().sort({ createdAt: -1 }).limit(200).lean(),
          money: await getMoneySummary(),
          error: `Cannot approve ${payout.amount.toLocaleString()} for ${payout.requesterUsername || payout.cashierUsername}. Only ₦${Math.max(0, available).toLocaleString()} is currently available.`,
        });
      }
    }

    payout.status = 'Approved';
    payout.decidedAt = new Date();
    payout.decidedBy = 'admin';
    payout.decisionNote = 'Approved by admin';
    await payout.save();
    await logAction(req, {
      actorType: 'admin', actorLabel: 'admin', action: payout.requesterType === 'supervisor' ? 'SUPERVISOR_PAYOUT_APPROVED' : 'CASHIER_PAYOUT_APPROVED',
      meta: { payoutId: payout._id.toString(), requesterType: payout.requesterType, requester: payout.requesterUsername || payout.cashierUsername, amount: payout.amount },
    });
    res.redirect('/admin/cashier-payouts');
  } catch (err) { next(err); }
});

router.post('/cashier-payouts/:id/reject', requireAdmin, async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(404).render('admin/not-found');
    const payout = await CashierPayout.findById(req.params.id);
    if (!payout) return res.redirect('/admin/cashier-payouts');
    if (payout.status === 'Pending') {
      payout.status = 'Rejected';
      payout.decidedAt = new Date();
      payout.decidedBy = 'admin';
      payout.decisionNote = 'Rejected by admin';
      await payout.save();
      await logAction(req, {
        actorType: 'admin', actorLabel: 'admin', action: 'CASHIER_PAYOUT_REJECTED',
        meta: { payoutId: payout._id.toString(), requesterType: payout.requesterType, requester: payout.requesterUsername || payout.cashierUsername, amount: payout.amount },
      });
    }
    res.redirect('/admin/cashier-payouts');
  } catch (err) { next(err); }
});

// -------------------- ENTRIES: FULL ADMIN CRUD --------------------
// Supervisors are read-only (routes/supervisor.js has no PUT/DELETE at
// all). Only an admin can edit or delete an entry — that full CRUD
// lives entirely here, unrestricted by department.

const ENTRIES_PER_PAGE = 20;

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

router.get('/entries', requireAdmin, async (req, res, next) => {
  try {
    const rawQuery = isPlainString(req.query.q) ? req.query.q : '';
    const q = sanitizeText(rawQuery).slice(0, 100);
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);

    const filter = {};
    if (q) {
      const re = new RegExp(escapeRegex(q), 'i');
      filter.$or = [{ firstName: re }, { middleName: re }, { surname: re }, { regNo: re }, { pin: re }, { phone: re }, { department: re }];
    }

    const [entries, total] = await Promise.all([
      Entry.find(filter)
        .sort({ surname: 1, firstName: 1 })
        .skip((page - 1) * ENTRIES_PER_PAGE)
        .limit(ENTRIES_PER_PAGE)
        .lean(),
      Entry.countDocuments(filter),
    ]);

    res.render('admin/entries', {
      entries,
      q,
      page,
      totalPages: Math.max(1, Math.ceil(total / ENTRIES_PER_PAGE)),
    });
  } catch (err) {
    next(err);
  }
});

async function loadEntryOr404(req, res) {
  const { id } = req.params;
  if (!mongoose.isValidObjectId(id)) {
    res.status(404).render('admin/not-found');
    return null;
  }
  const entry = await Entry.findById(id);
  if (!entry) {
    res.status(404).render('admin/not-found');
    return null;
  }
  return entry;
}

router.get('/entries/:id/edit', requireAdmin, async (req, res, next) => {
  try {
    const entry = await loadEntryOr404(req, res);
    if (!entry) return;

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'ENTRY_VIEW',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
      department: entry.department,
    });

    const [paymentHistory, attendanceLog, resultsForEntry] = await Promise.all([
      Receipt.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
      Attendance.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
      Result.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
    ]);

    const entryValues = entry.toObject();
    entryValues.photoUrl = resolvePhotoUrl(entryValues);

    res.render('admin/entry-edit', {
      error: null,
      values: entryValues,
      paymentHistory,
      attendanceLog,
      resultsForEntry,
      faculties: FACULTIES,
      states: STATES,
      sexOptions: SEX_OPTIONS,
      bloodGroups: BLOOD_GROUPS,
      emergencyRelations: EMERGENCY_RELATIONS,
    });
  } catch (err) {
    next(err);
  }
});

router.put('/entries/:id', requireAdmin, handlePhotoUpload, async (req, res, next) => {
  let result;
  try {
    const existingEntry = await loadEntryOr404(req, res);
    if (!existingEntry) return;

    result = readEntryInput(req.body || {});
    if (!result.ok || req.photoError) {
      return res.status(400).render('admin/entry-edit', {
        error: req.photoError || result.error,
        values: { ...result.values, _id: existingEntry._id, pin: existingEntry.pin, photoUrl: existingEntry.photoUrl },
        paymentHistory: await Receipt.find({ entry: existingEntry._id }).sort({ createdAt: -1 }).lean(),
        attendanceLog: await Attendance.find({ entry: existingEntry._id }).sort({ createdAt: -1 }).lean(),
        resultsForEntry: await Result.find({ entry: existingEntry._id }).sort({ createdAt: -1 }).lean(),
        faculties: FACULTIES,
        states: STATES,
        sexOptions: SEX_OPTIONS,
        bloodGroups: BLOOD_GROUPS,
        emergencyRelations: EMERGENCY_RELATIONS,
      });
    }

    const updates = { ...result.values };
    const removePhoto = req.body && req.body.removePhoto === 'on';

    if (req.file) {
      try {
        const uploaded = await uploadPhotoToDrive(req.file.buffer, `${existingEntry.pin}-${Date.now()}`, req.file.mimetype);
        updates.photoId = uploaded.id;
        updates.photoUrl = uploaded.url;
        if (existingEntry.photoId) {
          await deletePhotoFromDrive(existingEntry.photoId);
        }
      } catch (uploadErr) {
        console.error('Drive upload failed', uploadErr);
        return res.status(400).render('admin/entry-edit', {
          error: 'Photo upload failed. You can try again, or leave the existing photo in place.',
          values: { ...result.values, _id: existingEntry._id, pin: existingEntry.pin, photoUrl: existingEntry.photoUrl },
          paymentHistory: await Receipt.find({ entry: existingEntry._id }).sort({ createdAt: -1 }).lean(),
          attendanceLog: await Attendance.find({ entry: existingEntry._id }).sort({ createdAt: -1 }).lean(),
          resultsForEntry: await Result.find({ entry: existingEntry._id }).sort({ createdAt: -1 }).lean(),
          faculties: FACULTIES,
          states: STATES,
          sexOptions: SEX_OPTIONS,
          bloodGroups: BLOOD_GROUPS,
          emergencyRelations: EMERGENCY_RELATIONS,
        });
      }
    } else if (removePhoto && existingEntry.photoId) {
      await deletePhotoFromDrive(existingEntry.photoId);
      updates.photoId = '';
      updates.photoUrl = '';
    }

    // Diff against the pre-update document so the audit log records
    // exactly what changed, not a full before/after snapshot.
    const changed = {};
    Object.keys(result.values).forEach((key) => {
      const before = existingEntry[key];
      const after = updates[key];
      if (before !== after) {
        changed[key] = { from: before, to: after };
      }
    });

    const updatedEntry = await Entry.findByIdAndUpdate(
      existingEntry._id,
      { $set: updates },
      { new: true, runValidators: true }
    );

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'ENTRY_UPDATE',
      targetEntryId: existingEntry._id.toString(),
      targetPin: existingEntry.pin,
      department: existingEntry.department,
      meta: { changed },
    });

    res.redirect(`/admin/entries`);
  } catch (err) {
    if (err.code === 11000 && result && result.ok) {
      const key = err.keyPattern ? Object.keys(err.keyPattern)[0] : null;
      const entry = await Entry.findById(req.params.id).lean();
      return res.status(400).render('admin/entry-edit', {
        error: key === 'regNo' ? duplicateKeyMessage(err) : 'That value is already in use.',
        values: { ...result.values, _id: req.params.id, pin: entry ? entry.pin : '', photoUrl: entry ? entry.photoUrl : '' },
        paymentHistory: await Receipt.find({ entry: req.params.id }).sort({ createdAt: -1 }).lean(),
        attendanceLog: await Attendance.find({ entry: req.params.id }).sort({ createdAt: -1 }).lean(),
        resultsForEntry: await Result.find({ entry: req.params.id }).sort({ createdAt: -1 }).lean(),
        faculties: FACULTIES,
        states: STATES,
        sexOptions: SEX_OPTIONS,
        bloodGroups: BLOOD_GROUPS,
        emergencyRelations: EMERGENCY_RELATIONS,
      });
    }
    next(err);
  }
});

router.delete('/entries/:id', requireAdmin, async (req, res, next) => {
  try {
    const entry = await loadEntryOr404(req, res);
    if (!entry) return;

    if (entry.photoId) {
      await deletePhotoFromDrive(entry.photoId);
    }
    await Entry.deleteOne({ _id: entry._id });
    // Free the pin back up for reuse, same as the self-service DELETE
    // used to do.
    await Pin.findOneAndUpdate({ code: entry.pin }, { $set: { used: false } });

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'ENTRY_DELETE',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
      department: entry.department,
      meta: { regNo: entry.regNo, name: fullName(entry) },
    });

    res.redirect('/admin/entries');
  } catch (err) {
    next(err);
  }
});

// -------------------- ACTIVATE / DEACTIVATE ENTRY --------------------
// Separate from DELETE above: deactivating locks the pin holder out of
// their own pin (see GET /:pin in routes/pin.js and GET /entry/:id in
// routes/entryProfile.js) without deleting the record or freeing the
// pin for reuse. Only DELETE frees the pin.

router.post('/entries/:id/toggle', requireAdmin, async (req, res, next) => {
  try {
    const entry = await loadEntryOr404(req, res);
    if (!entry) return;

    entry.active = !entry.active;
    await entry.save();

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: entry.active ? 'ENTRY_REACTIVATED' : 'ENTRY_DEACTIVATED',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
      department: entry.department,
      meta: { regNo: entry.regNo, name: fullName(entry) },
    });

    res.redirect('/admin/entries');
  } catch (err) {
    next(err);
  }
});
// Cashiers can only CREATE a receipt and READ their own (routes/cashier.js).
// Only an admin can list every receipt, edit one, or delete one — that
// full CRUD lives entirely here.

const RECEIPTS_PER_PAGE = 300;
const AMOUNT_PATTERN = /^\d{1,9}(\.\d{1,2})?$/;

router.get('/receipts', requireAdmin, async (req, res, next) => {
  try {
    const rawQuery = isPlainString(req.query.q) ? req.query.q : '';
    const q = sanitizeText(rawQuery).slice(0, 100);
    const entryId = isPlainString(req.query.entry) ? req.query.entry.trim() : '';
    const range = normalizeRange(req.query.range);

    const filter = {};
    if (entryId && mongoose.isValidObjectId(entryId)) filter.entry = entryId;
    if (q) {
      const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      filter.$or = [{ receiptNo: re }, { entryRegNo: re }, { entryName: re }, { cashierUsername: re }, { department: re }];
    }
    const start = rangeStart(range);
    if (start) filter.createdAt = { $gte: start };

    // No server-side pagination here any more — the card list below
    // scrolls inside its own box (see .card-list in style.css) instead
    // of paging through screens, so we just fetch a generous, single
    // batch of the most recent matches.
    const [receipts, rangeAgg] = await Promise.all([
      Receipt.find(filter)
        .sort({ createdAt: -1 })
        .limit(RECEIPTS_PER_PAGE)
        .lean(),
      Receipt.aggregate([
        { $match: filter },
        { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } },
      ]),
    ]);
    const rangeTotals = { total: rangeAgg[0]?.total || 0, count: rangeAgg[0]?.count || 0 };

    res.render('admin/receipts', {
      receipts,
      q,
      entryId,
      error: null,
      range,
      rangeTotals,
    });
  } catch (err) {
    next(err);
  }
});

router.get('/receipts/:id/edit', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(404).render('admin/not-found');

    const receipt = await Receipt.findById(id).lean();
    if (!receipt) return res.status(404).render('admin/not-found');

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'RECEIPT_VIEW',
      targetReceiptId: receipt._id.toString(),
      targetEntryId: receipt.entry ? receipt.entry.toString() : '',
      department: receipt.department,
      meta: { receiptNo: receipt.receiptNo },
    });

    res.render('admin/receipt-edit', { receipt, error: null });
  } catch (err) {
    next(err);
  }
});

router.put('/receipts/:id', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(404).render('admin/not-found');

    const existing = await Receipt.findById(id);
    if (!existing) return res.status(404).render('admin/not-found');

    const body = req.body || {};
    const hasBadType = ['amount', 'purpose'].some((key) => body[key] !== undefined && !isPlainString(body[key]));
    if (hasBadType) {
      return res.status(400).render('admin/receipt-edit', { receipt: existing.toObject(), error: 'Invalid submission.' });
    }

    const amountRaw = sanitizeText(body.amount);
    const purpose = sanitizeText(body.purpose).slice(0, 300);

    if (!AMOUNT_PATTERN.test(amountRaw)) {
      return res.status(400).render('admin/receipt-edit', {
        receipt: { ...existing.toObject(), amount: amountRaw, purpose },
        error: 'Enter a valid amount (up to 2 decimal places).',
      });
    }
    const amount = Number(amountRaw);
    if (!(amount > 0)) {
      return res.status(400).render('admin/receipt-edit', {
        receipt: { ...existing.toObject(), amount: amountRaw, purpose },
        error: 'Enter a valid amount.',
      });
    }
    if (!purpose) {
      return res.status(400).render('admin/receipt-edit', {
        receipt: { ...existing.toObject(), amount: amountRaw, purpose },
        error: 'Purpose / reason is required.',
      });
    }

    const changed = {};
    if (existing.amount !== amount) changed.amount = { from: existing.amount, to: amount };
    if (existing.purpose !== purpose) changed.purpose = { from: existing.purpose, to: purpose };

    existing.amount = amount;
    existing.purpose = purpose;
    await existing.save();

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'RECEIPT_UPDATE',
      targetReceiptId: existing._id.toString(),
      targetEntryId: existing.entry ? existing.entry.toString() : '',
      department: existing.department,
      meta: { receiptNo: existing.receiptNo, changed },
    });

    res.redirect('/admin/receipts');
  } catch (err) {
    next(err);
  }
});

router.delete('/receipts/:id', requireAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) return res.status(404).render('admin/not-found');

    const receipt = await Receipt.findByIdAndDelete(id);
    if (!receipt) return res.redirect('/admin/receipts');

    await logAction(req, {
      actorType: 'admin',
      actorLabel: 'admin',
      action: 'RECEIPT_DELETE',
      targetReceiptId: receipt._id.toString(),
      targetEntryId: receipt.entry ? receipt.entry.toString() : '',
      department: receipt.department,
      meta: { receiptNo: receipt.receiptNo, amount: receipt.amount, purpose: receipt.purpose },
    });

    res.redirect('/admin/receipts');
  } catch (err) {
    next(err);
  }
});

// -------------------- AUDIT LOGS --------------------

const LOGS_PER_PAGE = 300;

router.get('/logs', requireAdmin, async (req, res, next) => {
  try {
    // Same reasoning as /admin/receipts above: one scrollable batch,
    // no page-by-page navigation.
    const logs = await AuditLog.find()
      .sort({ createdAt: -1 })
      .limit(LOGS_PER_PAGE)
      .lean();

    res.render('admin/logs', { logs });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
