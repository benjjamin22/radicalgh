const express = require('express');
const mongoose = require('mongoose');
const Supervisor = require('../models/Supervisor');
const CashierPayout = require('../models/CashierPayout');
const Entry = require('../models/Entry');
const Attendance = require('../models/Attendance');
const { isPlainString, sanitizeText } = require('../utils/sanitize');
const { verifyPassword } = require('../utils/password');
const {
  setSupervisorCookie,
  clearSupervisorCookie,
  requireSupervisor,
} = require('../utils/adminAuth');
const { logAction } = require('../utils/logger');
const { fullName } = require('../utils/entryFields');
const { resolvePhotoUrl } = require('../utils/photo');

const router = express.Router();

// Same reasoning as routes/pin.js, routes/admin.js and routes/cashier.js:
// once a supervisor logs out, every supervisor page must be re-fetched
// and re-checked, not served from the browser's back/forward cache.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

const RESULTS_PER_PAGE = 20;
const MAX_AMOUNT = 100000000;
const AMOUNT_PATTERN = /^\d{1,9}(\.\d{1,2})?$/;

// -------------------- LOGIN / LOGOUT --------------------

router.get('/login', (req, res) => {
  res.render('supervisor/login', { error: null });
});

router.post('/login', async (req, res, next) => {
  try {
    const body = req.body || {};
    if (!isPlainString(body.username) || !isPlainString(body.password)) {
      return res.status(400).render('supervisor/login', { error: 'Invalid submission.' });
    }

    const username = sanitizeText(body.username).toLowerCase();
    const password = body.password;

    const supervisor = await Supervisor.findOne({ username });
    const passwordOk = supervisor ? await verifyPassword(password, supervisor.passwordHash) : false;

    if (!supervisor || !supervisor.active || !passwordOk) {
      await logAction(req, {
        actorType: 'supervisor',
        actorLabel: username,
        action: 'SUPERVISOR_LOGIN_FAILURE',
      });
      return res.status(401).render('supervisor/login', { error: 'Incorrect username or password.' });
    }

    setSupervisorCookie(res, {
      supervisorId: supervisor._id.toString(),
      username: supervisor.username,
      level: supervisor.level,
      department: supervisor.department,
    });

    await logAction(req, {
      actorType: 'supervisor',
      actorId: supervisor._id.toString(),
      actorLabel: supervisor.username,
      level: supervisor.level,
      department: supervisor.department,
      action: 'SUPERVISOR_LOGIN_SUCCESS',
    });

    res.redirect('/supervisor');
  } catch (err) {
    next(err);
  }
});

router.post('/logout', requireSupervisor, async (req, res, next) => {
  try {
    clearSupervisorCookie(res);
    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level: req.supervisor.level,
      department: req.supervisor.department,
      action: 'SUPERVISOR_LOGOUT',
    });
    res.redirect('/supervisor/login');
  } catch (err) {
    next(err);
  }
});

// -------------------- SEARCH DASHBOARD --------------------
// Level 1: browses the entire Entry collection.
// Level 2: the department filter is always forced to the supervisor's
// own department, regardless of anything else submitted — this is what
// actually enforces the department-only scope, not just the UI.
//
// The `q` box is deliberately NOT a filter across name/phone/pin — it is
// a registration-number lookup for exactly one person. A match sends the
// supervisor straight to that person's read-only profile
// (GET /supervisor/entry/:id) instead of returning a filtered list, so a
// supervisor can never browse the roster by anything other than a reg
// no they already have. A miss re-renders this same page with an inline
// "not found" message and the normal (unfiltered) browsable list below
// it — it never falls back to a broader search.
//
// A supervisor is READ-ONLY everywhere in this file: there is no
// update or delete route here at all. Only /admin/entries can change or
// remove an entry — see routes/admin.js.
router.get('/', requireSupervisor, async (req, res, next) => {
  try {
    const { level, department } = req.supervisor;
    const rawQuery = isPlainString(req.query.q) ? req.query.q : '';
    const q = sanitizeText(rawQuery).slice(0, 40);

    let notFound = false;
    if (q) {
      const regNo = q.toUpperCase();
      const lookupFilter = { regNo };
      if (level === 2) lookupFilter.department = department;

      const match = await Entry.findOne(lookupFilter).select({ _id: 1 }).lean();

      await logAction(req, {
        actorType: 'supervisor',
        actorId: req.supervisor.supervisorId,
        actorLabel: req.supervisor.username,
        level,
        department: level === 2 ? department : '',
        action: 'ENTRY_SEARCH',
        meta: { query: q, found: !!match },
      });

      if (match) {
        return res.redirect(`/supervisor/entry/${match._id}`);
      }
      notFound = true;
    }

    // A supervisor no longer browses the full roster from this page —
    // only the reg-no search above and the two "Scan for Attendance"
    // shortcuts. Keeping this a lookup-only screen, rather than handing
    // out the whole entry list at once, is a deliberate access-scope
    // decision (see src/views/supervisor/dashboard.ejs).
    const payoutRequests = await CashierPayout.find({
      requesterType: 'supervisor',
      supervisor: req.supervisor.supervisorId,
    }).sort({ createdAt: -1 }).limit(10).lean();

    res.render('supervisor/dashboard', {
      supervisor: req.supervisor,
      q,
      notFound,
      payoutRequests,
      error: null,
    });
  } catch (err) {
    next(err);
  }
});

// Always rebuild the photo URL from the permanent photoId (see
// utils/photo.js) rather than trusting a possibly-stale stored value.
function normalizeEntryPhoto(entry) {
  if (!entry) return entry;
  entry.photoUrl = resolvePhotoUrl(entry);
  return entry;
}

// Shared authorization: level 1 may view any entry; level 2 only an
// entry in their own department. Used by the read-only view route below.
async function loadAuthorizedEntry(req, res) {
  const { id } = req.params;
  if (!mongoose.isValidObjectId(id)) {
    res.status(404).render('404');
    return null;
  }

  const entry = normalizeEntryPhoto(await Entry.findById(id).lean());
  if (!entry) {
    res.status(404).render('404');
    return null;
  }

  const { level, department } = req.supervisor;
  if (level === 2 && entry.department !== department) {
    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level,
      department,
      action: 'ENTRY_VIEW_DENIED',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
      meta: { reason: 'department mismatch', entryDepartment: entry.department },
    });
    res.status(403).render('error', { message: 'You are not authorized to view this entry.' });
    return null;
  }

  return entry;
}

// -------------------- MONEY / ADMIN APPROVAL REQUESTS --------------------
// Supervisors may send money approval requests to admin. These requests are
// kept separate from cashier receipt balances because supervisors do not
// issue receipts themselves.
router.post('/payout-requests', requireSupervisor, async (req, res, next) => {
  try {
    const body = req.body || {};
    const amountRaw = isPlainString(body.amount) ? sanitizeText(body.amount) : '';
    const reason = isPlainString(body.reason) ? sanitizeText(body.reason).slice(0, 300) : '';
    if (!AMOUNT_PATTERN.test(amountRaw)) return res.status(400).redirect('/supervisor');
    const amount = Number(amountRaw);
    if (!(amount > 0) || amount > MAX_AMOUNT) return res.status(400).redirect('/supervisor');

    const payout = await CashierPayout.create({
      requesterType: 'supervisor',
      supervisor: req.supervisor.supervisorId,
      requesterUsername: req.supervisor.username,
      amount,
      reason,
      status: 'Pending',
    });

    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level: req.supervisor.level,
      department: req.supervisor.department,
      action: 'SUPERVISOR_PAYOUT_REQUESTED',
      meta: { payoutId: payout._id.toString(), amount, reason },
    });
    res.redirect('/supervisor');
  } catch (err) { next(err); }
});

// -------------------- VIEW (READ-ONLY) --------------------
// Supervisors can look, never touch: there is deliberately no PUT/DELETE
// route in this file. Only an admin can edit or delete an entry — see
// the "/admin/entries" section of routes/admin.js.
router.get('/entry/:id', requireSupervisor, async (req, res, next) => {
  try {
    const entry = await loadAuthorizedEntry(req, res);
    if (!entry) return;

    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level: req.supervisor.level,
      department: entry.department,
      action: 'ENTRY_VIEW',
      targetEntryId: entry._id.toString(),
      targetPin: entry.pin,
    });

    res.render('supervisor/view', {
      supervisor: req.supervisor,
      entry,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------- ATTENDANCE SCANNER --------------------
// Mirrors cashier's bulk QR scanner (routes/cashier.js, "BULK RECEIPT
// SCANNER" section) but retasked as a gate log — no payment involved at
// any point. Instead of locking an amount + purpose and issuing a
// receipt per scan, the supervisor locks a session/event name AND
// whether this pass is marking Entry or Exit, then each scan (or typed
// reg no) records that person's entry or exit for that session. Marking
// entry and marking exit are two separate locked passes; both are kept
// as their own record. Scanning or typing the same person twice for the
// same session + type is reported back as "already marked", not a
// second record — enforced by the unique index on the Attendance model,
// not just client-side checking.
const PIN_PATTERN = /^[a-zA-Z0-9]{4,10}$/;
const REGNO_PATTERN = /^[A-Za-z0-9/.\-]{3,40}$/; // same shape routes/pin.js accepts
const SESSION_MAXLEN = 200;

router.get('/attendance-scanner', requireSupervisor, (req, res) => {
  res.render('supervisor/attendance-scanner', { supervisor: req.supervisor });
});

// Look up a person by registration number only — nothing is recorded.
// The attendance-scanner page's reg-no box calls this after Enter is
// pressed so the supervisor can see the name + department and confirm
// it's the right person before POST /bulk-attendance actually marks them.
router.get('/lookup-regno', requireSupervisor, async (req, res) => {
  const { level, department } = req.supervisor;
  const fail = (status, message) => res.status(status).json({ success: false, message });
  try {
    const regNo = isPlainString(req.query.regNo) ? sanitizeText(req.query.regNo).toUpperCase() : '';
    if (!REGNO_PATTERN.test(regNo)) return fail(400, 'Enter a valid registration number.');

    const entry = await Entry.findOne({ regNo })
      .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1 })
      .lean();
    if (!entry) return fail(404, 'No matching user found for that registration number.');

    const authorized = !(level === 2 && entry.department !== department);
    return res.json({
      success: true,
      authorized,
      student: { name: fullName(entry), id: entry.regNo, department: entry.department },
    });
  } catch (err) {
    console.error('reg no lookup failed', err);
    return fail(500, 'Server error while looking up that registration number.');
  }
});

// Resolve a scanned QR to the person's registration number. Existing
// profile QR cards may contain a URL ending in the person's pin, while
// newer cards may contain the registration number directly. The
// attendance endpoint itself remains registration-number based.
router.get('/lookup-qr', requireSupervisor, async (req, res) => {
  const { level, department } = req.supervisor;
  const fail = (status, message) => res.status(status).json({ success: false, message });
  try {
    if (!isPlainString(req.query.code)) return fail(400, 'No QR data was supplied.');
    const raw = sanitizeText(req.query.code).trim();
    if (!raw || raw.length > 500) return fail(400, 'Invalid QR data.');

    let token = raw;
    try {
      const url = new URL(raw);
      const parts = url.pathname.split('/').filter(Boolean);
      if (parts.length) token = parts[parts.length - 1];
    } catch (e) {}

    token = sanitizeText(token).trim();
    let entry = null;

    // Prefer registration number first. This makes the scanner's normal
    // path explicitly reg-no based.
    if (REGNO_PATTERN.test(token)) {
      entry = await Entry.findOne({ regNo: token.toUpperCase() })
        .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1 })
        .lean();
    }

    // Backward compatibility: old QR cards contain the pin in the URL.
    // Resolve it once to the same entry, then return only the reg no to
    // the scanner. No attendance is marked from this compatibility lookup.
    if (!entry && PIN_PATTERN.test(token)) {
      entry = await Entry.findOne({ pin: token })
        .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1 })
        .lean();
    }

    if (!entry) return fail(404, 'That QR code does not match a registered user.');

    const authorized = !(level === 2 && entry.department !== department);
    return res.json({
      success: true,
      authorized,
      student: { name: fullName(entry), id: entry.regNo, department: entry.department },
    });
  } catch (err) {
    console.error('QR lookup failed', err);
    return fail(500, 'Server error while reading that QR code.');
  }
});

// Marks one person present (or absent-again) for the locked session.
// Takes a pin OR a registration number, exactly like
// /cashier/bulk-receipts, and answers with JSON so the scanner page can
// keep running without a reload.
//
// The type (entry/exit) is no longer something the supervisor picks
// ahead of time — it's worked out from this person's own attendance
// history for this session, which is what actually decides what
// scanning them again means:
//   - no record yet for this session          -> mark ENTRY, right away
//   - an entry but no exit yet                -> this is their second
//     scan; don't record anything on this call, just ask the scanner
//     page to confirm "mark exit?" (needsExitConfirm: true). Only a
//     follow-up call with confirmExit=true actually writes the exit row.
//   - both an entry and an exit already exist -> nothing left to record;
//     answered as a duplicate, same as before.
router.post('/bulk-attendance', requireSupervisor, async (req, res) => {
  const { level, department } = req.supervisor;
  const body = req.body || {};
  const fail = (status, message) => res.status(status).json({ success: false, message });

  try {
    const hasBadType = ['pin', 'regNo', 'session'].some(
      (key) => body[key] !== undefined && !isPlainString(body[key])
    );
    if (hasBadType) return fail(400, 'Invalid submission.');

    const pin = isPlainString(body.pin) ? body.pin.trim() : '';
    const regNo = isPlainString(body.regNo) ? sanitizeText(body.regNo).toUpperCase() : '';
    const session = sanitizeText(body.session).slice(0, SESSION_MAXLEN);
    const confirmExit = body.confirmExit === true || body.confirmExit === 'true';

    // Exactly one way of naming the person: a scanned pin or a typed reg no.
    if (pin && regNo) return fail(400, 'Send either a pin or a registration number, not both.');
    const via = regNo ? 'regNo' : 'pin';
    if (via === 'regNo') {
      if (!REGNO_PATTERN.test(regNo)) return fail(400, 'Enter a valid registration number.');
    } else if (!PIN_PATTERN.test(pin)) {
      return fail(400, 'That QR code does not contain a valid pin.');
    }
    if (!session) return fail(400, 'Session / event name is required.');

    const entry = await Entry.findOne(via === 'regNo' ? { regNo } : { pin })
      .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1 })
      .lean();
    if (!entry) {
      return fail(404, via === 'regNo'
        ? 'No matching user found for that registration number.'
        : 'No matching user found for that pin.');
    }

    const student = { name: fullName(entry), id: entry.regNo, department: entry.department };

    if (level === 2 && entry.department !== department) {
      await logAction(req, {
        actorType: 'supervisor',
        actorId: req.supervisor.supervisorId,
        actorLabel: req.supervisor.username,
        level,
        department,
        action: 'ATTENDANCE_MARK_DENIED',
        targetEntryId: entry._id.toString(),
        meta: { reason: 'department mismatch', entryDepartment: entry.department, session, via },
      });
      return fail(403, 'You are not authorized to mark attendance for a user outside your department.');
    }

    // Source of truth is the DB, not anything the scanner page remembers
    // client-side — another device could have marked this person in the
    // meantime, so this is checked fresh on every call.
    const existing = await Attendance.find({ entry: entry._id, session })
      .select({ type: 1 })
      .lean();
    const hasEntry = existing.some((r) => r.type === 'entry');
    const hasExit = existing.some((r) => r.type === 'exit');

    if (hasEntry && hasExit) {
      return res.json({
        success: false,
        duplicate: true,
        student,
        message: 'This person has already entered and exited this session.',
      });
    }

    if (hasEntry && !confirmExit) {
      // Don't write anything yet — the scanner page shows a Yes/No
      // prompt and only replays this same request with confirmExit=true
      // once the supervisor actually says yes.
      return res.json({
        success: false,
        needsExitConfirm: true,
        student,
        message: `${student.name || 'This person'} already entered "${session}". Mark them as exited?`,
      });
    }

    const type = hasEntry ? 'exit' : 'entry';

    let record;
    try {
      record = await Attendance.create({
        entry: entry._id,
        entryRegNo: entry.regNo,
        entryName: fullName(entry),
        department: entry.department,
        session,
        type,
        markedBy: req.supervisor.supervisorId,
        markedByUsername: req.supervisor.username,
        supervisorLevel: level,
      });
    } catch (err) {
      if (err.code === 11000) {
        // Someone else's scan (or this same one, retried) beat this
        // request to it between the check above and this insert.
        return res.json({
          success: false,
          duplicate: true,
          student,
          message: `This person is already marked ${type === 'exit' ? 'exited' : 'entered'} for this session.`,
        });
      }
      throw err;
    }

    await logAction(req, {
      actorType: 'supervisor',
      actorId: req.supervisor.supervisorId,
      actorLabel: req.supervisor.username,
      level,
      department: entry.department,
      action: 'ATTENDANCE_MARKED',
      targetEntryId: entry._id.toString(),
      meta: { session, type, via, attendanceId: record._id.toString() },
    });

    return res.json({
      success: true,
      student,
      attendance: { session, type, markedAt: record.createdAt },
    });
  } catch (err) {
    console.error('bulk attendance failed', err);
    return fail(500, 'Server error while marking attendance.');
  }
});

module.exports = router;
