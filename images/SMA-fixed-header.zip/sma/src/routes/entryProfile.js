// GET/POST /entry/:id — a public, database-_id-addressed profile page.
//
// This is deliberately the ONLY way to reach another pin holder's full
// profile (name, faculty, department, contact details) without knowing
// their pin. It is intentionally a dead-end, self-contained page: it
// never renders any pin-section screen (edit, department listing, the
// pin section's own payments page) and never hands the visitor off into
// the pin section. Entering the correct pin re-renders this same
// /entry/:id page, now showing the logged-in state (with a Log out
// button and a Payment History link); it does not redirect to
// /:pin/profile or anywhere else in the pin section. Payment history for
// the logged-in owner is served by this section's own /entry/:id/payments
// route below — a separate, self-contained page, not the pin section's
// /:pin/profile/payments. Logging out from either page here (POST
// /:pin/logout with from=entry, see routes/pin.js) lands back on this
// same /entry/:id page. The pin section, this entry page, and admin are
// kept deliberately separate — none of the three ever redirects a
// visitor into either of the others. See src/views/entry/view.ejs and
// src/views/entry/payments.ejs, which are their own standalone
// templates with no shared partial with the pin section.
//
// Mounted at /entry in app.js, ahead of the /:pin catch-all — same
// reservation trick as /admin, /supervisor, /cashier: "entry" can never
// be issued as a pin.
const express = require('express');
const mongoose = require('mongoose');
const Entry = require('../models/Entry');
const Receipt = require('../models/Receipt');
const Attendance = require('../models/Attendance');
const Result = require('../models/Result');
const { setAuthCookie, getAuth } = require('../utils/auth');
const { isPlainString, sanitizeText } = require('../utils/sanitize');
const { resolvePhotoUrl } = require('../utils/photo');

// Always rebuild the photo URL from the permanent photoId (see
// utils/photo.js) rather than trusting a possibly-stale stored value.
function normalizeEntryPhoto(entry) {
  if (!entry) return entry;
  entry.photoUrl = resolvePhotoUrl(entry);
  return entry;
}

const router = express.Router();

// Same reasoning as routes/pin.js and the other route files: this page's
// "Log out" button (shown when the visitor is viewing their own entry
// while logged in) changes what's rendered, so the page must be
// re-fetched rather than repainted from the browser's back/forward
// cache once that state has changed.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

async function loadEntry(id) {
  if (!mongoose.isValidObjectId(id)) return null;
  const entry = await Entry.findById(id).lean();
  if (!entry || entry.active === false) return null;
  return normalizeEntryPhoto(entry);
}

router.get('/:id', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('entry/not-found');
    }
    const auth = getAuth(req);
    const loggedInPin = auth && String(auth.entryId) === String(entry._id) ? auth.pin : '';

    // Payments and Attendance Log tabs are only ever populated for the
    // entry's own owner (same ownership check as the standalone
    // /entry/:id/payments route below) — everyone else just sees the
    // Info tab, same as before this page had tabs at all.
    let paymentHistory = [];
    let attendanceLog = [];
    let resultsForEntry = [];
    if (loggedInPin) {
      [paymentHistory, attendanceLog, resultsForEntry] = await Promise.all([
        Receipt.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
        Attendance.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
        Result.find({ entry: entry._id }).sort({ createdAt: -1 }).lean(),
      ]);
    }

    res.render('entry/view', { entry, error: null, loggedInPin, paymentHistory, attendanceLog, resultsForEntry });
  } catch (err) {
    next(err);
  }
});

router.post('/:id', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('entry/not-found');
    }

    const body = req.body || {};
    if (!isPlainString(body.pin)) {
      return res.status(400).render('entry/view', { entry, loggedInPin: '', error: 'Enter a valid pin.' });
    }

    const attempt = sanitizeText(body.pin);
    if (!attempt || attempt !== entry.pin) {
      return res.status(400).render('entry/view', { entry, loggedInPin: '', error: 'Incorrect pin.' });
    }

    setAuthCookie(res, {
      pin: entry.pin,
      entryId: entry._id.toString(),
      department: entry.department,
      faculty: entry.faculty,
    });

    // Stay on this same page, now logged in — never hand off to the pin
    // section. (The GET handler above reads the same auth cookie to
    // decide whether to show the logged-in state / Log out button.)
    res.redirect(`/entry/${entry._id}`);
  } catch (err) {
    next(err);
  }
});

// GET /entry/:id/payments — payment history for the logged-in owner of
// this entry, rendered by this section's own standalone template
// (src/views/entry/payments.ejs). Deliberately NOT the pin section's
// /:pin/profile/payments route — a visitor here never leaves /entry.
// Only the entry's own owner (matched via the same auth cookie the GET
// /:id handler already reads) can see it; anyone else, or a signed-out
// visitor, is sent back to the public profile at /entry/:id, exactly as
// if this route didn't exist for them.
router.get('/:id/payments', async (req, res, next) => {
  try {
    const entry = await loadEntry(req.params.id);
    if (!entry) {
      return res.status(404).render('entry/not-found');
    }

    const auth = getAuth(req);
    const isOwner = auth && String(auth.entryId) === String(entry._id);
    if (!isOwner) {
      return res.redirect(`/entry/${entry._id}`);
    }

    const paymentHistory = await Receipt.find({ entry: entry._id })
      .sort({ createdAt: -1 })
      .lean();

    res.render('entry/payments', { entry, loggedInPin: auth.pin, paymentHistory });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
