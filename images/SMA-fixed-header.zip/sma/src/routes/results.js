const express = require('express');
const mongoose = require('mongoose');
const Result = require('../models/Result');
const Entry = require('../models/Entry');
const { isPlainString, sanitizeText, sanitizeMultiline } = require('../utils/sanitize');
const { requireSupervisor, requireAdmin } = require('../utils/adminAuth');
const { logAction } = require('../utils/logger');
const { fullName } = require('../utils/entryFields');

// Results are prepared by supervisors and remarked by the admin.
//   supervisorRouter -> mounted at /supervisor/results
//   adminRouter      -> mounted at /admin/results
// Both are mounted in app.js ahead of the main supervisor/admin routers.
// Nothing in the existing supervisor/admin route files was changed.

const REGNO_PATTERN = /^[A-Za-z0-9/.\-]{3,40}$/;
const MARK_PATTERN = /^\d{1,3}(\.\d{1,2})?$/;
const MAX_SUBJECTS = 40;
const MAX_RESULTS_SHOWN = 300;
const MAX_REMARK = 600;

const noStore = (req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
};

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const round2 = (n) => Math.round(n * 100) / 100;

// Accepts undefined, one string, or an array of strings (what
// express.urlencoded gives for repeated `subject[]` fields). Anything
// else (nested objects from `subject[$ne]=1`) is rejected outright.
function toStringArray(value) {
  if (value === undefined) return [];
  if (isPlainString(value)) return [value];
  if (Array.isArray(value) && value.every(isPlainString)) return value;
  return null;
}

// Turns the submitted subject rows into clean, validated subjects.
// Returns { error, rows } on failure (rows = what to show back in the
// form) or { subjects, grandTotal, rows } on success.
function parseSubjects(body) {
  const names = toStringArray(body.subject);
  const cas = toStringArray(body.ca);
  const exams = toStringArray(body.exam);
  if (!names || !cas || !exams) return { error: 'Invalid submission.', rows: [] };
  if (names.length > MAX_SUBJECTS) return { error: `You can list at most ${MAX_SUBJECTS} subjects.`, rows: [] };

  const rows = [];
  const subjects = [];
  const seen = new Set();
  let error = '';

  names.forEach((rawName, i) => {
    const name = sanitizeText(rawName).slice(0, 80);
    const caRaw = sanitizeText(cas[i] || '');
    const examRaw = sanitizeText(exams[i] || '');
    if (!name && !caRaw && !examRaw) return; // blank row, ignore
    rows.push({ name, ca: caRaw, exam: examRaw });
    if (error) return;
    const label = name || `Row ${rows.length}`;
    if (!name) { error = `Row ${rows.length}: enter the subject name.`; return; }
    if (seen.has(name.toLowerCase())) { error = `"${name}" is listed twice.`; return; }
    seen.add(name.toLowerCase());
    if (!MARK_PATTERN.test(caRaw) || Number(caRaw) > 100) { error = `${label}: enter a CA mark between 0 and 100.`; return; }
    if (examRaw && (!MARK_PATTERN.test(examRaw) || Number(examRaw) > 100)) { error = `${label}: the exam mark must be between 0 and 100.`; return; }
    const ca = Number(caRaw);
    const exam = examRaw ? Number(examRaw) : null;
    const total = round2(ca + (exam || 0));
    if (total > 100) { error = `${label}: CA plus exam is ${total}, which is more than 100.`; return; }
    subjects.push({ name, ca, exam, total });
  });

  if (error) return { error, rows };
  if (!subjects.length) return { error: 'Add at least one subject with its CA mark.', rows };
  const grandTotal = round2(subjects.reduce((sum, s) => sum + s.total, 0));
  return { subjects, grandTotal, rows };
}

function readableSupervisorScope(req) {
  const { level, department } = req.supervisor;
  return level === 2 ? { department } : {};
}

function searchFilter(q) {
  if (!q) return null;
  const re = new RegExp(escapeRegex(q), 'i');
  return { $or: [{ entryRegNo: re }, { entryName: re }, { session: re }, { department: re }, { 'subjects.name': re }] };
}

// ======================================================================
// SUPERVISOR
// ======================================================================
const supervisorRouter = express.Router();
supervisorRouter.use(noStore);

function blankValues() {
  return { regNo: '', session: '', supervisorRemark: '', rows: [{ name: '', ca: '', exam: '' }] };
}

function renderForm(res, status, { mode, values, error, result = null }) {
  return res.status(status).render('supervisor/result-form', { mode, values, error, result });
}

async function loadScopedResult(req, res) {
  const { id } = req.params;
  if (!mongoose.isValidObjectId(id)) { res.status(404).render('404'); return null; }
  const result = await Result.findOne({ _id: id, ...readableSupervisorScope(req) }).lean();
  if (!result) {
    await logAction(req, {
      actorType: 'supervisor', actorId: req.supervisor.supervisorId, actorLabel: req.supervisor.username,
      level: req.supervisor.level, department: req.supervisor.level === 2 ? req.supervisor.department : '',
      action: 'RESULT_VIEW_DENIED', meta: { resultId: id },
    });
    res.status(404).render('404');
    return null;
  }
  return result;
}

supervisorRouter.get('/', requireSupervisor, async (req, res, next) => {
  try {
    const q = sanitizeText(isPlainString(req.query.q) ? req.query.q : '').slice(0, 100);
    const filter = { ...readableSupervisorScope(req) };
    const search = searchFilter(q);
    if (search) Object.assign(filter, search);
    const results = await Result.find(filter)
      .select({ entryRegNo: 1, entryName: 1, department: 1, session: 1, grandTotal: 1, adminRemark: 1, preparedBy: 1, preparedByUsername: 1, subjects: 1, createdAt: 1 })
      .sort({ createdAt: -1 }).limit(MAX_RESULTS_SHOWN).lean();
    res.render('supervisor/results', { supervisor: req.supervisor, results, q });
  } catch (err) { next(err); }
});

supervisorRouter.get('/new', requireSupervisor, (req, res) => {
  const values = blankValues();
  if (isPlainString(req.query.regNo)) values.regNo = sanitizeText(req.query.regNo).toUpperCase().slice(0, 40);
  renderForm(res, 200, { mode: 'new', values, error: null });
});

supervisorRouter.post('/', requireSupervisor, async (req, res, next) => {
  try {
    const body = req.body || {};
    const { level, department, supervisorId, username } = req.supervisor;
    const regNo = isPlainString(body.regNo) ? sanitizeText(body.regNo).toUpperCase().slice(0, 40) : '';
    const session = isPlainString(body.session) ? sanitizeText(body.session).slice(0, 60) : '';
    const supervisorRemark = isPlainString(body.supervisorRemark) ? sanitizeMultiline(body.supervisorRemark).slice(0, MAX_REMARK) : '';
    const parsed = parseSubjects(body);
    const values = { regNo, session, supervisorRemark, rows: parsed.rows.length ? parsed.rows : blankValues().rows };
    const fail = (message) => renderForm(res, 400, { mode: 'new', values, error: message });

    if (!REGNO_PATTERN.test(regNo)) return fail('Enter a valid registration number.');
    if (!session) return fail('Enter the session, e.g. 2025/2026 First Semester.');
    if (parsed.error) return fail(parsed.error);

    const entry = await Entry.findOne({ regNo }).lean();
    if (!entry || entry.active === false) return fail('No user found with that registration number.');
    if (level === 2 && entry.department !== department) return fail('This person is outside your department, so you cannot prepare a result for them.');

    let result;
    try {
      result = await Result.create({
        entry: entry._id, entryRegNo: entry.regNo, entryName: fullName(entry), department: entry.department,
        session, subjects: parsed.subjects, grandTotal: parsed.grandTotal, supervisorRemark,
        preparedBy: supervisorId, preparedByUsername: username,
      });
    } catch (err) {
      if (err && err.code === 11000) return fail('A result for this person and session already exists. Open it from the list to edit it.');
      throw err;
    }

    await logAction(req, {
      actorType: 'supervisor', actorId: supervisorId, actorLabel: username, level,
      department: level === 2 ? department : '', action: 'RESULT_SAVED',
      targetEntryId: entry._id.toString(), meta: { resultId: result._id.toString(), regNo: entry.regNo, session, subjects: parsed.subjects.length, grandTotal: parsed.grandTotal },
    });
    res.redirect(`/supervisor/results/${result._id}`);
  } catch (err) { next(err); }
});

supervisorRouter.get('/:id', requireSupervisor, async (req, res, next) => {
  try {
    const result = await loadScopedResult(req, res);
    if (!result) return;
    res.render('supervisor/result-view', {
      supervisor: req.supervisor, result,
      canEdit: String(result.preparedBy) === req.supervisor.supervisorId,
    });
  } catch (err) { next(err); }
});

supervisorRouter.get('/:id/edit', requireSupervisor, async (req, res, next) => {
  try {
    const result = await loadScopedResult(req, res);
    if (!result) return;
    if (String(result.preparedBy) !== req.supervisor.supervisorId) return res.redirect(`/supervisor/results/${result._id}`);
    const values = {
      regNo: result.entryRegNo, session: result.session, supervisorRemark: result.supervisorRemark || '',
      rows: result.subjects.map((s) => ({ name: s.name, ca: String(s.ca), exam: s.exam === null || s.exam === undefined ? '' : String(s.exam) })),
    };
    renderForm(res, 200, { mode: 'edit', values, error: null, result });
  } catch (err) { next(err); }
});

supervisorRouter.post('/:id', requireSupervisor, async (req, res, next) => {
  try {
    const result = await loadScopedResult(req, res);
    if (!result) return;
    if (String(result.preparedBy) !== req.supervisor.supervisorId) return res.redirect(`/supervisor/results/${result._id}`);

    const body = req.body || {};
    const session = isPlainString(body.session) ? sanitizeText(body.session).slice(0, 60) : '';
    const supervisorRemark = isPlainString(body.supervisorRemark) ? sanitizeMultiline(body.supervisorRemark).slice(0, MAX_REMARK) : '';
    const parsed = parseSubjects(body);
    const values = { regNo: result.entryRegNo, session, supervisorRemark, rows: parsed.rows.length ? parsed.rows : blankValues().rows };
    const fail = (message) => renderForm(res, 400, { mode: 'edit', values, error: message, result });

    if (!session) return fail('Enter the session, e.g. 2025/2026 First Semester.');
    if (parsed.error) return fail(parsed.error);

    try {
      await Result.updateOne({ _id: result._id }, { $set: { session, subjects: parsed.subjects, grandTotal: parsed.grandTotal, supervisorRemark } }, { runValidators: true });
    } catch (err) {
      if (err && err.code === 11000) return fail('Another result for this person already uses that session.');
      throw err;
    }

    await logAction(req, {
      actorType: 'supervisor', actorId: req.supervisor.supervisorId, actorLabel: req.supervisor.username, level: req.supervisor.level,
      department: req.supervisor.level === 2 ? req.supervisor.department : '', action: 'RESULT_UPDATED',
      targetEntryId: String(result.entry), meta: { resultId: String(result._id), regNo: result.entryRegNo, session, subjects: parsed.subjects.length, grandTotal: parsed.grandTotal },
    });
    res.redirect(`/supervisor/results/${result._id}`);
  } catch (err) { next(err); }
});

// ======================================================================
// ADMIN
// ======================================================================
const adminRouter = express.Router();
adminRouter.use(noStore);

adminRouter.get('/', requireAdmin, async (req, res, next) => {
  try {
    const q = sanitizeText(isPlainString(req.query.q) ? req.query.q : '').slice(0, 100);
    const filter = searchFilter(q) || {};
    const results = await Result.find(filter)
      .select({ entryRegNo: 1, entryName: 1, department: 1, session: 1, grandTotal: 1, adminRemark: 1, preparedByUsername: 1, subjects: 1, createdAt: 1 })
      .sort({ createdAt: -1 }).limit(MAX_RESULTS_SHOWN).lean();
    res.render('admin/results', { results, q });
  } catch (err) { next(err); }
});

async function loadResult(req, res) {
  const { id } = req.params;
  if (!mongoose.isValidObjectId(id)) { res.status(404).render('admin/not-found'); return null; }
  const result = await Result.findById(id).lean();
  if (!result) { res.status(404).render('admin/not-found'); return null; }
  return result;
}

adminRouter.get('/:id', requireAdmin, async (req, res, next) => {
  try {
    const result = await loadResult(req, res);
    if (!result) return;
    res.render('admin/result-view', { result, saved: req.query.saved === '1', error: null });
  } catch (err) { next(err); }
});

adminRouter.post('/:id/remark', requireAdmin, async (req, res, next) => {
  try {
    const result = await loadResult(req, res);
    if (!result) return;
    const raw = req.body && req.body.adminRemark;
    if (!isPlainString(raw)) return res.status(400).render('admin/result-view', { result, saved: false, error: 'Invalid submission.' });
    const adminRemark = sanitizeMultiline(raw).slice(0, MAX_REMARK);
    await Result.updateOne({ _id: result._id }, { $set: { adminRemark, adminRemarkAt: adminRemark ? new Date() : null } });
    await logAction(req, {
      actorType: 'admin', actorLabel: 'admin', action: 'RESULT_ADMIN_REMARK',
      targetEntryId: String(result.entry), department: result.department,
      meta: { resultId: String(result._id), regNo: result.entryRegNo, session: result.session, cleared: !adminRemark },
    });
    res.redirect(`/admin/results/${result._id}?saved=1`);
  } catch (err) { next(err); }
});

adminRouter.delete('/:id', requireAdmin, async (req, res, next) => {
  try {
    const result = await loadResult(req, res);
    if (!result) return;
    await Result.deleteOne({ _id: result._id });
    await logAction(req, {
      actorType: 'admin', actorLabel: 'admin', action: 'RESULT_DELETED',
      targetEntryId: String(result.entry), department: result.department,
      meta: { resultId: String(result._id), regNo: result.entryRegNo, session: result.session, grandTotal: result.grandTotal },
    });
    res.redirect('/admin/results');
  } catch (err) { next(err); }
});

module.exports = { supervisorRouter, adminRouter };
