const express = require('express');
const { isPlainString, sanitizeText } = require('../utils/sanitize');

const router = express.Router();
const PIN_PATTERN = /^[a-zA-Z0-9]{4,10}$/;

// GET / — landing page: enter a pin
router.get('/', (req, res) => {
  res.render('pin/home', { error: null });
});

// POST / — forward to /:pin, which does the actual existence/used check
router.post('/', (req, res) => {
  const body = req.body || {};

  // Reject non-string input (e.g. pin[$ne]=1 or a repeated field arriving
  // as an array) before it's ever used to build a redirect or a query.
  if (body.pin !== undefined && !isPlainString(body.pin)) {
    return res.status(400).render('pin/home', { error: 'Invalid pin.' });
  }

  const raw = sanitizeText(body.pin);

  if (!raw) {
    return res.status(400).render('pin/home', { error: 'Please enter a pin.' });
  }

  if (!PIN_PATTERN.test(raw)) {
    return res.status(400).render('pin/home', { error: 'Pin must be 4-10 letters/numbers.' });
  }

  res.redirect(`/${raw}`);
});

module.exports = router;
