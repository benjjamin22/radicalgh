const mongoose = require('mongoose');

// One Entry per pin — created the moment that pin's form is submitted.
const entrySchema = new mongoose.Schema(
  {
    pin: { type: String, required: true, unique: true, trim: true, index: true },
    regNo: { type: String, required: true, unique: true, trim: true, uppercase: true, maxlength: 40 },
    firstName: { type: String, required: true, trim: true, maxlength: 100 },
    middleName: { type: String, trim: true, default: '', maxlength: 100 },
    surname: { type: String, required: true, trim: true, maxlength: 100 },
    phone: { type: String, trim: true, default: '', maxlength: 30 },
    faculty: { type: String, required: true, trim: true, maxlength: 100 },
    // Indexed on its own (not just as part of the pin lookup) because the
    // department-listing page queries by department for every visit.
    department: { type: String, required: true, trim: true, maxlength: 100, index: true },
    status: { type: String, trim: true, default: 'STUDENT', maxlength: 40 },
    lga: { type: String, trim: true, default: '', maxlength: 80 },

    sex: { type: String, trim: true, default: '', maxlength: 20 },
    bloodGroup: { type: String, trim: true, default: '', maxlength: 10 },
    state: { type: String, trim: true, default: '', maxlength: 60 },
    emergencyPhone: { type: String, trim: true, default: '', maxlength: 30 },

    // Profile photo, stored in Google Drive — only the file id (needed to
    // delete/replace it later) and a direct-viewable URL (used in <img
    // src>) live in Mongo. See src/utils/googleDrive.js.
    photoId: { type: String, trim: true, default: '' },
    photoUrl: { type: String, trim: true, default: '' },

    // Admin-only kill switch. An inactive entry can no longer be reached
    // through its pin (GET /:pin) or through the public /entry/:id
    // profile page — this is deliberately separate from deletion, which
    // frees the pin for reuse (see admin-only DELETE /admin/entries/:id).
    // Deactivating just locks the pin holder out without losing the
    // record or freeing the pin.
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Entry', entrySchema);
