const mongoose = require('mongoose');

const cashierPayoutSchema = new mongoose.Schema(
  {
    requesterType: { type: String, enum: ['cashier', 'supervisor'], default: 'cashier', index: true },
    cashier: { type: mongoose.Schema.Types.ObjectId, ref: 'Cashier', default: null, index: true },
    supervisor: { type: mongoose.Schema.Types.ObjectId, ref: 'Supervisor', default: null, index: true },
    cashierUsername: { type: String, trim: true, default: '', maxlength: 60 },
    requesterUsername: { type: String, trim: true, required: true, maxlength: 60 },
    amount: { type: Number, required: true, min: 0.01 },
    reason: { type: String, trim: true, maxlength: 300, default: '' },
    status: { type: String, enum: ['Pending', 'Approved', 'Rejected'], default: 'Pending', index: true },
    requestedAt: { type: Date, default: Date.now },
    decidedAt: { type: Date, default: null },
    decidedBy: { type: String, trim: true, default: '' },
    decisionNote: { type: String, trim: true, maxlength: 300, default: '' },
  },
  { timestamps: true }
);

cashierPayoutSchema.index({ createdAt: -1 });

module.exports = mongoose.model('CashierPayout', cashierPayoutSchema);
