const mongoose = require('mongoose');

// A pin must already exist in the database to be usable — this app never
// generates pins itself. `used` flips to true the moment an Entry is
// submitted for it, which is what routes a later visit to the view page
// instead of the form.
const pinSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true, trim: true },
    used: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Pin', pinSchema);
