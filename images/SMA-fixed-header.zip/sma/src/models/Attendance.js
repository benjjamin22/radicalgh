const mongoose = require('mongoose');

// One document per (person, session, type). Created only from the
// supervisor attendance scanner (see routes/supervisor.js, "ATTENDANCE
// SCANNER" section). This is strictly a gate log — who entered and who
// exited, and when — never a payment or receipt of any kind. The
// supervisor locks in a session name AND a type ("entry" or "exit")
// before scanning; a scan or reg-no entry for a person already marked
// with that same type for that same session hits the unique index below
// and is reported back to the scanner page as "already marked", not a
// second record. Marking someone's exit is a separate lock/scan pass
// from marking their entry — both are recorded, neither overwrites the
// other, so a person's full session record is their entry row plus
// (once it happens) their exit row.
const attendanceSchema = new mongoose.Schema(
  {
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry', required: true },
    entryRegNo: { type: String, required: true, trim: true },
    entryName: { type: String, required: true, trim: true },
    department: { type: String, trim: true, default: '' },
    // Free-text session/event name the supervisor locks in before
    // scanning — e.g. "Morning Assembly — 22 Sep 2026". Not a ref to
    // any other collection; there is no separate "sessions" list.
    session: { type: String, required: true, trim: true, maxlength: 200 },
    // Which side of the gate this record is: 'entry' when the person
    // arrived, 'exit' when they left.
    type: { type: String, required: true, enum: ['entry', 'exit'] },
    markedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Supervisor', required: true },
    markedByUsername: { type: String, trim: true, default: '' },
    supervisorLevel: { type: Number, default: null },
  },
  { timestamps: true }
);

attendanceSchema.index({ entry: 1, session: 1, type: 1 }, { unique: true });
attendanceSchema.index({ session: 1, type: 1, createdAt: -1 });

module.exports = mongoose.model('Attendance', attendanceSchema);
