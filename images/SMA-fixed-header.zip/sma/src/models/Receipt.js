const mongoose = require('mongoose');

// A receipt is created by a cashier against one Entry ("user"). Cashiers
// can only ever CREATE and READ-THEIR-OWN receipts (enforced in
// routes/cashier.js, not just hidden in the UI); only an admin can
// update or delete one (routes/admin.js), which is why this schema has
// no soft-delete/void flag of its own — deletion is a real admin CRUD
// operation, logged like everything else.
const receiptSchema = new mongoose.Schema(
  {
    receiptNo: { type: String, required: true, unique: true, trim: true, uppercase: true, index: true },

    // The user (Entry) the receipt was issued to. Kept as a ref so the
    // live record can always be looked up, plus a denormalized snapshot
    // of the three fields a cashier is allowed to see, so a receipt
    // still reads sensibly even if the entry is later edited/removed.
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry', required: true },
    entryRegNo: { type: String, trim: true, required: true, maxlength: 40 },
    entryName: { type: String, trim: true, required: true, maxlength: 200 },
    // Also the scope field: level-2 cashiers may only issue against (and
    // only ever see) receipts whose department matches their own.
    department: { type: String, trim: true, required: true, maxlength: 100, index: true },

    amount: { type: Number, required: true, min: 0.01 },
    purpose: { type: String, trim: true, required: true, maxlength: 300 },

    cashier: { type: mongoose.Schema.Types.ObjectId, ref: 'Cashier', required: true, index: true },
    cashierUsername: { type: String, trim: true, required: true, maxlength: 60 },
    cashierLevel: { type: Number, required: true, enum: [1, 2] },
  },
  { timestamps: true }
);

receiptSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Receipt', receiptSchema);
