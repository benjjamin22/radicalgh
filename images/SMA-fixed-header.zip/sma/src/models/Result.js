const mongoose = require('mongoose');

// One document per (person, session). Prepared by a supervisor (see
// routes/results.js, supervisor router) and read/remarked/deleted by an
// admin (admin router in the same file). Nothing here touches receipts,
// attendance, or the Entry itself — it only references the Entry.
//
// Each subject row carries the continuous-assessment (CA) mark, an
// optional exam mark, and the stored total (CA + exam). Marks are not
// tied to a fixed scale: each mark is 0-100 and a subject's total may not
// exceed 100, so this works for any CA/exam split (30/70, 40/60, ...).
const subjectSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    ca: { type: Number, required: true, min: 0, max: 100 },
    exam: { type: Number, default: null, min: 0, max: 100 },
    total: { type: Number, required: true, min: 0, max: 100 },
  },
  { _id: false }
);

const resultSchema = new mongoose.Schema(
  {
    entry: { type: mongoose.Schema.Types.ObjectId, ref: 'Entry', required: true },
    entryRegNo: { type: String, required: true, trim: true },
    entryName: { type: String, required: true, trim: true },
    department: { type: String, trim: true, default: '' },

    // Free-text label, e.g. "2025/2026 First Semester".
    session: { type: String, required: true, trim: true, maxlength: 60 },
    subjects: { type: [subjectSchema], default: [] },
    grandTotal: { type: Number, default: 0 },

    supervisorRemark: { type: String, trim: true, default: '', maxlength: 600 },
    preparedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'Supervisor', required: true },
    preparedByUsername: { type: String, trim: true, default: '' },

    adminRemark: { type: String, trim: true, default: '', maxlength: 600 },
    adminRemarkAt: { type: Date, default: null },
  },
  { timestamps: true }
);

resultSchema.index({ entry: 1, session: 1 }, { unique: true });
resultSchema.index({ department: 1, createdAt: -1 });
resultSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Result', resultSchema);
