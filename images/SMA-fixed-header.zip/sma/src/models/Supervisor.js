const mongoose = require('mongoose');

// Created only by an admin (see routes/admin.js) — supervisors never
// self-register. `level` decides scope everywhere in routes/supervisor.js:
//   1 -> can search/edit/update entries across every department
//   2 -> can search/edit/update entries only within `department`
// `department` is required for level 2 and ignored (left unset) for
// level 1, enforced in the admin route that creates these.
const supervisorSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true, trim: true, lowercase: true, maxlength: 60 },
    passwordHash: { type: String, required: true },
    level: { type: Number, required: true, enum: [1, 2] },
    // Only meaningful for level 2. Stored as a plain department string
    // (matches Entry.department) rather than a ref, consistent with how
    // faculty/department are stored on Entry.
    department: { type: String, trim: true, default: '', maxlength: 100 },
    active: { type: Boolean, default: true },
    createdBy: { type: String, trim: true, default: 'admin' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Supervisor', supervisorSchema);
