const mongoose = require('mongoose');

// One document per admin/supervisor action. Nothing here is ever
// updated or deleted by the app itself — it's an append-only trail.
// `before`/`after` hold only the fields that actually changed on an
// UPDATE action (see routes/supervisor.js), not a full entry snapshot,
// to keep log documents small.
const auditLogSchema = new mongoose.Schema(
  {
    actorType: { type: String, required: true, enum: ['admin', 'supervisor', 'cashier'] },
    // For a supervisor/cashier actor: their _id and username. For the
    // shared admin login there's no per-admin account, so actorId stays
    // empty and actorLabel is just "admin".
    actorId: { type: String, trim: true, default: '' },
    actorLabel: { type: String, trim: true, default: '' },
    level: { type: Number, default: null }, // 1, 2, or null for admin actions

    action: {
      type: String,
      required: true,
      enum: [
        'ADMIN_LOGIN_SUCCESS',
        'ADMIN_LOGIN_FAILURE',
        'ADMIN_LOGOUT',
        'SUPERVISOR_CREATED',
        'SUPERVISOR_DEACTIVATED',
        'SUPERVISOR_REACTIVATED',
        'SUPERVISOR_LOGIN_SUCCESS',
        'SUPERVISOR_LOGIN_FAILURE',
        'SUPERVISOR_LOGOUT',
        'ENTRY_SEARCH',
        'ENTRY_VIEW',
        'ENTRY_VIEW_DENIED',
        'ENTRY_UPDATE',
        'ENTRY_UPDATE_DENIED',
        'ENTRY_DELETE',
        'CASHIER_CREATED',
        'CASHIER_DEACTIVATED',
        'CASHIER_REACTIVATED',
        'CASHIER_LOGIN_SUCCESS',
        'CASHIER_LOGIN_FAILURE',
        'CASHIER_LOGOUT',
        'CASHIER_USER_SEARCH',
        'CASHIER_USER_SEARCH_DENIED',
        'RECEIPT_ISSUED',
        'RECEIPT_ISSUE_DENIED',
        'RECEIPT_VIEW',
        'RECEIPT_VIEW_DENIED',
        'RECEIPT_UPDATE',
        'RECEIPT_DELETE',
        'ATTENDANCE_MARKED',
        'ATTENDANCE_MARK_DENIED',
        'RESULT_SAVED',
        'RESULT_UPDATED',
        'RESULT_VIEW_DENIED',
        'RESULT_ADMIN_REMARK',
        'RESULT_DELETED',
      ],
    },

    targetEntryId: { type: String, trim: true, default: '' },
    targetPin: { type: String, trim: true, default: '' },
    targetReceiptId: { type: String, trim: true, default: '' },
    department: { type: String, trim: true, default: '' },

    // Free-form details specific to the action — e.g. { query } for a
    // search, or { changed: { name: { from, to }, ... } } for an update.
    meta: { type: mongoose.Schema.Types.Mixed, default: {} },

    ip: { type: String, trim: true, default: '' },
  },
  { timestamps: true }
);

auditLogSchema.index({ createdAt: -1 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
