// Vercel serverless entry point.
// Vercel invokes exported Express apps directly as request handlers —
// it does NOT run app.listen() (that only happens locally via `npm start`,
// which uses src/bin/www instead).
require('dotenv').config();
const app = require('../src/app');

module.exports = app;
