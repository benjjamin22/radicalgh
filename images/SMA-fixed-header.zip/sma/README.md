# Pin-gated intake form (Node.js / Express / EJS / MongoDB)

Full CRUD on an entry is now an **admin-only** capability
(`/admin/entries`). The self-service pin flow below only supports
Create and a phone-only Update; Delete is admin-only too.

Visiting `/:pin` is the only entry point into this app. What it shows
depends on that pin's state **in the database**:

| Pin state                          | What `/:pin` shows                        |
|-------------------------------------|--------------------------------------------|
| Doesn't exist in the `pins` collection | "Pin doesn't exist" page                 |
| Exists, `used: false`                | The intake form (Create)                    |
| Exists, `used: true`, entry `active: true`  | A department listing ("users"); the pin holder's own row opens an edit page where **only their phone number is editable** |
| Exists, `used: true`, entry `active: false` | "Entry deactivated" page — admin has locked this pin holder out (see Deactivation below) |

There's no sign-up flow and no way to generate a pin from the app itself —
pins are inserted directly into MongoDB (see below) and handed out to
whoever should fill in the form.

## Routes

| Method | Path         | Does                                                            |
|--------|--------------|------------------------------------------------------------------|
| GET    | /            | Landing page — type in a pin                                     |
| POST   | /            | Redirects to `/:pin`                                              |
| GET    | /:pin        | Looks up the pin and renders form / department listing / not-found / deactivated accordingly |
| POST   | /:pin        | **Create** — submits the form; on success, redirects to `/:pin`, which (now `used`) shows the department listing |
| GET    | /:pin/edit   | Edit page — every field is read-only except phone                 |
| PUT    | /:pin        | **Update phone only** — every other submitted field is ignored server-side |
| GET    | /:pin/profile| The pin holder's full profile (all fields, read-only) plus their payment/receipt history — reachable only via `/entry/:id` -> "Login with pin" (see below), not linked directly from the edit page |
| GET    | /entry/:id   | Public, `_id`-addressed basic profile (no payments) with a "Login with pin" form that unlocks `/:pin/profile` |
| POST   | /entry/:id   | Checks the submitted pin against this entry; on match, authenticates and redirects to `/:pin/profile` |
| GET    | /health      | `{ ok: true }`                                                    |

Admin (`/admin/...`), supervisor (`/supervisor/...`), cashier
(`/cashier/...`), and entry (`/entry/...`) routes are documented in their
own sections below — they're mounted ahead of `/:pin`, so those four
words can't be issued as pins.

`PUT` is sent from a plain HTML form via a hidden `_method` field
(handled by `method-override`).

Only an admin can delete an entry now (`DELETE /admin/entries/:id`) — see
the Admin & supervisor area section below. Deleting it there sets that
pin's `used` back to `false`, so `/:pin` shows the intake form again — the
pin is reusable.

A pin is 4–10 letters/numbers.

## Data model

**`pins` collection** (`src/models/Pin.js`)
- `code` — the pin string, unique
- `used` — `true` while a submission exists for this pin; `false` once
  it's deleted

**`entries` collection** (`src/models/Entry.js`) — one per pin, created on submit
- `pin` — which pin this entry belongs to (unique)
- `regNo`, `firstName`, `surname` — required (`middleName` optional)
- `faculty`, `department` — required, validated against `src/config/faculties.js`
- `sex`, `bloodGroup`, `state` — required, validated against fixed option lists
- `emergencyPhone`, `emergencyRelation` — required
- `phone`, `message` — optional
- `photoId`, `photoUrl` — optional; set when a profile photo is uploaded.
  `photoId` is the Google Drive file id (used to delete/replace the photo
  later), `photoUrl` is a direct-viewable link used in `<img src>`.

## Profile photo (Google Drive)

The Create and Edit pages let a visitor attach a profile photo. Photos
never touch this app's disk/database — they're uploaded in-memory
(`multer`, 5MB limit, JPEG/PNG/WEBP only) straight to Google Drive via a
service account (`src/utils/googleDrive.js`), made link-viewable, and only
the resulting file id + URL are stored on the `Entry`.

To enable it, set in `.env`:
```
GOOGLE_SERVICE_ACCOUNT_EMAIL=your-service-account@your-project.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
GOOGLE_DRIVE_FOLDER_ID=   # optional — a Drive folder shared with the service account as Editor
```
Without these set, the app still works fine — submissions without a photo
just show a placeholder avatar. A failed/misconfigured upload shows a
friendly form error rather than a 500.

Uploading a new photo, and the "remove current photo" checkbox, are now
admin-only actions (`/admin/entries/:id/edit`) — the self-service Edit
page only lets a pin holder change their phone number, so it has no
photo controls at all.

## Adding pins

Since there's no admin UI for pins specifically, insert them straight into
MongoDB, e.g. via `mongosh`:

```js
use database
db.pins.insertMany([
  { code: "4821", used: false },
  { code: "9310", used: false }
])
```

Anyone who visits `/4821` will get the form; once they submit it, `used`
flips to `true` and future visits to `/4821` show the department listing
instead, with the submitter's own row opening an edit page where only
their phone number can be changed.

## Admin & supervisor area

A separate, password-gated area for staff, on top of the self-service pin
flow above.

- **Only admin has full CRUD on entries.** Admin can search every
  department, and edit or delete any entry, at `/admin/entries`.
- **Supervisor is read-only.** A supervisor can search and view entries
  within their scope, but there is no update or delete route available to
  a supervisor anywhere in the app — not just hidden in the UI, the
  routes simply don't exist for that role.

**Admin** (`/admin`) — a single shared password (`ADMIN_PASSWORD` in
`.env`), no individual admin accounts. An admin can:
- Search, edit (every field, including photo), and delete any entry at
  `/admin/entries` — this is the only place in the app with full CRUD on
  an entry.
- Create supervisor accounts with a username, password, and a **level**:
  - **Level 1** — can search and view entries across every department.
  - **Level 2** — assigned one specific department at creation; can only
    search/view entries within that department. The scope is enforced
    server-side (the department filter is forced on every query and
    re-checked on every view), not just hidden in the UI.
- Deactivate / reactivate a supervisor account. Deactivation takes effect
  immediately — supervisor sessions re-check the live account status on
  every request rather than trusting the login token for its full 8h.
- View the audit log (`/admin/logs`).

**Supervisor** (`/supervisor`) — signs in with the username/password an
admin created. The dashboard is a search box (name, reg no, phone,
or pin) over whatever scope their level allows, and each result opens a
**read-only** view. There is no edit or delete capability for a
supervisor — to change or remove an entry, an admin has to do it at
`/admin/entries`.

**Audit log** — every admin and supervisor action is written to the
`auditlogs` collection (`src/models/AuditLog.js`): logins/logouts
(success and failure), supervisor creation/deactivation, every search,
every entry view (and denied views, for a level-2 supervisor stepping
outside their department), and every admin update/delete of an entry
(updates include a from/to diff of just the fields that changed). Nothing
is ever deleted or edited after the fact — it's an append-only trail,
visible to admins at `/admin/logs`.

Routes:

| Method | Path                          | Requires    | Does                                             |
|--------|-------------------------------|-------------|--------------------------------------------------|
| GET    | /admin/login                  | —           | Admin login form                                  |
| POST   | /admin/login                  | —           | Checks the shared password, sets the admin cookie |
| POST   | /admin/logout                 | admin       | Clears the admin cookie                           |
| GET    | /admin                        | admin       | Dashboard — create supervisors/cashiers, list existing ones |
| POST   | /admin/supervisors            | admin       | Creates a supervisor account                      |
| POST   | /admin/supervisors/:id/toggle | admin       | Activate/deactivate a supervisor                  |
| GET    | /admin/entries                | admin       | Search every entry, any department                |
| GET    | /admin/entries/:id/edit       | admin       | Full edit form for one entry (every field + photo) |
| PUT    | /admin/entries/:id            | admin       | Updates an entry; logs a from/to diff             |
| DELETE | /admin/entries/:id            | admin       | Deletes an entry and frees its pin for reuse       |
| POST   | /admin/entries/:id/toggle     | admin       | Activates/deactivates an entry (locks the pin without freeing it) |
| GET    | /admin/logs                   | admin       | Paginated audit log                               |
| GET    | /supervisor/login             | —           | Supervisor login form                             |
| POST   | /supervisor/login             | —           | Checks username/password, sets the supervisor cookie |
| POST   | /supervisor/logout            | supervisor  | Clears the supervisor cookie                      |
| GET    | /supervisor                   | supervisor  | Search dashboard, scoped by level                 |
| GET    | /supervisor/entry/:id         | supervisor  | Read-only view of one entry (authorized by level/department) |

## Full profile & payments (self-service)

The pin holder's edit page no longer links directly to their full
profile — that link was removed. Instead, full profile + payments is
reached through the public **`GET /entry/:id`** page (see the Routes
table above): it shows a basic read-only profile (no pin, no payments)
plus a **"Login with pin"** form. Submitting the pin that actually owns
that entry proves ownership, sets the same pin-derived auth cookie the
edit page uses, and redirects to `GET /:pin/profile`, which shows every
field on the entry read-only, plus a full history of any
receipts/payments a cashier has issued to them (amount, purpose, receipt
number, date) — pulled straight from the `receipts` collection. A wrong
pin just re-renders the same page with "Incorrect pin." — it never
reveals which part was wrong or anything about other entries.

The department listing links every *other* entry to `/entry/:id`; the
pin holder's own row still goes straight to `/:pin/edit` since they're
already authenticated for that pin.

## Deactivation (admin-only)

Separate from delete. An admin can flip `active` on an `Entry`,
`Supervisor`, or `Cashier` without removing the record:

- **Entry** — `POST /admin/entries/:id/toggle`. A deactivated entry's
  pin renders an "Entry deactivated" page for *every* route the pin
  holder could otherwise reach (`/:pin`, `/:pin/edit`, `/:pin/profile`,
  `/entry/:id`'s login) — locked out, but the pin stays `used` and the
  record isn't freed for reuse. Only `DELETE /admin/entries/:id` frees
  the pin.
- **Supervisor** — `POST /admin/supervisors/:id/toggle`. Already
  existed: `requireSupervisor` re-checks the live `active` flag on every
  request, so deactivation takes effect immediately rather than waiting
  for the session to expire.
- **Cashier** — `POST /admin/cashiers/:id/toggle`. Same mechanism as
  Supervisor, via `requireCashier`.

## Cashier & receipts area

A separate role from Supervisor, for staff who issue receipts to users
rather than editing their entries.

**Cashier** (`/cashier`) — an admin-created account with a username,
password, and a **level**, same scoping idea as Supervisor:
- **Level 1** — can look up and issue a receipt to a user in any
  department.
- **Level 2** — assigned one department at creation; can only look up
  and issue receipts to users in that department. Enforced server-side
  (the department filter is forced on every search and re-checked
  before every receipt is created), not just hidden in the UI.

A cashier's dashboard is a search box over **user ID no. (registration
number) only** — never name or phone. Search results are
projected down to just the user's **name and department** (plus the id
needed to issue a receipt); no other profile fields are ever sent to a
cashier. Opening a result shows a small form to record an **amount**
and **purpose/reason**, which creates a receipt (with an auto-generated
receipt number).

A cashier can view **only the receipts they themselves issued**
(`/cashier/receipts`), and that view is read-only — there is no
edit or delete route available to a cashier anywhere in the app.

**Admin** has full CRUD over receipts at `/admin/receipts`: search
across every receipt, edit the amount/purpose of any receipt, or
delete one outright. Admin also creates/deactivates/reactivates cashier
accounts from the main `/admin` dashboard, the same way it does for
supervisors.

**Audit log** — every cashier and admin action on this side is logged
the same way as the supervisor side: logins/logouts, cashier
creation/deactivation, every user search, every receipt issued (and any
issue attempt denied by department scope), and every admin view/update/
delete of a receipt (updates include a from/to diff).

Routes:

| Method | Path                       | Requires | Does                                              |
|--------|----------------------------|----------|----------------------------------------------------|
| GET    | /cashier/login             | —        | Cashier login form                                  |
| POST   | /cashier/login             | —        | Checks username/password, sets the cashier cookie   |
| POST   | /cashier/logout            | cashier  | Clears the cashier cookie                           |
| GET    | /cashier                   | cashier  | Search by user ID no., scoped by level              |
| POST   | /cashier/receipts          | cashier  | Issues a receipt (amount, purpose) to a searched user |
| GET    | /cashier/receipts          | cashier  | Read-only list of receipts *this cashier* issued    |
| POST   | /admin/cashiers            | admin    | Creates a cashier account                           |
| POST   | /admin/cashiers/:id/toggle | admin    | Activate/deactivate a cashier                       |
| GET    | /admin/receipts            | admin    | Search/list every receipt                           |
| GET    | /admin/receipts/:id/edit   | admin    | Edit form for one receipt                           |
| PUT    | /admin/receipts/:id        | admin    | Updates a receipt's amount/purpose                  |
| DELETE | /admin/receipts/:id        | admin    | Deletes a receipt                                   |

## Input handling

- Non-string fields are rejected outright (blocks NoSQL-operator injection
  like `name[$ne]=1`)
- Every field is trimmed and internal whitespace collapsed (no double
  spacing)
- `firstName`/`middleName`/`surname`/`phone`/`message` are capped at
  100/100/100/30/2000 characters, both in the route and at the schema level
- Views render values with EJS's escaping `<%= %>`, so stored input can't
  inject HTML/script when displayed back

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Copy the env file and fill in your own values:
   ```bash
   cp .env.example .env
   ```
   At minimum set `MONGODB_URI` (a local `mongod` or a MongoDB Atlas
   connection string).

3. Start it:
   ```bash
   npm start
   ```
   or, for auto-restart on file changes:
   ```bash
   npm run dev
   ```

   Then open `http://localhost:5000`.

## Project structure
```
server/
├── src/
│   ├── index.js              # Entry point, requires bin/www
│   ├── app.js                  # Express app, view engine, middleware, routes
│   ├── db.js                   # Mongoose connection
│   ├── config/
│   │   ├── faculties.js        # Faculty -> departments map
│   │   └── states.js           # State dropdown options
│   ├── models/
│   │   ├── Pin.js              # code, used
│   │   ├── Entry.js            # profile fields incl. photoId/photoUrl, active
│   │   ├── Supervisor.js       # username, passwordHash, level, department, active
│   │   ├── Cashier.js          # username, passwordHash, level, department, active
│   │   ├── Receipt.js          # receiptNo, entry, amount, purpose, cashier
│   │   └── AuditLog.js         # append-only admin/supervisor/cashier action trail
│   ├── utils/
│   │   ├── auth.js             # JWT cookie helpers (pin-holder auth)
│   │   ├── adminAuth.js        # JWT cookie helpers (admin + supervisor + cashier auth)
│   │   ├── password.js         # bcrypt hash/verify for supervisor/cashier accounts
│   │   ├── logger.js           # writes to AuditLog, best-effort
│   │   ├── entryFields.js      # shared entry validation (pin.js + admin.js entries CRUD)
│   │   ├── photoUpload.js      # shared multer config (pin.js + admin.js entries CRUD)
│   │   ├── sanitize.js         # input cleaning/validation helpers
│   │   ├── receiptNo.js        # generates a human-readable receipt number
│   │   └── googleDrive.js      # profile photo upload/delete (Drive)
│   ├── routes/
│   │   ├── home.js             # GET/POST / — pin entry
│   │   ├── pin.js              # mounted at /:pin — create + phone-only self edit + department listing
│   │   ├── entryProfile.js     # mounted at /entry — public profile by _id + "login with pin" -> full profile
│   │   ├── admin.js            # mounted at /admin — full CRUD on entries/receipts, activate/deactivate, supervisor/cashier mgmt, logs
│   │   ├── supervisor.js       # mounted at /supervisor — READ-ONLY scoped search/view
│   │   └── cashier.js          # mounted at /cashier — user lookup + issue/read-own receipts
│   └── views/
│       ├── home.ejs
│       ├── 404.ejs
│       ├── error.ejs
│       ├── partials/
│       │   ├── head.ejs / foot.ejs   # used by home/404/error/admin/supervisor/cashier/entry pages
│       │   └── profile-card.ejs      # shared design for form/edit/profile
│       ├── pin/
│       │   ├── form.ejs        # shown when pin exists and is unused (Create)
│       │   ├── view.ejs        # edge case: used pin with no entry
│       │   ├── edit.ejs        # phone-only edit form (mode: edit, phoneOnly: true)
│       │   ├── profile.ejs     # full read-only profile + payment history (mode: profile), reached only via /entry/:id login
│       │   ├── department.ejs  # directory of entries in a department ("users") — shown right after submission
│       │   └── not-found.ejs   # shown when pin doesn't exist, or when the entry has been deactivated
│       ├── entry/
│       │   └── view.ejs        # public basic profile by _id + "login with pin" form
│       ├── admin/
│       │   ├── login.ejs
│       │   ├── dashboard.ejs   # create/list/toggle supervisors and cashiers
│       │   ├── entries.ejs     # search every entry (admin CRUD entry point)
│       │   ├── entry-edit.ejs  # full edit + delete + activate/deactivate for one entry (only admin has this)
│       │   ├── receipts.ejs    # search every receipt (admin CRUD entry point)
│       │   ├── receipt-edit.ejs# edit or delete one receipt
│       │   └── logs.ejs        # paginated audit log
│       ├── supervisor/
│       │   ├── login.ejs
│       │   ├── dashboard.ejs   # search, scoped by level
│       │   └── view.ejs        # read-only view of one entry (no edit/delete)
│       └── cashier/
│           ├── login.ejs
│           ├── dashboard.ejs   # search by user ID no., issue a receipt
│           └── receipts.ejs    # read-only list of receipts this cashier issued
├── public/
│   └── css/style.css
├── .env.example
└── package.json
```

## Money approvals
Cashiers and supervisors can now send money approval requests to the admin. Cashier requests remain tied to the cashier's receipt balance and are balance-checked before approval. Supervisor requests are recorded separately because supervisors do not issue receipts; admin can approve or reject them from the shared Money Approvals page.
