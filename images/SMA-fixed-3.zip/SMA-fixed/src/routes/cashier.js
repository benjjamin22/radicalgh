const express = require('express');
const mongoose = require('mongoose');
const Cashier = require('../models/Cashier');
const Entry = require('../models/Entry');
const Receipt = require('../models/Receipt');
const CashierPayout = require('../models/CashierPayout');
const { isPlainString, sanitizeText } = require('../utils/sanitize');
const { verifyPassword } = require('../utils/password');
const {
  setCashierCookie,
  clearCashierCookie,
  requireCashier,
} = require('../utils/adminAuth');
const { generateReceiptNo } = require('../utils/receiptNo');
const { logAction } = require('../utils/logger');
const { fullName } = require('../utils/entryFields');

const router = express.Router();

// Same reasoning as routes/pin.js and routes/admin.js: once a cashier
// logs out, every cashier page must be re-fetched and re-checked, not
// served from the browser's back/forward cache.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

const RESULTS_PER_PAGE = 20;
const RECEIPTS_PER_PAGE = 20;
const MAX_AMOUNT = 100000000; // sanity ceiling, not a business rule
const AMOUNT_PATTERN = /^\d{1,9}(\.\d{1,2})?$/;

async function getCashierMoney(cashierId) {
  const [receiptAgg, payoutAgg] = await Promise.all([
    Receipt.aggregate([
      { $match: { cashier: new mongoose.Types.ObjectId(cashierId) } },
      { $group: { _id: null, total: { $sum: '$amount' } } },
    ]),
    CashierPayout.aggregate([
      { $match: { cashier: new mongoose.Types.ObjectId(cashierId), status: 'Approved' } },
      { $group: { _id: null, total: { $sum: '$amount' } } },
    ]),
  ]);
  const totalCollected = receiptAgg[0]?.total || 0;
  const approvedPayouts = payoutAgg[0]?.total || 0;
  return { totalCollected, approvedPayouts, available: Math.max(0, totalCollected - approvedPayouts) };
}

// Escapes regex metacharacters so a search term is used as literal text,
// never as an arbitrary regex — same reasoning as routes/supervisor.js.
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// -------------------- LOGIN / LOGOUT --------------------

router.get('/login', (req, res) => {
  res.render('cashier/login', { error: null });
});

router.post('/login', async (req, res, next) => {
  try {
    const body = req.body || {};
    if (!isPlainString(body.username) || !isPlainString(body.password)) {
      return res.status(400).render('cashier/login', { error: 'Invalid submission.' });
    }

    const username = sanitizeText(body.username).toLowerCase();
    const password = body.password;

    const cashier = await Cashier.findOne({ username });
    const passwordOk = cashier ? await verifyPassword(password, cashier.passwordHash) : false;

    if (!cashier || !cashier.active || !passwordOk) {
      await logAction(req, {
        actorType: 'cashier',
        actorLabel: username,
        action: 'CASHIER_LOGIN_FAILURE',
      });
      return res.status(401).render('cashier/login', { error: 'Incorrect username or password.' });
    }

    setCashierCookie(res, {
      cashierId: cashier._id.toString(),
      username: cashier.username,
      level: cashier.level,
      department: cashier.department,
    });

    await logAction(req, {
      actorType: 'cashier',
      actorId: cashier._id.toString(),
      actorLabel: cashier.username,
      level: cashier.level,
      department: cashier.department,
      action: 'CASHIER_LOGIN_SUCCESS',
    });

    res.redirect('/cashier');
  } catch (err) {
    next(err);
  }
});

router.post('/logout', requireCashier, async (req, res, next) => {
  try {
    clearCashierCookie(res);
    await logAction(req, {
      actorType: 'cashier',
      actorId: req.cashier.cashierId,
      actorLabel: req.cashier.username,
      level: req.cashier.level,
      department: req.cashier.department,
      action: 'CASHIER_LOGOUT',
    });
    res.redirect('/cashier/login');
  } catch (err) {
    next(err);
  }
});

// -------------------- SEARCH (BY USER ID NO. ONLY) --------------------
// A cashier looks a user up by regNo ("user ID no.") only — never by
// name/phone — and the result set is projected down to exactly
// the three fields a cashier is allowed to see (name, department, regNo)
// plus the id needed to issue a receipt. Level 2 always has the
// department filter forced onto the query, same enforcement pattern as
// routes/supervisor.js: not just hidden in the UI.
router.get('/', requireCashier, async (req, res, next) => {
  try {
    const money = await getCashierMoney(req.cashier.cashierId);
    res.render('cashier/dashboard', { cashier: req.cashier, money });
  } catch (err) {
    next(err);
  }
});

// -------------------- REQUEST REMITTANCE (own page) --------------------
router.get('/request-remittance', requireCashier, async (req, res, next) => {
  try {
    const money = await getCashierMoney(req.cashier.cashierId);
    const payoutRequests = await CashierPayout.find({ cashier: req.cashier.cashierId })
      .sort({ createdAt: -1 }).limit(10).lean();
    res.render('cashier/request-remittance', {
      cashier: req.cashier, money, payoutRequests, error: null,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------- ISSUE RECEIPT (own page) --------------------
router.get('/issue-receipt', requireCashier, async (req, res, next) => {
  try {
    const { level, department } = req.cashier;
    const rawQuery = isPlainString(req.query.regNo) ? req.query.regNo : '';
    const q = sanitizeText(rawQuery).toUpperCase().slice(0, 40);
    // A scanned QR carries the entry's pin, not a reg no — a pin
    // identifies exactly one entry, so it's looked up directly rather
    // than run through the reg-no text search below.
    const rawPin = isPlainString(req.query.pin) ? req.query.pin : '';
    const scannedPin = sanitizeText(rawPin).slice(0, 10);
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);

    let entries = [];
    let total = 0;
    let pinError = null;

    if (scannedPin) {
      const pinFilter = { pin: scannedPin };
      if (level === 2) pinFilter.department = department;
      const found = await Entry.findOne(pinFilter)
        .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1, photoUrl: 1 })
        .lean();
      if (found) {
        entries = [found];
        total = 1;
      } else {
        pinError = 'No matching user found for that pin.';
      }
      await logAction(req, {
        actorType: 'cashier',
        actorId: req.cashier.cashierId,
        actorLabel: req.cashier.username,
        level,
        department: level === 2 ? department : '',
        action: 'CASHIER_USER_SEARCH',
        meta: { query: `pin:${scannedPin}`, resultCount: entries.length },
      });
    } else if (q) {
      const filter = { regNo: new RegExp(escapeRegex(q), 'i') };
      if (level === 2) {
        filter.department = department;
      }
      [entries, total] = await Promise.all([
        Entry.find(filter)
          .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1, photoUrl: 1 })
          .sort({ surname: 1, firstName: 1 })
          .skip((page - 1) * RESULTS_PER_PAGE)
          .limit(RESULTS_PER_PAGE)
          .lean(),
        Entry.countDocuments(filter),
      ]);

      await logAction(req, {
        actorType: 'cashier',
        actorId: req.cashier.cashierId,
        actorLabel: req.cashier.username,
        level,
        department: level === 2 ? department : '',
        action: 'CASHIER_USER_SEARCH',
        meta: { query: q, resultCount: entries.length },
      });
    }

    res.render('cashier/issue-receipt', {
      cashier: req.cashier,
      entries,
      q,
      page,
      totalPages: Math.max(1, Math.ceil(total / RESULTS_PER_PAGE)),
      error: pinError,
      issued: null,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------- ISSUE RECEIPT --------------------
// Only entryId, amount, and purpose are accepted from the form — a
// cashier can never set which department/name a receipt records; those
// are always re-read from the live Entry server-side.
router.post('/receipts', requireCashier, async (req, res, next) => {
  const { level, department } = req.cashier;
  const body = req.body || {};

  const renderError = async (error, entryId) => {
    let entries = [];
    if (entryId && mongoose.isValidObjectId(entryId)) {
      const found = await Entry.findById(entryId).select({ firstName:1,middleName:1,surname:1,department:1,regNo:1,photoUrl:1 }).lean();
      if(found) entries=[found];
    }
    return res.status(400).render('cashier/issue-receipt', {
      cashier: req.cashier, entries, q: '', page: 1, totalPages: 1, error, issued: null,
      reopenEntryId: entryId || '',
    });
  };

  try {
    const hasBadType = ['entryId', 'amount', 'purpose'].some(
      (key) => body[key] !== undefined && !isPlainString(body[key])
    );
    if (hasBadType) return await renderError('Invalid submission.');

    const entryId = isPlainString(body.entryId) ? body.entryId.trim() : '';
    const amountRaw = sanitizeText(body.amount);
    const purpose = sanitizeText(body.purpose).slice(0, 300);

    if (!mongoose.isValidObjectId(entryId)) {
      return await renderError('Select a valid user before issuing a receipt.');
    }
    if (!AMOUNT_PATTERN.test(amountRaw)) {
      return await renderError('Enter a valid amount (up to 2 decimal places).', entryId);
    }
    const amount = Number(amountRaw);
    if (!(amount > 0) || amount > MAX_AMOUNT) {
      return await renderError('Enter a valid amount.', entryId);
    }
    if (!purpose) {
      return await renderError('Purpose / reason is required.', entryId);
    }

    // Re-read the live entry rather than trusting anything else the form
    // submitted — this is what actually enforces the department scope.
    const entry = await Entry.findById(entryId).select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1, photoUrl: 1 }).lean();
    if (!entry) return await renderError('That user could not be found.');

    if (level === 2 && entry.department !== department) {
      await logAction(req, {
        actorType: 'cashier',
        actorId: req.cashier.cashierId,
        actorLabel: req.cashier.username,
        level,
        department,
        action: 'RECEIPT_ISSUE_DENIED',
        targetEntryId: entry._id.toString(),
        meta: { reason: 'department mismatch', entryDepartment: entry.department },
      });
      return await renderError('You are not authorized to issue a receipt to a user outside your department.');
    }

    let receipt = null;
    // Retry a handful of times on the (astronomically unlikely) chance
    // of a receiptNo collision rather than trusting uniqueness blindly.
    for (let attempt = 0; attempt < 5 && !receipt; attempt += 1) {
      try {
        receipt = await Receipt.create({
          receiptNo: generateReceiptNo(),
          entry: entry._id,
          entryRegNo: entry.regNo,
          entryName: fullName(entry),
          department: entry.department,
          amount,
          purpose,
          cashier: req.cashier.cashierId,
          cashierUsername: req.cashier.username,
          cashierLevel: level,
        });
      } catch (err) {
        if (err.code !== 11000 || attempt === 4) throw err;
      }
    }

    await logAction(req, {
      actorType: 'cashier',
      actorId: req.cashier.cashierId,
      actorLabel: req.cashier.username,
      level,
      department: entry.department,
      action: 'RECEIPT_ISSUED',
      targetEntryId: entry._id.toString(),
      targetReceiptId: receipt._id.toString(),
      meta: { receiptNo: receipt.receiptNo, amount, purpose },
    });

    // Provide the issue-receipt page's data after a successful receipt
    // too. EJS throws ReferenceError when a variable is completely
    // absent, so every field the template reads must be supplied here.
    res.render('cashier/issue-receipt', {
      cashier: req.cashier,
      entries: [],
      q: '',
      page: 1,
      totalPages: 1,
      error: null,
      issued: receipt,
    });
  } catch (err) {
    next(err);
  }
});

// -------------------- BULK RECEIPT SCANNER --------------------
// The "Scan pin" button on the issue-receipt page opens this page. The
// cashier locks in one amount + purpose, starts the camera, and every
// pin QR that is scanned issues one receipt with those locked values.
// The QR on a profile card carries a URL ending in the pin, and the
// page extracts the pin before calling POST /cashier/bulk-receipts.
// The page also has a reg-no box: the same route accepts a registration
// number instead of a pin (an exact match, never a partial one).
const PIN_PATTERN = /^[a-zA-Z0-9]{4,10}$/;
const REGNO_PATTERN = /^[A-Za-z0-9/.\-]{3,40}$/; // same shape routes/pin.js accepts

router.get('/bulk-scanner', requireCashier, (req, res) => {
  res.render('cashier/bulk-scanner', { cashier: req.cashier });
});

// Look up a person by registration number only — no receipt is issued.
// The bulk-scanner page's reg-no box calls this after Enter is pressed so
// the cashier can see the name + department and confirm it's the right
// person before POST /bulk-receipts actually charges/issues anything.
router.get('/lookup-regno', requireCashier, async (req, res) => {
  const { level, department } = req.cashier;
  const fail = (status, message) => res.status(status).json({ success: false, message });
  try {
    const regNo = isPlainString(req.query.regNo) ? sanitizeText(req.query.regNo).toUpperCase() : '';
    if (!REGNO_PATTERN.test(regNo)) return fail(400, 'Enter a valid registration number.');

    const entry = await Entry.findOne({ regNo })
      .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1 })
      .lean();
    if (!entry) return fail(404, 'No matching user found for that registration number.');

    const authorized = !(level === 2 && entry.department !== department);
    return res.json({
      success: true,
      authorized,
      student: { name: fullName(entry), id: entry.regNo, department: entry.department },
    });
  } catch (err) {
    console.error('reg no lookup failed', err);
    return fail(500, 'Server error while looking up that registration number.');
  }
});

// Same rules as POST /receipts (amount format, department scope for
// level 2, re-reading the live Entry, audit log entries) — but it takes
// a pin OR a registration number instead of an entryId and answers with
// JSON so the scanner page can keep running without a reload.
router.post('/bulk-receipts', requireCashier, async (req, res) => {
  const { level, department } = req.cashier;
  const body = req.body || {};
  const fail = (status, message) => res.status(status).json({ success: false, message });

  try {
    const hasBadType = ['pin', 'regNo', 'amount', 'purpose'].some(
      (key) => body[key] !== undefined && !isPlainString(body[key])
    );
    if (hasBadType) return fail(400, 'Invalid submission.');

    const pin = isPlainString(body.pin) ? body.pin.trim() : '';
    const regNo = isPlainString(body.regNo) ? sanitizeText(body.regNo).toUpperCase() : '';
    const amountRaw = sanitizeText(body.amount);
    const purpose = sanitizeText(body.purpose).slice(0, 300);

    // Exactly one way of naming the person: a scanned pin or a typed reg no.
    if (pin && regNo) return fail(400, 'Send either a pin or a registration number, not both.');
    const via = regNo ? 'regNo' : 'pin';
    if (via === 'regNo') {
      if (!REGNO_PATTERN.test(regNo)) return fail(400, 'Enter a valid registration number.');
    } else if (!PIN_PATTERN.test(pin)) {
      return fail(400, 'That QR code does not contain a valid pin.');
    }
    if (!AMOUNT_PATTERN.test(amountRaw)) return fail(400, 'Enter a valid amount (up to 2 decimal places).');
    const amount = Number(amountRaw);
    if (!(amount > 0) || amount > MAX_AMOUNT) return fail(400, 'Enter a valid amount.');
    if (!purpose) return fail(400, 'Purpose / reason is required.');

    const entry = await Entry.findOne(via === 'regNo' ? { regNo } : { pin })
      .select({ firstName: 1, middleName: 1, surname: 1, department: 1, regNo: 1 })
      .lean();
    if (!entry) {
      return fail(404, via === 'regNo'
        ? 'No matching user found for that registration number.'
        : 'No matching user found for that pin.');
    }

    if (level === 2 && entry.department !== department) {
      await logAction(req, {
        actorType: 'cashier',
        actorId: req.cashier.cashierId,
        actorLabel: req.cashier.username,
        level,
        department,
        action: 'RECEIPT_ISSUE_DENIED',
        targetEntryId: entry._id.toString(),
        meta: { reason: 'department mismatch', entryDepartment: entry.department, bulk: true, via },
      });
      return fail(403, 'You are not authorized to issue a receipt to a user outside your department.');
    }

    let receipt = null;
    for (let attempt = 0; attempt < 5 && !receipt; attempt += 1) {
      try {
        receipt = await Receipt.create({
          receiptNo: generateReceiptNo(),
          entry: entry._id,
          entryRegNo: entry.regNo,
          entryName: fullName(entry),
          department: entry.department,
          amount,
          purpose,
          cashier: req.cashier.cashierId,
          cashierUsername: req.cashier.username,
          cashierLevel: level,
        });
      } catch (err) {
        if (err.code !== 11000 || attempt === 4) throw err;
      }
    }

    await logAction(req, {
      actorType: 'cashier',
      actorId: req.cashier.cashierId,
      actorLabel: req.cashier.username,
      level,
      department: entry.department,
      action: 'RECEIPT_ISSUED',
      targetEntryId: entry._id.toString(),
      targetReceiptId: receipt._id.toString(),
      meta: { receiptNo: receipt.receiptNo, amount, purpose, bulk: true, via },
    });

    return res.json({
      success: true,
      student: { name: fullName(entry), id: entry.regNo, department: entry.department },
      receipt: { receiptNo: receipt.receiptNo, amount: receipt.amount, purpose: receipt.purpose },
    });
  } catch (err) {
    console.error('bulk receipt failed', err);
    return fail(500, 'Server error while issuing the receipt.');
  }
});

// -------------------- MONEY / ADMIN APPROVAL REQUESTS --------------------
router.post('/payout-requests', requireCashier, async (req, res, next) => {
  try {
    const body = req.body || {};
    const amountRaw = isPlainString(body.amount) ? sanitizeText(body.amount) : '';
    const reason = isPlainString(body.reason) ? sanitizeText(body.reason).slice(0, 300) : '';
    if (!AMOUNT_PATTERN.test(amountRaw)) return res.status(400).redirect('/cashier/request-remittance');
    const amount = Number(amountRaw);
    if (!(amount > 0) || amount > MAX_AMOUNT) return res.status(400).redirect('/cashier/request-remittance');

    const money = await getCashierMoney(req.cashier.cashierId);
    if (amount > money.available) return res.status(400).redirect('/cashier/request-remittance');

    const payout = await CashierPayout.create({
      requesterType: 'cashier',
      cashier: req.cashier.cashierId,
      requesterUsername: req.cashier.username,
      cashierUsername: req.cashier.username,
      amount,
      reason,
      status: 'Pending',
    });

    await logAction(req, {
      actorType: 'cashier',
      actorId: req.cashier.cashierId,
      actorLabel: req.cashier.username,
      level: req.cashier.level,
      department: req.cashier.department,
      action: 'CASHIER_PAYOUT_REQUESTED',
      meta: { payoutId: payout._id.toString(), amount, reason },
    });
    res.redirect('/cashier/request-remittance');
  } catch (err) { next(err); }
});

// -------------------- OWN RECEIPTS (READ-ONLY) --------------------
// A cashier can only ever read receipts *they themselves* issued — the
// filter below is forced to their own cashierId regardless of anything
// in the query string, and there is deliberately no edit/delete route
// for a cashier anywhere in this file. Only /admin/receipts can modify
// or remove a receipt.
router.get('/receipts', requireCashier, async (req, res, next) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const filter = { cashier: req.cashier.cashierId };

    const [receipts, total] = await Promise.all([
      Receipt.find(filter)
        .sort({ createdAt: -1 })
        .skip((page - 1) * RECEIPTS_PER_PAGE)
        .limit(RECEIPTS_PER_PAGE)
        .lean(),
      Receipt.countDocuments(filter),
    ]);

    const money = await getCashierMoney(req.cashier.cashierId);
    const payoutRequests = await CashierPayout.find({ cashier: req.cashier.cashierId })
      .sort({ createdAt: -1 }).limit(20).lean();
    res.render('cashier/receipts', {
      cashier: req.cashier,
      receipts,
      page,
      totalPages: Math.max(1, Math.ceil(total / RECEIPTS_PER_PAGE)),
      money,
      payoutRequests,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
